﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Opus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");
        }

    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {                
         
            DALAutoMatrix objAutoMatrix = new DALAutoMatrix();
            int iEffectedRows = 0;            
            iEffectedRows = objAutoMatrix.ResetDatabase();            
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Script", "alert('" + iEffectedRows + " records deleted');", true);

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void btnCheckDatabase_Click(object sender, EventArgs e)
    {
        try
        {
            DALAutoMatrix objAutoMatrix = new DALAutoMatrix();
            int iEffectedRows = 0;
            iEffectedRows = objAutoMatrix.DataCleaning();
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Script", "alert('Data cleaning Process Stage 1 Completed No of Rows affected " + iEffectedRows + "');", true);
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        }


    }
    protected void btnImport_Click(object sender, EventArgs e)
    {
        try
        {         
        Process.Start(HttpContext.Current.Server.MapPath("Application\\ConsoleApplication1.exe"));                
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            Process.Start(HttpContext.Current.Server.MapPath("Application\\Matrix.exe"));
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }
}