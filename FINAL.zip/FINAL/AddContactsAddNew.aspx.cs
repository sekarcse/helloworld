﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddContactsAddNew : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
        Session["CommandAddContacts"] = "save";
        try
        {
            DALContact objContact = new DALContact();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            string Employee_Name = Convert.ToString(txtContactName.Text);
            DateTime Date = Convert.ToDateTime(txtDate.Text);
            string Attitude = Convert.ToString(txtAttitude.Text);
            string Create_User = Session["UserName"].ToString();
            objContact.AddNewInsertClient_Contacts(Cust_id, Employee_Name, Attitude, Create_User, Date);        
                                    
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveAddContactsAddNew()", true);

            string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

            // ASP.NET 2.0
            if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Dashboard History Contact", "btnSave_Click", ex.Message);
        }
    }  

}