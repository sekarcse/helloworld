﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class DLAFs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            BindDLAFsData();
        }
    }

    public void BindDLAFsData()
    {
        try
        {
            DALHHSTariff objBindDLAFsData = new DALHHSTariff();
            DataSet ds = new DataSet();
            ds = objBindDLAFsData.BindDLAFsData();

            if (ds.Tables.Count > 0)
            {
                grdDLAFs.DataSource = ds;
                grdDLAFs.DataBind();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "DLAFs", "BindDLAFsData", ex.Message);
        }
    }

}