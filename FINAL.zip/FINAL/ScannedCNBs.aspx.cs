﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class ScannedCNBs : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getScannedCNB();         
        }
        else
        {
            if (Convert.ToString(Session["CommandScannedCNBs"])== "save")
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");
                Response.Clear();
                getScannedCNB();
                Session["CommandScannedCNBs"] = string.Empty;
            }
        }
    }


    protected void grdScannedCNB_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                grdScannedCNB.Columns[6].Visible = true;
                grdScannedCNB.Columns[7].Visible = true;
                TableCell cell1 = grdScannedCNB.FooterRow.Cells[8];
                TableCell cell2 = grdScannedCNB.FooterRow.Cells[6];
                grdScannedCNB.FooterRow.Cells.RemoveAt(8);
                grdScannedCNB.FooterRow.Cells.RemoveAt(6);
                grdScannedCNB.FooterRow.Cells.AddAt(6, cell1);
                grdScannedCNB.FooterRow.Cells.AddAt(8, cell2);                
            }
            else
            {
                grdScannedCNB.Columns[6].Visible = false;
                grdScannedCNB.Columns[7].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }


    public void getScannedCNB()
    {
        try
        {
            DALScannedCNB objScannedCNB = new DALScannedCNB();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objScannedCNB.getScannedCNB(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("Startdate");
            dtnull.Columns.Add("Enddate");
            dtnull.Columns.Add("Util_type");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["ScannedCNBGrid"] = ds;
				grdScannedCNB.DataSource = ds;
                grdScannedCNB.DataBind();               
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["Startdate"] = null;
                d["Enddate"] = null;
                d["Util_type"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
				Session["ScannedCNBGrid"] = dtnull;
                grdScannedCNB.DataSource = dtnull;
                grdScannedCNB.DataBind();
                grdScannedCNB.Rows[0].Visible = false;
                grdScannedCNB.Rows[0].Controls.Clear();                
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewScannedCNB(object sender, EventArgs e)
    {
        //try
       // {
            DALScannedCNB objScannedCNB = new DALScannedCNB();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());


            DateTime startDate = Convert.ToDateTime(((TextBox)grdScannedCNB.FooterRow.FindControl("txtStartDate")).Text);
            DateTime EndDate = Convert.ToDateTime(((TextBox)grdScannedCNB.FooterRow.FindControl("txtEndDate")).Text);

            int Utilitytype = ((DropDownList)grdScannedCNB.FooterRow.FindControl("ddlUtility_type")).SelectedIndex;
        
            string CNB = ((TextBox)grdScannedCNB.FooterRow.FindControl("txtCNB")).Text;
            FileUpload fUpload = (FileUpload)grdScannedCNB.FooterRow.FindControl("FileUpload");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;
                
                    if (Utilitytype == 1)
                    {
                        if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Electric\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Electric\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }
                        else
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Electric\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Electric\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }
                    }
                    else if (Utilitytype == 2)
                    {
                        if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Gas\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Gas\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }
                        else
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Gas\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Gas\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;                        
                        }
                    }
                    else if (Utilitytype == 3)
                    {
                        if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Telecom\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Telecom\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }
                        else
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Telecom\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Telecom\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }
                    }
                    else if (Utilitytype == 4)
                    {
                        if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Water\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Water\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }
                        else
                        {
                            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Water\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Water\\") +
                            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                        }                    
                }                
            }
            grdScannedCNB.DataSource = objScannedCNB.InsertScannedCNB(Cust_id, CurrentFileName, CurrentFilePath, Create_User, startDate,EndDate,Utilitytype, CNB);
            grdScannedCNB.DataBind();
        //}
        //catch (Exception ex)
       // {
       //     ex.ToString();
       // }
       // finally
      //  { }
    }

    protected void UpdateScannedCNB(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALScannedCNB objScannedCNB = new DALScannedCNB();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdScannedCNB.Rows[e.RowIndex].FindControl("Id")).Text);

            DateTime startDate = Convert.ToDateTime(((TextBox)grdScannedCNB.Rows[e.RowIndex].FindControl("txtStartDate")).Text);
            DateTime EndDate = Convert.ToDateTime(((TextBox)grdScannedCNB.Rows[e.RowIndex].FindControl("txtEndDate")).Text);

            int Utilitytype = ((DropDownList)grdScannedCNB.Rows[e.RowIndex].FindControl("ddlUtility_type")).SelectedIndex;

            string CNB = ((TextBox)grdScannedCNB.Rows[e.RowIndex].FindControl("txtCNB")).Text;
            FileUpload fUpload = (FileUpload)grdScannedCNB.Rows[e.RowIndex].FindControl("FileUpload");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;

                if (Utilitytype == 1)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Electric\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Electric\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                    else
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Electric\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Electric\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                }
                else if (Utilitytype == 2)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Gas\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Gas\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                    else
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Gas\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Gas\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                }
                else if (Utilitytype == 3)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Telecom\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Telecom\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                    else
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Telecom\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Telecom\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                }
                else if (Utilitytype == 4)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Water\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Water\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                    else
                    {
                        fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Water\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Water\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
                    }
                }

            }
            grdScannedCNB.EditIndex = -1;
            grdScannedCNB.DataSource = objScannedCNB.UpdateScannedCNB(ID, Cust_id, CurrentFileName, CurrentFilePath, Update_User, startDate, EndDate, Utilitytype, CNB);
            grdScannedCNB.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditScannedCNB(object sender, GridViewEditEventArgs e)
    {
        grdScannedCNB.EditIndex = e.NewEditIndex;
        getScannedCNB();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdScannedCNB.EditIndex = -1;
        getScannedCNB();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {   
            LinkButton lnkRemove = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }

    protected void DeleteScannedCNB(object sender, EventArgs e)
    {
        try
        {
            DALScannedCNB objScannedCNB = new DALScannedCNB();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objScannedCNB.delScannedCNB(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("Startdate");
            dtnull.Columns.Add("Enddate");
            dtnull.Columns.Add("Util_type");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
				Session["ScannedCNBGrid"] = ds;
                grdScannedCNB.DataSource = ds;
                grdScannedCNB.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["Startdate"] = null;
                d["Enddate"] = null;
                d["Util_type"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
				Session["ScannedCNBGrid"] = dtnull;
                grdScannedCNB.DataSource = dtnull;
                grdScannedCNB.DataBind();
                grdScannedCNB.Rows[0].Visible = false;
                grdScannedCNB.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        grdScannedCNB.PageIndex = e.NewPageIndex;
        grdScannedCNB.DataSource = (DataSet)Session["ScannedCNBGrid"];
        grdScannedCNB.DataBind();
    }

    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowState == DataControlRowState.Edit || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Edit)))
            {
                DropDownList ddlUtility_type = (DropDownList)e.Row.FindControl("ddlUtility_type");
                ddlUtility_type.SelectedIndex = ddlUtility_type.Items.IndexOf(ddlUtility_type.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "Util_type").ToString()));
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }


}