﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class Sitecheck : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getSitecheck();         
        }
    }


    protected void grdSitecheck_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                grdSitecheck.Columns[4].Visible = true;
                grdSitecheck.Columns[5].Visible = true;
                TableCell cell1 = grdSitecheck.FooterRow.Cells[6];
                TableCell cell2 = grdSitecheck.FooterRow.Cells[4];
                grdSitecheck.FooterRow.Cells.RemoveAt(6);
                grdSitecheck.FooterRow.Cells.RemoveAt(4);
                grdSitecheck.FooterRow.Cells.AddAt(4, cell1);
                grdSitecheck.FooterRow.Cells.AddAt(6, cell2);                
            }
            else
            {
                grdSitecheck.Columns[4].Visible = false;
                grdSitecheck.Columns[5].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }


    public void getSitecheck()
    {
        try
        {
            DALSitecheck objSitecheck = new DALSitecheck();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSitecheck.getSitecheck(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("File_NameUser");
            dtnull.Columns.Add("File_PathUser");
            dtnull.Columns.Add("File_NameClient");
            dtnull.Columns.Add("File_PathClient");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSitecheck.DataSource = ds;
                grdSitecheck.DataBind();               
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["File_NameUser"] = null;
                d["File_PathUser"] = null;
                d["File_NameClient"] = null;
                d["File_PathClient"] = null;
                dtnull.Rows.Add(d);
                grdSitecheck.DataSource = dtnull;
                grdSitecheck.DataBind();
                grdSitecheck.Rows[0].Visible = false;
                grdSitecheck.Rows[0].Controls.Clear();                
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewSitecheck(object sender, EventArgs e)
    {
        try
        {
            DALSitecheck objSitecheck = new DALSitecheck();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            DateTime strDate = Convert.ToDateTime(((TextBox)grdSitecheck.FooterRow.FindControl("txtDate")).Text);

            
            FileUpload FileUploadUser = (FileUpload)grdSitecheck.FooterRow.FindControl("FileUploadUser");
            FileUpload FileUploadClient = (FileUpload)grdSitecheck.FooterRow.FindControl("FileUploadClient");
            
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePathUser = "", CurrentFileNameUser = "";
            string CurrentFilePathClient = "", CurrentFileNameClient = "";
                        
            DateTime dtNow = DateTime.Now;

            if (FileUploadUser.HasFile)
            {
                CurrentFileNameUser = FileUploadUser.FileName;
                FileUploadUser.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadUser.FileName);
                CurrentFilePathUser = HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadUser.FileName;
            }

            if (FileUploadClient.HasFile)
            {
                CurrentFileNameClient = FileUploadClient.FileName;
                FileUploadClient.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadClient.FileName);
                CurrentFilePathClient = HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadClient.FileName;
            }


            grdSitecheck.DataSource = objSitecheck.InsertSitecheck(Cust_id, CurrentFileNameUser, CurrentFilePathUser,CurrentFileNameClient,CurrentFilePathClient, Create_User, strDate);
            grdSitecheck.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateSitecheck(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALSitecheck objSitecheck = new DALSitecheck();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdSitecheck.Rows[e.RowIndex].FindControl("Id")).Text);

            DateTime strDate = Convert.ToDateTime(((TextBox)grdSitecheck.Rows[e.RowIndex].FindControl("txtDate")).Text);
            
            FileUpload FileUploadUser = (FileUpload)grdSitecheck.Rows[e.RowIndex].FindControl("FileUploadUser");
            FileUpload FileUploadClient = (FileUpload)grdSitecheck.Rows[e.RowIndex].FindControl("FileUploadClient");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePathUser = "", CurrentFileNameUser = "";
            string CurrentFilePathClient = "", CurrentFileNameClient = "";

            DateTime dtNow = DateTime.Now;

            if (FileUploadUser.HasFile)
            {
                CurrentFileNameUser = FileUploadUser.FileName;
                FileUploadUser.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadUser.FileName);
                CurrentFilePathUser = HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadUser.FileName;
            }

            if (FileUploadClient.HasFile)
            {
                CurrentFileNameClient = FileUploadClient.FileName;
                FileUploadClient.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadClient.FileName);
                CurrentFilePathClient = HttpContext.Current.Server.MapPath("PostedFiles\\SitecheckFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUploadClient.FileName;
            }

            grdSitecheck.EditIndex = -1;
            grdSitecheck.DataSource = objSitecheck.UpdateSitecheck(ID, Cust_id, CurrentFileNameUser, CurrentFilePathUser, CurrentFileNameClient, CurrentFilePathClient, Update_User, strDate);
            grdSitecheck.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditSitecheck(object sender, GridViewEditEventArgs e)
    {
        grdSitecheck.EditIndex = e.NewEditIndex;
        getSitecheck();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdSitecheck.EditIndex = -1;
        getSitecheck();
    }

    protected void ShowFilesUser(object sender, EventArgs e)

    {
        LinkButton lnkShowFileUser = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkShowFileUser.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkShowFileUser.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }


    protected void ShowFilesClient(object sender, EventArgs e)
    {
        LinkButton lnkShowFileClient = (LinkButton)sender;
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + lnkShowFileClient.Text);
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(lnkShowFileClient.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }

    protected void DeleteSitecheck(object sender, EventArgs e)
    {
        try
        {
            DALSitecheck objSitecheck = new DALSitecheck();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSitecheck.delSitecheck(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("File_NameUser");
            dtnull.Columns.Add("File_PathUser");
            dtnull.Columns.Add("File_NameClient");
            dtnull.Columns.Add("File_PathClient");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSitecheck.DataSource = ds;
                grdSitecheck.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["File_NameUser"] = null;
                d["File_PathUser"] = null;
                d["File_NameClient"] = null;
                d["File_PathClient"] = null;
                dtnull.Rows.Add(d);
                grdSitecheck.DataSource = dtnull;
                grdSitecheck.DataBind();
                grdSitecheck.Rows[0].Visible = false;
                grdSitecheck.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
    }


}