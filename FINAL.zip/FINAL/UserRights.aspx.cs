﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class UserRights : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {

            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getUserRights();

        }

    }


    public void getUserRights()
    {

        try
        {

            DALUserRights objMeetingHist = new DALUserRights();
            DataSet ds = new DataSet();

            ds = objMeetingHist.GetUserRights();

            grdUserRights.DataSource = ds.Tables[0];
            grdUserRights.DataBind();


        }
        catch (Exception ex)
        {
            ex.ToString();
        }



    }


    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

        try
        {

        getUserRights();
        grdUserRights.PageIndex = e.NewPageIndex;
        grdUserRights.DataBind();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }




    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {

          DALUserRights objMeetingHist = new DALUserRights();
          objMeetingHist.UpdateUserRights(hfUserRights.Value.ToString());
          getUserRights();

           // ScriptManager.RegisterStartupScript(this.Page, typeof(string), "javascript", "<script type='text/javascript' language='javascript'>alert('Hello');</script>", false);
        
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        }
    }
}