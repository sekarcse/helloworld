﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LOAAddNew : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            
        } 
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["Command"] = "cancel";
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "CancelLOAAddNew()", true);
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Session["Command"] = "save";
        try
        {
            DALLOA objLOA = new DALLOA();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);
            
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fileUploadScanImage.HasFile)
            {
                CurrentFileName = fileUploadScanImage.FileName;
                fileUploadScanImage.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\LOAFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadScanImage.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\LOAFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadScanImage.FileName;
            }
            objLOA.LOAAddNewInsertLOA(Cust_id, CurrentFileName, CurrentFilePath, Create_User, FromDate, ToDate);

            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveLOAAddNew()", true);

            string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

            // ASP.NET 2.0
            if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }        
    }
}