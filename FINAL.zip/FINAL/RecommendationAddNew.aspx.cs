﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RecommendationAddNew : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
    }




    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
        Session["CommandRecommendation"] = "save";
        try
        {
            DALRecommendation objRecommendation = new DALRecommendation();
            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            DateTime date_of_recommendation = Convert.ToDateTime(txtdate_of_recommendation.Text);
            int Recommendation = Convert.ToInt32(ddlrecommendation.SelectedIndex);

            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;




            int location_id = 0;
            if (Convert.ToString(txtlocation_id.Text.Trim()).Length > 0)
            {
                location_id = Convert.ToInt32(txtlocation_id.Text.Trim());
            }
            Decimal Saving_Refund = 0;
            if (Convert.ToString(txtSaving_Refund.Text.Trim()).Length > 0)
            {
                Saving_Refund = Convert.ToDecimal(txtSaving_Refund.Text.Trim());
            }
            DateTime date_expected = Convert.ToDateTime("1/1/1753");
            if (Convert.ToString(txtdate_expected.Text).Length == 10)
            {
                date_expected = Convert.ToDateTime(txtdate_expected.Text);
            }
            DateTime date_agreed_by_supplier = Convert.ToDateTime("1/1/1753");
            if (Convert.ToString(txtdate_agreed_by_supplier.Text).Length == 10)
            {
                date_agreed_by_supplier = Convert.ToDateTime(txtdate_agreed_by_supplier.Text);
            }
            DateTime date_billed_by_monarch = Convert.ToDateTime("1/1/1753");
            if (Convert.ToString(txtdate_billed_by_monarch.Text).Length == 10)
            {
                date_billed_by_monarch = Convert.ToDateTime(txtdate_billed_by_monarch.Text);
            }




            if (FileUpload.HasFile)
            {
                CurrentFileName = FileUpload.FileName;
                FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\RecommendationFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\RecommendationFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
            }
            objRecommendation.RecommendationAddNewInsertHistoryRecommendation(Cust_id, date_of_recommendation, CurrentFileName, CurrentFilePath, Recommendation, Create_User, location_id, Saving_Refund, date_expected, date_agreed_by_supplier, date_billed_by_monarch);

            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveRecommendationAddNew()", true);

            string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

            // ASP.NET 2.0
            if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Dashboard History Recommendation", "btnSave_Click", ex.Message);
        }
    }  




}