﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class SoldSites : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_load(object sender, EventArgs e)

    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getSoldSites();         
        }
    }


    protected void grdSoldSites_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdSoldSites.Columns[3].Visible = true;
                grdSoldSites.Columns[4].Visible = true;
                TableCell cell1 = grdSoldSites.FooterRow.Cells[5];
                TableCell cell2 = grdSoldSites.FooterRow.Cells[3];
                grdSoldSites.FooterRow.Cells.RemoveAt(5);
                grdSoldSites.FooterRow.Cells.RemoveAt(3);
                grdSoldSites.FooterRow.Cells.AddAt(3, cell1);
                grdSoldSites.FooterRow.Cells.AddAt(5, cell2);
                //grdSoldSites.Columns[5].Visible = false;
            }
            else
            {
                grdSoldSites.Columns[3].Visible = false;
                grdSoldSites.Columns[4].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getSoldSites()
    {
        try
        {
            DALSoldSites objSoldSites = new DALSoldSites();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSoldSites.getSoldSites(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSoldSites.DataSource = ds;
                grdSoldSites.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdSoldSites.DataSource = dtnull;
                grdSoldSites.DataBind();
                grdSoldSites.Rows[0].Visible = false;
                grdSoldSites.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewSoldSites(object sender, EventArgs e)
    {
        try
        {
            DALSoldSites objSoldSites = new DALSoldSites();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            DateTime Contract_Renewal_Date = Convert.ToDateTime(((TextBox)grdSoldSites.FooterRow.FindControl("txtContract_Renewal_Date")).Text);
            
            FileUpload fUpSoldSitesd = (FileUpload)grdSoldSites.FooterRow.FindControl("FileUpSoldSitesd");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpSoldSitesd.HasFile)
            {                
                CurrentFileName = fUpSoldSitesd.FileName;
                fUpSoldSitesd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SoldSitesFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSoldSitesd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\SoldSitesFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSoldSitesd.FileName;
            }
            grdSoldSites.DataSource = objSoldSites.InsertSoldSites(Cust_id, CurrentFileName, CurrentFilePath, Create_User, Contract_Renewal_Date);
            grdSoldSites.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateSoldSites(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALSoldSites objSoldSites = new DALSoldSites();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdSoldSites.Rows[e.RowIndex].FindControl("Id")).Text);

            DateTime SoldSitesDate = Convert.ToDateTime(((TextBox)grdSoldSites.Rows[e.RowIndex].FindControl("txtContract_Renewal_Date")).Text);

            FileUpload fUpSoldSitesd = (FileUpload)grdSoldSites.Rows[e.RowIndex].FindControl("FileUpSoldSitesd");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpSoldSitesd.HasFile)
            {
                CurrentFileName = fUpSoldSitesd.FileName;
                fUpSoldSitesd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SoldSitesFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSoldSitesd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\SoldSitesFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSoldSitesd.FileName;
            }
            grdSoldSites.EditIndex = -1;
            grdSoldSites.DataSource = objSoldSites.UpdateSoldSites(ID, Cust_id, CurrentFileName, CurrentFilePath, Update_User, SoldSitesDate);
            grdSoldSites.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditSoldSites(object sender, GridViewEditEventArgs e)
    {
        grdSoldSites.EditIndex = e.NewEditIndex;
        getSoldSites();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdSoldSites.EditIndex = -1;
        getSoldSites();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {   
            LinkButton lnkRemove = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }

    protected void DeleteSoldSites(object sender, EventArgs e)
    {
        try
        {
            DALSoldSites objSoldSites = new DALSoldSites();

            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSoldSites.delSoldSites(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSoldSites.DataSource = ds;
                grdSoldSites.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdSoldSites.DataSource = dtnull;
                grdSoldSites.DataBind();
                grdSoldSites.Rows[0].Visible = false;
                grdSoldSites.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
    }


}