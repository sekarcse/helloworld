﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class LineLossCodes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            BindLLCsData();
        }
    }

    public void BindLLCsData()
    {
        try
        {
            DALHHSTariff objBindLLCsData = new DALHHSTariff();
            DataSet ds = new DataSet();
            ds = objBindLLCsData.BindLLCsData();           

            if (ds.Tables.Count > 0)
            {
                grdLLCs.DataSource = ds;
                grdLLCs.DataBind();
            }            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "LineLossCodes", "BindLLCsData", ex.Message);
        }
    }

}