﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class AcceptanceLetters : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getAcceptanceLetter();         
        }
    }


    protected void grdAcceptanceLetter_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdAcceptanceLetter.Columns[4].Visible = true;
                grdAcceptanceLetter.Columns[5].Visible = true;
                TableCell cell1 = grdAcceptanceLetter.FooterRow.Cells[6];
                TableCell cell2 = grdAcceptanceLetter.FooterRow.Cells[4];
                grdAcceptanceLetter.FooterRow.Cells.RemoveAt(6);
                grdAcceptanceLetter.FooterRow.Cells.RemoveAt(4);
                grdAcceptanceLetter.FooterRow.Cells.AddAt(4, cell1);
                grdAcceptanceLetter.FooterRow.Cells.AddAt(6, cell2);
                //grdAcceptanceLetter.Columns[5].Visible = false;
            }
            else
            {
                grdAcceptanceLetter.Columns[4].Visible = false;
                grdAcceptanceLetter.Columns[5].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getAcceptanceLetter()
    {
        try
        {
            DALAcceptanceLetter objAcceptanceLetter = new DALAcceptanceLetter();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objAcceptanceLetter.getAcceptanceLetter(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAcceptanceLetter.DataSource = ds;
                grdAcceptanceLetter.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdAcceptanceLetter.DataSource = dtnull;
                grdAcceptanceLetter.DataBind();
                grdAcceptanceLetter.Rows[0].Visible = false;
                grdAcceptanceLetter.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewAcceptanceLetter(object sender, EventArgs e)
    {
        try
        {
            DALAcceptanceLetter objAcceptanceLetter = new DALAcceptanceLetter();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            
            DateTime Contract_Renewal_Date = Convert.ToDateTime(((TextBox)grdAcceptanceLetter.FooterRow.FindControl("txtContract_Renewal_Date")).Text);
            string CNB = ((TextBox)grdAcceptanceLetter.FooterRow.FindControl("txtCNB")).Text;
            FileUpload fUpAcceptanceLetterd = (FileUpload)grdAcceptanceLetter.FooterRow.FindControl("FileUpAcceptanceLetterd");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpAcceptanceLetterd.HasFile)
            {                
                CurrentFileName = fUpAcceptanceLetterd.FileName;
                fUpAcceptanceLetterd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\AcceptanceLetterFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpAcceptanceLetterd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\AcceptanceLetterFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpAcceptanceLetterd.FileName;
            }
            grdAcceptanceLetter.DataSource = objAcceptanceLetter.InsertAcceptanceLetter(Cust_id, CurrentFileName, CurrentFilePath, Create_User, Contract_Renewal_Date, CNB);
            grdAcceptanceLetter.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateAcceptanceLetter(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALAcceptanceLetter objAcceptanceLetter = new DALAcceptanceLetter();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdAcceptanceLetter.Rows[e.RowIndex].FindControl("Id")).Text);
            string CNB = ((TextBox)grdAcceptanceLetter.Rows[e.RowIndex].FindControl("txtCNB")).Text;
            DateTime AcceptanceLetterDate = Convert.ToDateTime(((TextBox)grdAcceptanceLetter.Rows[e.RowIndex].FindControl("txtContract_Renewal_Date")).Text);
            FileUpload fUpAcceptanceLetterd = (FileUpload)grdAcceptanceLetter.Rows[e.RowIndex].FindControl("FileUpAcceptanceLetterd");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpAcceptanceLetterd.HasFile)
            {
                CurrentFileName = fUpAcceptanceLetterd.FileName;
                fUpAcceptanceLetterd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\AcceptanceLetterFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpAcceptanceLetterd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\AcceptanceLetterFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpAcceptanceLetterd.FileName;
            }
            grdAcceptanceLetter.EditIndex = -1;
            grdAcceptanceLetter.DataSource = objAcceptanceLetter.UpdateAcceptanceLetter(ID, Cust_id, CurrentFileName, CurrentFilePath, Update_User, AcceptanceLetterDate, CNB);
            grdAcceptanceLetter.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditAcceptanceLetter(object sender, GridViewEditEventArgs e)
    {
        grdAcceptanceLetter.EditIndex = e.NewEditIndex;
        getAcceptanceLetter();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdAcceptanceLetter.EditIndex = -1;
        getAcceptanceLetter();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {   
            LinkButton lnkRemove = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }

    protected void DeleteAcceptanceLetter(object sender, EventArgs e)
    {
        try
        {
            DALAcceptanceLetter objAcceptanceLetter = new DALAcceptanceLetter();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objAcceptanceLetter.delAcceptanceLetter(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAcceptanceLetter.DataSource = ds;
                grdAcceptanceLetter.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdAcceptanceLetter.DataSource = dtnull;
                grdAcceptanceLetter.DataBind();
                grdAcceptanceLetter.Rows[0].Visible = false;
                grdAcceptanceLetter.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
    }


}