﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;

public partial class Recommendation : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getRecommendation();
        }
        else
        {
            if (Convert.ToString(Session["CommandRecommendation"]) == "save")
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");
                getRecommendation();
                Session["CommandRecommendation"] = string.Empty;
            }
        }
    }


    protected void grdRecommendation_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                //Changes when we add/remove any columns in GridView Starts
                grdRecommendation.Columns[9].Visible = true;
                grdRecommendation.Columns[10].Visible = true;
                //Changes when we add/remove any columns in GridView Ends

                TableCell cell1 = grdRecommendation.FooterRow.Cells[6];
                TableCell cell2 = grdRecommendation.FooterRow.Cells[4];
                grdRecommendation.FooterRow.Cells.RemoveAt(6);
                grdRecommendation.FooterRow.Cells.RemoveAt(4);
                grdRecommendation.FooterRow.Cells.AddAt(4, cell1);
                grdRecommendation.FooterRow.Cells.AddAt(6, cell2);
            }
            else
            {
                //Changes when we add/remove any columns in GridView Starts
                grdRecommendation.Columns[9].Visible = false;
                grdRecommendation.Columns[10].Visible = false;
                //Changes when we add/remove any columns in GridView Ends
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getRecommendation()
    {
        try
        {
            DALRecommendation objRecommendation = new DALRecommendation();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objRecommendation.getHistoryRecommendation(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("location_id");
            dtnull.Columns.Add("date_of_recommendation");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");
            dtnull.Columns.Add("Saving_Refund");
            //dtnull.Columns.Add("Recommendation");
            dtnull.Columns.Add("RecommendationDDLValue");

            dtnull.Columns.Add("date_expected");
            dtnull.Columns.Add("date_agreed_by_supplier");
            dtnull.Columns.Add("date_billed_by_monarch");


            if (ds.Tables.Count > 0)
            {
                Session["RecommendationGrid"] = ds;
                grdRecommendation.DataSource = ds;
                grdRecommendation.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["location_id"] = null;
                d["date_of_recommendation"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                d["Saving_Refund"] = null;
                //d["Recommendation"] = null;
                d["RecommendationDDLValue"] = null;

                d["date_expected"] = null;
                d["date_agreed_by_supplier"] = null;
                d["date_billed_by_monarch"] = null;

                dtnull.Rows.Add(d);
                Session["RecommendationGrid"] = dtnull;
                grdRecommendation.DataSource = dtnull;
                grdRecommendation.DataBind();
                grdRecommendation.Rows[0].Visible = false;
                grdRecommendation.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    protected void UpdateContact(object sender, GridViewUpdateEventArgs e)
    {
        DALRecommendation objRecommendation = new DALRecommendation();
        string ID = ((Label)grdRecommendation.Rows[e.RowIndex].FindControl("Id")).Text;

        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        DateTime date_of_recommendation = Convert.ToDateTime(((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtdate_of_recommendation")).Text);

        int Recommendation = ((DropDownList)grdRecommendation.Rows[e.RowIndex].FindControl("ddlrecommendation")).SelectedIndex;

        FileUpload fUpload = (FileUpload)grdRecommendation.Rows[e.RowIndex].FindControl("FileUpload");
        string Update_User = Session["UserName"].ToString();

        string CurrentFilePath = "", CurrentFileName = "";
        DateTime dtNow = DateTime.Now;

        
        
        int location_id = Convert.ToInt32(((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtlocation_id")).Text);
        Decimal Saving_Refund = Convert.ToDecimal(((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtSaving_Refund")).Text);
        DateTime date_expected = Convert.ToDateTime(((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtdate_expected")).Text);
        DateTime date_agreed_by_supplier = Convert.ToDateTime(((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtdate_agreed_by_supplier")).Text);

        //Changes for handling null values for DateTime Starts
        DateTime date_billed_by_monarch = Convert.ToDateTime("1/1/1753");
        if (((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtDateBilledByMonarch")).Text.Length == 10)
        {
            date_billed_by_monarch = Convert.ToDateTime(((TextBox)grdRecommendation.Rows[e.RowIndex].FindControl("txtDateBilledByMonarch")).Text);
        }
        //Changes for handling null values for DateTime Ends
        


        if (fUpload.HasFile)
        {
            CurrentFileName = fUpload.FileName;
            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\RecommendationFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\RecommendationFiles\\") +
            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
        }

        grdRecommendation.EditIndex = -1;
        grdRecommendation.DataSource = objRecommendation.UpdateHistoryRecommendation(Convert.ToInt32(ID), Cust_id, date_of_recommendation, CurrentFileName, CurrentFilePath, Recommendation, Update_User, location_id, Saving_Refund, date_expected, date_agreed_by_supplier, date_billed_by_monarch);
        grdRecommendation.DataBind();

    }


    protected void EditContact(object sender, GridViewEditEventArgs e)
    {
        grdRecommendation.EditIndex = e.NewEditIndex;
        getRecommendation();
    }


    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdRecommendation.EditIndex = -1;
        getRecommendation();
    }

    protected void DeleteContact(object sender, EventArgs e)
    {
        DALRecommendation objRecommendation = new DALRecommendation();


        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        LinkButton lnkRemove = (LinkButton)sender;
        grdRecommendation.DataSource = objRecommendation.delHistoryRecommendation(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);
        getRecommendation();
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        grdRecommendation.PageIndex = e.NewPageIndex;
        grdRecommendation.DataSource = (DataSet)Session["RecommendationGrid"];
        grdRecommendation.DataBind();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {
        LinkButton lnkRemove = (LinkButton)sender;
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }



    protected void grdRecommendation_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {            
            if (e.Row.RowState == DataControlRowState.Edit || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Edit)))
            {
                DropDownList ddlrecommendation = (DropDownList)e.Row.FindControl("ddlrecommendation");
                ddlrecommendation.SelectedIndex = ddlrecommendation.Items.IndexOf(ddlrecommendation.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "RecommendationDDLValue").ToString()));
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

}