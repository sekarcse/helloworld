﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DynamicMessages : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string strName = "";
        
        if (!IsPostBack)
        {

            if (Request.QueryString["value"] != null && Request.QueryString["value"].ToString().Equals("RegisterUsersSuccessfully"))
            {                             
                lblMessage.Text = "User added successfully";
            }
            else if (Request.QueryString["value"] != null && Request.QueryString["value"].ToString().Equals("Accessdenied"))
            {
                lblMessage.Text = "Access denied";
            }
            else if (Request.QueryString["value"] != null && Request.QueryString["value"].ToString().Equals("Invaliduser"))
            {
                lblMessage.Text = "Invalid user or password";
            }
            else
            {
                lblMessage.Text = strName;
            }
            

        }

    }
}