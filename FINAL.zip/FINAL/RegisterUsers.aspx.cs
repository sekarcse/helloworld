﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Account_RegisterUsers : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {

            if (!this.IsPostBack)
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }

    protected void CreateUserButton_Click(object sender, EventArgs e)
    {   
        
       DALUserRegistration objUserRegistration = new DALUserRegistration();
       DALLogin objLogin = new DALLogin();                
       string strPassword = (string)objLogin.getMd5Hash(txtPassword.Text.Trim());
       bool bRegistration;
       bRegistration = objUserRegistration.RegisterUser(txtUserName.Text.TrimEnd(), strPassword, txtFirstName.Text.TrimEnd(), txtSurName.Text.TrimEnd(), Convert.ToInt32(ddlRoleID.SelectedValue), txtEmail.Text.TrimEnd());
       if (bRegistration)
       {
           System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Script", "CallMessage();", true);
       }
       else
       {

       }
    }



   private void ClearTextBoxes()
{
	
       
       
    ContentPlaceHolder content = default(ContentPlaceHolder);

	//get a reference to the masterfile's 
	//Content place holder object.

	//the string "contentPlaceHolder1" is the name of the 
	//content place holder in master page


    content = (ContentPlaceHolder)Page.Master.FindControl("MainContent"); 

	Panel mypanel = default(Panel);

	//get a reference to panel object that is in 
	//the ASPX page associated with the master page.

    mypanel = (Panel)content.FindControl("pnlBody");

	
	//for loop to get controls in the ASPX page 
	foreach(Control ctl in mypanel.Controls) 
        {
		TextBox tb = default(TextBox);
		CheckBox CBL = default(CheckBox);
		CheckBoxList cblist = default(CheckBoxList);
        DropDownList ddl = default(DropDownList);

		//If control is text Box then reset it. (clear) 

		    if (ctl is TextBox) {
			    tb = (TextBox)ctl;
			    tb.Text = string.Empty;
		    }

		//If control is check box then reset it. (uncheck it)

		    else if (ctl is CheckBox) {
			    CBL = (CheckBox)ctl;
			    CBL.Checked = false;
		    }

		//If control is check box list then reset it.
		//(uncheck it)

            else if (ctl is CheckBoxList)
            {
                cblist = (CheckBoxList)ctl;
                cblist.Controls.Clear();
            }

            else if (ctl is DropDownList)
            {
                ddl = (DropDownList)ctl;
                ddl.SelectedIndex = 0;
            }


        }
	}
}






