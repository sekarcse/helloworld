﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Security.Cryptography;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }    
    
    protected void CreateUserButton_Click(object sender, EventArgs e)
    {
        
        DALLogin objLogin = new DALLogin();
        DataSet ds = new DataSet();

        try
        {
            ds = objLogin.LoginCheck(txtUserName.Text.ToString().Trim(), objLogin.getMd5Hash(txtPassword.Text.ToString().Trim()));
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["UserName"] = ds.Tables[0].Rows[0]["username"].ToString();
                Session["RoleID"] = ds.Tables[0].Rows[0]["role_id"].ToString();
                if (Convert.ToInt32(Session["RoleID"].ToString()) > 3)
                {
                    lblMessage.Text = "Access denied";
                }
                else
                {
                    Response.Redirect("default.aspx");
                }
            }
            else
            {
                lblMessage.Text = "Invalid username or password";
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        
        }



    }
}
    