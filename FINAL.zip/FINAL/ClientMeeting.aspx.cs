﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class ClientMeeting : System.Web.UI.Page
{

    DALSetup objsetup = new DALSetup();
    DALTariff objTariff = new DALTariff();
    DALLogin objLogin = new DALLogin();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");
            getAllData();
            Session["CHECKED_ITEMS"] = null;
        }
    }

    public void getAllData()
    {  
        
        ddlVenue.DataSource = objsetup.getAllVenue();
        ddlVenue.DataTextField = "Name";
        ddlVenue.DataValueField = "VenueID";
        ddlVenue.DataBind();
        ddlVenue.Items.Insert(0, "--Select--");

        ddlAuthorisedBy.DataSource = objLogin.getAllUsers();
        ddlAuthorisedBy.DataTextField = "name";
        ddlAuthorisedBy.DataValueField = "username";
        ddlAuthorisedBy.DataBind();
        ddlAuthorisedBy.Items.Insert(0, "--Select--");
        
        ddlMonarchUser.DataSource = objLogin.getAllUsers();
        ddlMonarchUser.DataTextField = "name";
        ddlMonarchUser.DataValueField = "username";
        ddlMonarchUser.DataBind();
        ddlMonarchUser.Items.Insert(0, "--Select--");

        ddlMeetingCalledBy.DataSource = objsetup.getMeetingCalledBy();
        ddlMeetingCalledBy.DataTextField = "Name";
        ddlMeetingCalledBy.DataValueField = "ID";
        ddlMeetingCalledBy.DataBind();
        ddlMeetingCalledBy.Items.Insert(0, "--Select--");

        txt_enddate.Text = DateTime.Now.ToShortDateString();
        dllCustomers.Items.Insert(0, "--Select--");
        ddlClientActionPerson.Items.Insert(0, "--Select--");

        grdMonarchAttendees.DataSource = objLogin.getAllUsers();
        grdMonarchAttendees.DataBind();

        grdMeetingResult.DataSource = objsetup.getMeetingResult();
        grdMeetingResult.DataBind();

        grdMeetingPurpose.DataSource = objsetup.getMeetingPurpose();
        grdMeetingPurpose.DataBind();

        grdMonarchAction.DataSource = objsetup.getAllActions();
        grdMonarchAction.DataBind();

        grdClientAction.DataSource = objsetup.getAllActions();
        grdClientAction.DataBind();      
    }

    private void RememberOldValues()
    {
        try
        {
        ArrayList categoryIDList = new ArrayList();
        string index = "";
        foreach (GridViewRow row in grdMonarchAttendees.Rows)
        {
            index = (string)grdMonarchAttendees.DataKeys[row.RowIndex].Value;
            bool result = ((CheckBox)row.FindControl("cb")).Checked;

            // Check in the Session
            if (Session["CHECKED_ITEMS"] != null)
                categoryIDList = (ArrayList)Session["CHECKED_ITEMS"];
            if (result)
            {
                if (!categoryIDList.Contains(index))
                    categoryIDList.Add(index);
            }
            else
                categoryIDList.Remove(index);
        }
        if (categoryIDList != null && categoryIDList.Count > 0)
            Session["CHECKED_ITEMS"] = categoryIDList;
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    private void RePopulateValues()
    {
        ArrayList categoryIDList = (ArrayList)Session["CHECKED_ITEMS"];
        if (categoryIDList != null && categoryIDList.Count > 0)
        {
            foreach (GridViewRow row in grdMonarchAttendees.Rows)
            {
                string index = (string)grdMonarchAttendees.DataKeys[row.RowIndex].Value;
                if (categoryIDList.Contains(index))
                {
                    CheckBox myCheckBox = (CheckBox)row.FindControl("cb");
                    myCheckBox.Checked = true;
                }
            }
        }
    }



    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            RememberOldValues();
            grdMonarchAttendees.DataSource = objLogin.getAllUsers();
            grdMonarchAttendees.PageIndex = e.NewPageIndex;
            grdMonarchAttendees.DataBind();
            RePopulateValues();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    //private void SortListBox(ListBox lb1)
    //{
    //    List<ListItem> t = new List<ListItem>();
    //    Comparison<ListItem> compare = new Comparison<ListItem>(CompareListItems);
    //    foreach (ListItem lbItem in lb1.Items)
    //        t.Add(lbItem);

    //    t.Sort(compare);
    //    lb1.Items.Clear();
    //    lb1.Items.AddRange(t.ToArray());

    //}

    //int CompareListItems(ListItem li1, ListItem li2)
    //{
    //    return String.Compare(li1.Value, li2.Value);
    //}  

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        
        try
        {            
            DALMeetingHist objMeetHist = new DALMeetingHist();
            string CurrentFilePath = "", CurrentFileName = "";

            if (FileUpload.HasFile)
            {
                CurrentFileName = FileUpload.FileName;
                FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\MeetingHistory\\") + FileUpload.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\MeetingHistory\\") +
                FileUpload.FileName;
            }

            // - To get values from Monarch Attendees Grid 
            CheckBox chkMonarchAttendees = new CheckBox();
            Label lblchkMonarchAttendees = new Label();
            string strMonarchAttendees = "";
            foreach (GridViewRow oItem in grdMonarchAttendees.Rows)
            {
                chkMonarchAttendees = (CheckBox)oItem.FindControl("cb");
                if (chkMonarchAttendees.Checked)
                {
                    lblchkMonarchAttendees = (Label)oItem.FindControl("lblID");
                    strMonarchAttendees = strMonarchAttendees + lblchkMonarchAttendees.Text.Trim() + ',';
                }
            }
            //strMonarchAttendees = strMonarchAttendees.ToString().Substring(0, strMonarchAttendees.Length - 1);

            // - To get values from Other Attendees Grid 
            CheckBox chkOtherAttendees = new CheckBox();
            Label lblOtherAttendees = new Label();
            string strOtherAttendees = "";
            foreach (GridViewRow oItem in grdOtherAttendees.Rows)
            {
                chkOtherAttendees = (CheckBox)oItem.FindControl("cb");
                if (chkOtherAttendees.Checked)
                {
                    lblOtherAttendees = (Label)oItem.FindControl("lblID");
                    strOtherAttendees = strOtherAttendees + lblOtherAttendees.Text.Trim() + ',';
                }
            }
            //strOtherAttendees = strOtherAttendees.ToString().Substring(0, strOtherAttendees.Length - 1);

            // - To get values from Meeting Purpose Grid 
            CheckBox chkPurpose = new CheckBox();
            Label lblPurpose = new Label();
            string strPurpose = "";
            foreach (GridViewRow oItem in grdMeetingPurpose.Rows)
            {
                chkPurpose = (CheckBox)oItem.FindControl("cb");
                if (chkPurpose.Checked)
                {
                    lblPurpose = (Label)oItem.FindControl("lblID");
                    strPurpose = strPurpose + lblPurpose.Text.Trim() + ',';
                }
            }
           // strPurpose = strPurpose.ToString().Substring(0, strPurpose.Length - 1);

            // - To get values from Meeting Result Grid 
            CheckBox chkResult = new CheckBox();
            Label lblResult = new Label();
            string strResult = "";
            foreach (GridViewRow oItem in grdMeetingResult.Rows)
            {
                chkResult = (CheckBox)oItem.FindControl("cb");
                if (chkResult.Checked)
                {
                    lblResult = (Label)oItem.FindControl("lblID");
                    strResult = strResult + lblResult.Text.Trim() + ',';
                }
            }
            //strResult = strResult.ToString().Substring(0, strResult.Length - 1);            

            // - To get values from Monarch Action Grid 
            CheckBox chkMonarchAction = new CheckBox();
            Label lblMonarchAction = new Label();
            string strMonarchAction = "";
            foreach (GridViewRow oItem in grdMonarchAction.Rows)
            {
                chkMonarchAction = (CheckBox)oItem.FindControl("cb");
                if (chkMonarchAction.Checked)
                {
                    lblMonarchAction = (Label)oItem.FindControl("lblID");
                    strMonarchAction = strMonarchAction + lblMonarchAction.Text.Trim() + ',';
                }
            }
            //strMonarchAction = strMonarchAction.ToString().Substring(0, strMonarchAction.Length - 1);


            // - To get values from Other Action Grid 
            CheckBox chkOtherAction = new CheckBox();
            Label lblOtherAction = new Label();
            string strOtherAction = "";
            foreach (GridViewRow oItem in grdClientAction.Rows)
            {
                chkOtherAction = (CheckBox)oItem.FindControl("cb");
                if (chkOtherAction.Checked)
                {
                    lblOtherAction = (Label)oItem.FindControl("lblID");
                    strOtherAction = strOtherAction + lblOtherAction.Text.Trim() + ',';
                }
            }
            //strOtherAction = strOtherAction.ToString().Substring(0, strOtherAction.Length - 1);            

            int MeetingCalledBy_Id = Convert.ToInt32(ddlMeetingCalledBy.SelectedValue);
            
            int CalledBy_Id = 0;            
            CalledBy_Id = Convert.ToInt32(dllCustomers.SelectedValue);         
            int VenueID = Convert.ToInt32(ddlVenue.SelectedValue);
            string AuthorisedBy = ddlAuthorisedBy.SelectedValue.ToString();
            DateTime dtMeetingDate = Convert.ToDateTime(txt_enddate.Text);                     
            string ClientAction_PersonName = Convert.ToString(ddlClientActionPerson.SelectedItem.ToString());            
            string MonarchAction_PersonName = Convert.ToString(ddlMonarchUser.SelectedValue);            
            string FileName = CurrentFileName;
            string FilePath = CurrentFilePath;
            string MeetingMinutes = Server.HtmlEncode(txtMinuteofMeeting.Text);
            string Create_User = Session["UserName"].ToString();

            objMeetHist.AddMeetingHistory(MeetingCalledBy_Id, CalledBy_Id, "", VenueID, AuthorisedBy, dtMeetingDate, strMonarchAttendees, strOtherAttendees, strPurpose, strResult, ClientAction_PersonName, strOtherAction, MonarchAction_PersonName, strMonarchAction, FileName, FilePath, MeetingMinutes, Create_User);
            Response.Redirect("ViewClientMeetings.aspx");            

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {

        }

    }


    protected void ddlMeetingCalledBy_SelectedIndexChanged(object sender, EventArgs e)
    {   

        if (ddlMeetingCalledBy.SelectedValue == "2")
        {

            dllCustomers.Items.Clear();
            dllCustomers.DataSource = objTariff.getCustomers();
            dllCustomers.DataTextField = "company_name";
            dllCustomers.DataValueField = "customer_id";
            dllCustomers.DataBind();
            dllCustomers.Items.Insert(0, "--Select--");

        }
        else if (ddlMeetingCalledBy.SelectedValue == "6")
        {


            dllCustomers.Items.Clear();
            dllCustomers.DataSource = objTariff.getSuppliers();
            dllCustomers.DataTextField = "supplier_name";
            dllCustomers.DataValueField = "supplier_id";
            dllCustomers.DataBind();
            dllCustomers.Items.Insert(0, "--Select--");

        }
        else if (ddlMeetingCalledBy.SelectedValue == "--Select--")
        {
            dllCustomers.Items.Clear();
            dllCustomers.Items.Insert(0, "--Select--");
        }
        else
        {
            dllCustomers.Items.Clear();
            dllCustomers.DataSource = objsetup.getCalledby(Convert.ToInt16(ddlMeetingCalledBy.SelectedValue));
            dllCustomers.DataTextField = "name";
            dllCustomers.DataValueField = "id";
            dllCustomers.DataBind();
            dllCustomers.Items.Insert(0, "--Select--");
        }


    }
    protected void dllCustomers_SelectedIndexChanged(object sender, EventArgs e)
    {

        ClientListValues();

    }


    public void ClientListValues()
    {

        
        DALClientAttendees objClientAttend = new DALClientAttendees();
        DataSet ds = new DataSet();

        int MeetingCalledBy = 0;
        int ClientsID = 0;

        if (ddlMeetingCalledBy.SelectedIndex != 0)
            MeetingCalledBy = Convert.ToInt16(ddlMeetingCalledBy.SelectedValue);

        if (dllCustomers.SelectedIndex != 0)
            ClientsID = Convert.ToInt16(dllCustomers.SelectedValue);

        ds = objClientAttend.getClientAttendees(ClientsID, MeetingCalledBy);

        DataTable dtnull = new DataTable();
        dtnull.Columns.Add("ID");
        dtnull.Columns.Add("Name");
        dtnull.Columns.Add("Designation");       


        ddlClientActionPerson.Items.Clear();
        ddlClientActionPerson.DataSource = ds;
        ddlClientActionPerson.DataTextField = "Name";
        ddlClientActionPerson.DataValueField = "Name";
        ddlClientActionPerson.DataBind();
        ddlClientActionPerson.Items.Insert(0, "--Select--");

        grdOtherAttendees.DataSource = ds;
        grdOtherAttendees.DataBind();       

    }

    //protected void lstClientForward_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (lstClientMain.SelectedIndex > -1)
    //        {
    //            ArrayList arr = new ArrayList();
    //            int j = 0;
    //            int count = 0;
    //            for (int i = 0; i <= lstClientMain.Items.Count - 1; i++)
    //            {
    //                if (lstClientMain.Items[i].Selected)
    //                {
    //                    lstClientSelect.Items.Add(new ListItem(lstClientMain.Items[i].Text, lstClientMain.Items[i].Value));
    //                    count = count + 1;
    //                    arr.Add(lstClientMain.Items.IndexOf(lstClientMain.Items[i]));
    //                }
    //            }
    //            for (j = count - 1; j >= 0; j--)
    //            {
    //                int k = Convert.ToInt32(arr[j].ToString());
    //                lstClientMain.Items.RemoveAt(k);
    //            }
    //            SortListBox(lstClientSelect);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ex.ToString();
    //    }
    //}
    //protected void lstClientBack_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (lstClientSelect.SelectedIndex > -1)
    //        {
    //            ArrayList arr = new ArrayList();
    //            int j = 0;
    //            int count = 0;
    //            for (int i = 0; i <= lstClientSelect.Items.Count - 1; i++)
    //            {
    //                if (lstClientSelect.Items[i].Selected)
    //                {
    //                    lstClientMain.Items.Add(new ListItem(lstClientSelect.Items[i].Text, lstClientSelect.Items[i].Value));
    //                    count = count + 1;
    //                    arr.Add(lstClientSelect.Items.IndexOf(lstClientSelect.Items[i]));
    //                }
    //            }
    //            for (j = count - 1; j >= 0; j--)
    //            {
    //                int k = Convert.ToInt32(arr[j].ToString());
    //                lstClientSelect.Items.RemoveAt(k);
    //            }
    //            SortListBox(lstClientMain);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ex.ToString();
    //    }
    //}


    //protected void lstClientSelectCheck(Object sender, ServerValidateEventArgs args)
    //{

    //    try
    //    {

    //        args.IsValid = (lstClientSelect.Items.Count == 0)? false : true;

    //    }
    //    catch (Exception ex)
    //    {
    //        ex.ToString();
    //    }
    //    finally
    //    {        
    //    }       
    //}
    
    
}