﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class DistributionIDs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            BindDistributionIDsData();
        }
    }

    public void BindDistributionIDsData()
    {
        try
        {
            DALHHSTariff objBindDistributionIDsData = new DALHHSTariff();
            DataSet ds = new DataSet();
            ds = objBindDistributionIDsData.BindDistributionIDsData();

            if (ds.Tables.Count > 0)
            {
                grdDistributionIDs.DataSource = ds;
                grdDistributionIDs.DataBind();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "DistributionIDs", "BindDistributionIDsData", ex.Message);
        }
    }
}