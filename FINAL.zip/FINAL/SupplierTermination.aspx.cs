﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class SupplierTermination : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getSupplierTermination();         
        }
    }


    protected void grdSupplierTermination_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdSupplierTermination.Columns[4].Visible = true;
                grdSupplierTermination.Columns[5].Visible = true;
                TableCell cell1 = grdSupplierTermination.FooterRow.Cells[6];
                TableCell cell2 = grdSupplierTermination.FooterRow.Cells[4];
                grdSupplierTermination.FooterRow.Cells.RemoveAt(6);
                grdSupplierTermination.FooterRow.Cells.RemoveAt(4);
                grdSupplierTermination.FooterRow.Cells.AddAt(4, cell1);
                grdSupplierTermination.FooterRow.Cells.AddAt(6, cell2);
                //grdSupplierTermination.Columns[5].Visible = false;
            }
            else
            {
                grdSupplierTermination.Columns[4].Visible = false;
                grdSupplierTermination.Columns[5].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getSupplierTermination()
    {
        try
        {
            DALSupplierTermination objSupplierTermination = new DALSupplierTermination();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSupplierTermination.getSupplierTermination(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSupplierTermination.DataSource = ds;
                grdSupplierTermination.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdSupplierTermination.DataSource = dtnull;
                grdSupplierTermination.DataBind();
                grdSupplierTermination.Rows[0].Visible = false;
                grdSupplierTermination.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewSupplierTermination(object sender, EventArgs e)
    {
        try
        {
            DALSupplierTermination objSupplierTermination = new DALSupplierTermination();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            
            DateTime Contract_Renewal_Date = Convert.ToDateTime(((TextBox)grdSupplierTermination.FooterRow.FindControl("txtContract_Renewal_Date")).Text);            

            string CNB = ((TextBox)grdSupplierTermination.FooterRow.FindControl("txtCNB")).Text;
            FileUpload fUpSupplierTerminationd = (FileUpload)grdSupplierTermination.FooterRow.FindControl("FileUpSupplierTerminationd");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpSupplierTerminationd.HasFile)
            {                
                CurrentFileName = fUpSupplierTerminationd.FileName;
                fUpSupplierTerminationd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SupplierTerminationFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSupplierTerminationd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\SupplierTerminationFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSupplierTerminationd.FileName;
            }
            grdSupplierTermination.DataSource = objSupplierTermination.InsertSupplierTermination(Cust_id, CurrentFileName, CurrentFilePath, Create_User, Contract_Renewal_Date, CNB);            
            grdSupplierTermination.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateSupplierTermination(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALSupplierTermination objSupplierTermination = new DALSupplierTermination();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdSupplierTermination.Rows[e.RowIndex].FindControl("Id")).Text);

            DateTime SupplierTerminationDate = Convert.ToDateTime(((TextBox)grdSupplierTermination.Rows[e.RowIndex].FindControl("txtContract_Renewal_Date")).Text);
            
            string CNB = ((TextBox)grdSupplierTermination.Rows[e.RowIndex].FindControl("txtCNB")).Text;
            FileUpload fUpSupplierTerminationd = (FileUpload)grdSupplierTermination.Rows[e.RowIndex].FindControl("FileUpSupplierTerminationd");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpSupplierTerminationd.HasFile)
            {
                CurrentFileName = fUpSupplierTerminationd.FileName;
                fUpSupplierTerminationd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SupplierTerminationFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSupplierTerminationd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\SupplierTerminationFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSupplierTerminationd.FileName;
            }
            grdSupplierTermination.EditIndex = -1;
            grdSupplierTermination.DataSource = objSupplierTermination.UpdateSupplierTermination(ID, Cust_id, CurrentFileName, CurrentFilePath, Update_User, SupplierTerminationDate, CNB);
            grdSupplierTermination.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditSupplierTermination(object sender, GridViewEditEventArgs e)
    {
        grdSupplierTermination.EditIndex = e.NewEditIndex;
        getSupplierTermination();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdSupplierTermination.EditIndex = -1;
        getSupplierTermination();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {   
            LinkButton lnkRemove = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }

    protected void DeleteSupplierTermination(object sender, EventArgs e)
    {
        try
        {
            DALSupplierTermination objSupplierTermination = new DALSupplierTermination();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSupplierTermination.delSupplierTermination(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSupplierTermination.DataSource = ds;
                grdSupplierTermination.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdSupplierTermination.DataSource = dtnull;
                grdSupplierTermination.DataBind();
                grdSupplierTermination.Rows[0].Visible = false;
                grdSupplierTermination.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
    }


}