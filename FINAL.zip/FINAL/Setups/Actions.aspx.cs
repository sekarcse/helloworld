﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Setups_Actions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            
                if (Session["RoleID"] == null)
                    Response.Redirect("../login.asp");
            
            getAction();

        }

    }


    public void getAction()
    {

        try
        {

            DALSetup objsetup = new DALSetup();
            DataSet ds = new DataSet();

            ds = objsetup.getAllActions();

            grdAction.DataSource = ds;
            grdAction.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }

    protected void AddNewAction(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        string Name = ((TextBox)grdAction.FooterRow.FindControl("txtName")).Text;
        string Desc = ((TextBox)grdAction.FooterRow.FindControl("txtDescription")).Text;

        grdAction.DataSource = objsetup.InsertActions(Name, Desc);
        grdAction.DataBind();

    }

    protected void UpdateAction(object sender, GridViewUpdateEventArgs e)
    {


        DALSetup objsetup = new DALSetup();


        string ID = ((Label)grdAction.Rows[e.RowIndex].FindControl("lblVenueID")).Text;
        string Name = ((TextBox)grdAction.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)grdAction.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        grdAction.EditIndex = -1;

        grdAction.DataSource = objsetup.UpdateActions(Convert.ToInt32(ID), Name, Desc);
        grdAction.DataBind();


    }

    protected void EditAction(object sender, GridViewEditEventArgs e)
    {

        grdAction.EditIndex = e.NewEditIndex;
        getAction();

    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {

        grdAction.EditIndex = -1;
        getAction();

    }


    protected void DeleteAction(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        LinkButton lnkRemove = (LinkButton)sender;
        grdAction.DataSource = objsetup.DelActions(Convert.ToInt32(lnkRemove.CommandArgument));
        grdAction.DataBind();

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }

}