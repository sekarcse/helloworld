﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class CalledBy : System.Web.UI.Page
{
    
    DALSetup objsetup = new DALSetup();
    DALTariff objTariff = new DALTariff();

    protected void Page_Load(object sender, EventArgs e)
    {      

        if (!IsPostBack)
        {
            if (Session["RoleID"] == null)
                    Response.Redirect("../login.asp");
            getValues();            
        }
    }


    public void getValues()
    {
        try
        {           

            DataSet ds = new DataSet();
            ds = objsetup.getMeetingCalledBy();            
            
            foreach (DataRow dr in ds.Tables[0].Rows)		            
                    {
			        if (dr["ID"].ToString() == "2")
				    dr.Delete();
                    else if (dr["ID"].ToString() == "6")
                    dr.Delete();
		            }

		    ds.Tables[0].AcceptChanges();
            
            ddlMeetingCalledBy.DataSource = ds;
            ddlMeetingCalledBy.DataTextField = "Name";
            ddlMeetingCalledBy.DataValueField = "ID";
            ddlMeetingCalledBy.DataBind();
            ddlMeetingCalledBy.Items.Insert(0, "--Select--");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        
        }
    }


    public void getAttendees()
    {
        try
        {

            DALSetup objsetup = new DALSetup();
            DataSet ds = new DataSet();

            ds = objsetup.getAllActions();

            grdCalledBy.DataSource = ds;
            grdCalledBy.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewAction(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
        DALSetup objCalledby = new DALSetup();
        string Name = ((TextBox)grdCalledBy.FooterRow.FindControl("txtName")).Text;
        string Desc = ((TextBox)grdCalledBy.FooterRow.FindControl("txtDescription")).Text;        
        int MeetingCalledById = Convert.ToInt16(ddlMeetingCalledBy.SelectedValue);
        grdCalledBy.DataSource = objCalledby.InsertCalledBy(MeetingCalledById, Name, Desc);
        grdCalledBy.DataBind();
        }
    }

    protected void UpdateAction(object sender, GridViewUpdateEventArgs e)
    {
        DALSetup objCalledby = new DALSetup();

        string ID = ((Label)grdCalledBy.Rows[e.RowIndex].FindControl("lblVenueID")).Text;
        string Name = ((TextBox)grdCalledBy.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)grdCalledBy.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        grdCalledBy.EditIndex = -1;

        grdCalledBy.DataSource = objCalledby.UpdateCalledBy(Convert.ToInt32(ID), Convert.ToInt16(ddlMeetingCalledBy.SelectedValue), Name, Desc);
        grdCalledBy.DataBind();
    }

    protected void EditAction(object sender, GridViewEditEventArgs e)
    {
        grdCalledBy.EditIndex = e.NewEditIndex;
        GridValues();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCalledBy.EditIndex = -1;
        GridValues();
    }


    protected void DeleteAction(object sender, EventArgs e)
    {
        DALSetup objCalledby = new DALSetup();
        LinkButton lnkRemove = (LinkButton)sender;
        grdCalledBy.DataSource = objCalledby.DelCalledby(Convert.ToInt32(lnkRemove.CommandArgument), Convert.ToInt16(ddlMeetingCalledBy.SelectedValue));
        grdCalledBy.DataBind();
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }

    protected void ddlMeetingCalledBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridValues();
    }
    
    public void GridValues() 
    {

        grdCalledBy.Visible = true;
        DALSetup objCalledby = new DALSetup();
            DataSet ds = new DataSet();

            int MeetingCalledBy = 0;

            if (ddlMeetingCalledBy.SelectedIndex != 0)
                MeetingCalledBy = Convert.ToInt16(ddlMeetingCalledBy.SelectedValue);
            else
            {
                grdCalledBy.Visible = false;
                return;
            }

            ds = objCalledby.getCalledby(MeetingCalledBy);            

            DataTable dtnull = new DataTable();
            dtnull.Columns.Add("ID");
            dtnull.Columns.Add("Name");
            dtnull.Columns.Add("Description");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdCalledBy.DataSource = ds;
                grdCalledBy.DataBind();
            }
            else 
            {
                DataRow d = dtnull.NewRow();
                d["ID"] = 0;
                d["Name"] = null;
                d["Description"] = null;
                dtnull.Rows.Add(d);
                grdCalledBy.DataSource = dtnull;
                grdCalledBy.DataBind();
                grdCalledBy.Rows[0].Visible = false;
                grdCalledBy.Rows[0].Controls.Clear();
            }
    }

}