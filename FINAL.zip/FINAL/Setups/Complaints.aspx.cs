﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Setups_Complaints : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            
                if (Session["RoleID"] == null)
                    Response.Redirect("../login.asp");
            
           //getAction();

        }

    }


    public void getAction()
    {

        try
        {

            DALSetup objsetup = new DALSetup();
            DataSet ds = new DataSet();

            int OptionCode = 0;

            if (ddlCategory.SelectedIndex != 0)
                OptionCode = Convert.ToInt16(ddlCategory.SelectedValue);
            else
            {
                grdComplaint_Nature.Visible = false;
                return;
            }

            grdComplaint_Nature.Visible = true;
            ds = objsetup.getComplaint_Nature(OptionCode);


            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("OptionCode");
            dtnull.Columns.Add("Name");
            dtnull.Columns.Add("Description");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdComplaint_Nature.DataSource = ds;
                grdComplaint_Nature.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["OptionCode"] = null;
                d["Name"] = null;
                d["Description"] = null;                
                dtnull.Rows.Add(d);
                grdComplaint_Nature.DataSource = dtnull;
                grdComplaint_Nature.DataBind();
                grdComplaint_Nature.Rows[0].Visible = false;
                grdComplaint_Nature.Rows[0].Controls.Clear();
            }

            
        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }

    protected void AddNewComplaint_Nature(object sender, EventArgs e)
    {

        if (Page.IsValid)
        {
            DALSetup objsetup = new DALSetup();

            string Name = ((TextBox)grdComplaint_Nature.FooterRow.FindControl("txtName")).Text;
            string Desc = ((TextBox)grdComplaint_Nature.FooterRow.FindControl("txtDescription")).Text;

            int OptionCode = 0;
            if (ddlCategory.SelectedIndex != 0)
                OptionCode = Convert.ToInt16(ddlCategory.SelectedValue);

            grdComplaint_Nature.DataSource = objsetup.InsertComplaint_Nature(Name, Desc, OptionCode);
            grdComplaint_Nature.DataBind();
        }

    }

    protected void UpdateComplaint_Nature(object sender, GridViewUpdateEventArgs e)
    {


        DALSetup objsetup = new DALSetup();


        string ID = ((Label)grdComplaint_Nature.Rows[e.RowIndex].FindControl("lblVenueID")).Text;
        string Name = ((TextBox)grdComplaint_Nature.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)grdComplaint_Nature.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        int OptionCode = 0;
        if (ddlCategory.SelectedIndex != 0)
            OptionCode = Convert.ToInt16(ddlCategory.SelectedValue);

        grdComplaint_Nature.EditIndex = -1;

        grdComplaint_Nature.DataSource = objsetup.UpdateComplaint_Nature(Convert.ToInt32(ID), Name, Desc, OptionCode);
        grdComplaint_Nature.DataBind();


    }

    protected void EditComplaint_Nature(object sender, GridViewEditEventArgs e)
    {

        grdComplaint_Nature.EditIndex = e.NewEditIndex;
        getAction();

    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {

        grdComplaint_Nature.EditIndex = -1;
        getAction();

    }


    protected void DeleteComplaint_Nature(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();


        int OptionCode = 0;
        if (ddlCategory.SelectedIndex != 0)
            OptionCode = Convert.ToInt16(ddlCategory.SelectedValue);

        LinkButton lnkRemove = (LinkButton)sender;
        grdComplaint_Nature.DataSource = objsetup.DelComplaint_Nature(Convert.ToInt32(lnkRemove.CommandArgument), OptionCode);
        grdComplaint_Nature.DataBind();

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }


    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        getAction();
    }

    protected void grdComplaint_Nature_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (ddlCategory.SelectedIndex == 1)
            {             
                grdComplaint_Nature.Columns[1].HeaderText = "Satisfaction";
            }
            else if (ddlCategory.SelectedIndex == 2)
            {                
                grdComplaint_Nature.Columns[1].HeaderText = "Complaint";
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }
}