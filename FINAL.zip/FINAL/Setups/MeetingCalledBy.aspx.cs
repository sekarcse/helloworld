﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;


public partial class Setups_MeetingCalledBy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            if (Session["RoleID"] == null)
                Response.Redirect("../login.asp");
            getMeetingCalledBy();

        }

    }

    public void getMeetingCalledBy()
    {

        try
        {

            DALSetup objsetup = new DALSetup();
            DataSet ds = new DataSet();

            ds = objsetup.getMeetingCalledBy();

            grdMeetingCalledBy.DataSource = ds;
            grdMeetingCalledBy.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }

    protected void AddNewgrdMeetingCalledBy(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        string Name = ((TextBox)grdMeetingCalledBy.FooterRow.FindControl("txtName")).Text;
        string Desc = ((TextBox)grdMeetingCalledBy.FooterRow.FindControl("txtDescription")).Text;

        grdMeetingCalledBy.DataSource = objsetup.InsertMeetingCalledBy(Name, Desc);
        grdMeetingCalledBy.DataBind();

    }

    protected void UpdategrdMeetingCalledBy(object sender, GridViewUpdateEventArgs e)
    {


        DALSetup objsetup = new DALSetup();


        string ID = ((Label)grdMeetingCalledBy.Rows[e.RowIndex].FindControl("lblVenueID")).Text;
        string Name = ((TextBox)grdMeetingCalledBy.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)grdMeetingCalledBy.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        grdMeetingCalledBy.EditIndex = -1;

        grdMeetingCalledBy.DataSource = objsetup.UpdateMeetingCalledBy(Convert.ToInt32(ID), Name, Desc);
        grdMeetingCalledBy.DataBind();


    }

    protected void EditgrdMeetingCalledBy(object sender, GridViewEditEventArgs e)
    {

        grdMeetingCalledBy.EditIndex = e.NewEditIndex;
        getMeetingCalledBy();

    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {

        grdMeetingCalledBy.EditIndex = -1;
        getMeetingCalledBy();

    }


    protected void DeletegrdMeetingCalledBy(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        LinkButton lnkRemove = (LinkButton)sender;
        grdMeetingCalledBy.DataSource = objsetup.DeleteMeetingCalledby(Convert.ToInt32(lnkRemove.CommandArgument));
        grdMeetingCalledBy.DataBind();

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }

}