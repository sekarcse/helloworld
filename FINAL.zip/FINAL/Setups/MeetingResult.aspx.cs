﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Setups_MeetingResult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("../login.asp");
            getMeetingResult();

        }

    }


    public void getMeetingResult()
    {

        DALSetup objsetup = new DALSetup();
        DataSet ds = new DataSet();

        ds = objsetup.getMeetingResult();

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }


    protected void AddNewCustomer(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        string Name = ((TextBox)GridView1.FooterRow.FindControl("txtName")).Text;
        string Desc = ((TextBox)GridView1.FooterRow.FindControl("txtDescription")).Text;

        GridView1.DataSource = objsetup.InsertMeetingResult(Name, Desc);
        GridView1.DataBind();

    }

    protected void UpdateCustomer(object sender, GridViewUpdateEventArgs e)
    {


        DALSetup objsetup = new DALSetup();


        string ID = ((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text;
        string Name = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        GridView1.EditIndex = -1;

        GridView1.DataSource = objsetup.UpdateMeetingResult(Convert.ToInt32(ID), Name, Desc);
        GridView1.DataBind();


    }

    protected void EditCustomer(object sender, GridViewEditEventArgs e)
    {

        GridView1.EditIndex = e.NewEditIndex;
        getMeetingResult();

    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {

        GridView1.EditIndex = -1;
        getMeetingResult();

    }


    protected void DeleteCustomer(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        LinkButton lnkRemove = (LinkButton)sender;
        GridView1.DataSource = objsetup.DelMeetingResult(Convert.ToInt32(lnkRemove.CommandArgument));
        GridView1.DataBind();

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }

}