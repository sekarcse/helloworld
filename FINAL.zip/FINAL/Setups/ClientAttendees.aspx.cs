﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class ClientAttendees_Actions : System.Web.UI.Page
{
    
    DALSetup objsetup = new DALSetup();
    DALTariff objTariff = new DALTariff();

    protected void Page_Load(object sender, EventArgs e)
    {

        

        if (!IsPostBack)
        {            
         
            if (Session["RoleID"] == null)
                    Response.Redirect("../login.asp");

            getValues();
            //getAttendees();
            
        }

    }


    public void getValues()
    {
        try
        {

            DataSet ds = new DataSet();
            ds = objsetup.getMeetingCalledBy();


            //foreach (DataRow dr in ds.Tables[0].Rows)
            //{
            //    if (dr["ID"].ToString() != "2" && dr["ID"].ToString() != "6")
            //        dr.Delete();
            //}
            //ds.Tables[0].AcceptChanges();
            
            ddlMeetingCalledBy.DataSource = ds;
            ddlMeetingCalledBy.DataTextField = "Name";
            ddlMeetingCalledBy.DataValueField = "ID";
            ddlMeetingCalledBy.DataBind();
            ddlMeetingCalledBy.Items.Insert(0, "--Select--");

            ddlClients.Items.Insert(0, "--Select--");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        
        }
    }


    public void getAttendees()
    {

        try
        {

            DALSetup objsetup = new DALSetup();
            DataSet ds = new DataSet();

            ds = objsetup.getAllActions();

            grdAttendees.DataSource = ds;
            grdAttendees.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }

    protected void AddNewAction(object sender, EventArgs e)
    {

        DALClientAttendees objClientAttend = new DALClientAttendees();

        string Name = ((TextBox)grdAttendees.FooterRow.FindControl("txtName")).Text;
        string Desc = ((TextBox)grdAttendees.FooterRow.FindControl("txtDescription")).Text;
        int ClientID = Convert.ToInt16(ddlClients.SelectedValue);
        int MeetingCalledById = Convert.ToInt16(ddlMeetingCalledBy.SelectedValue);

        grdAttendees.DataSource = objClientAttend.InsertClientAttendees(ClientID,MeetingCalledById,Name, Desc);
        grdAttendees.DataBind();

    }

    protected void UpdateAction(object sender, GridViewUpdateEventArgs e)
    {

        DALClientAttendees objsetup = new DALClientAttendees();

        string ID = ((Label)grdAttendees.Rows[e.RowIndex].FindControl("lblVenueID")).Text;
        string Name = ((TextBox)grdAttendees.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)grdAttendees.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        grdAttendees.EditIndex = -1;

        grdAttendees.DataSource = objsetup.UpdateClientAttendees(Convert.ToInt32(ID),Convert.ToInt16(ddlClients.SelectedValue),Convert.ToInt16(ddlMeetingCalledBy.SelectedValue), Name, Desc);
        grdAttendees.DataBind();


    }


    protected void grdAttendees_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                grdAttendees.Columns[3].Visible = true;
                TableCell cell1 = grdAttendees.FooterRow.Cells[5];
                TableCell cell2 = grdAttendees.FooterRow.Cells[3];
                grdAttendees.FooterRow.Cells.RemoveAt(5);
                grdAttendees.FooterRow.Cells.RemoveAt(3);
                grdAttendees.FooterRow.Cells.AddAt(3, cell1);
                grdAttendees.FooterRow.Cells.AddAt(5, cell2);
            }
            else
            {
                grdAttendees.Columns[3].Visible = false;
                TableCell cell1 = grdAttendees.FooterRow.Cells[5];
                TableCell cell2 = grdAttendees.FooterRow.Cells[4];
                grdAttendees.FooterRow.Cells.RemoveAt(5);
                //GridView1.FooterRow.Cells.RemoveAt(3);
                grdAttendees.FooterRow.Cells.AddAt(4, cell1);
                grdAttendees.FooterRow.Cells.AddAt(5, cell2);
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }

    protected void EditAction(object sender, GridViewEditEventArgs e)
    {

        grdAttendees.EditIndex = e.NewEditIndex;
        GridValues();

    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {

        grdAttendees.EditIndex = -1;
        GridValues();

    }


    protected void DeleteAction(object sender, EventArgs e)
    {

        DALClientAttendees objsetup = new DALClientAttendees();
        LinkButton lnkRemove = (LinkButton)sender;
        grdAttendees.DataSource = objsetup.DelClientAttendees(Convert.ToInt32(lnkRemove.CommandArgument),Convert.ToInt16(ddlClients.SelectedValue),Convert.ToInt16(ddlMeetingCalledBy.SelectedValue));
        grdAttendees.DataBind();

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }



    protected void ddlMeetingCalledBy_SelectedIndexChanged(object sender, EventArgs e)
    {       


        if (ddlMeetingCalledBy.SelectedValue == "2")
        {

            ddlClients.Items.Clear();
            ddlClients.DataSource = objTariff.getCustomers();
            ddlClients.DataTextField = "company_name";
            ddlClients.DataValueField = "customer_id";
            ddlClients.DataBind();
            ddlClients.Items.Insert(0, "--Select--");

        }
        else if (ddlMeetingCalledBy.SelectedValue == "6")
        {


            ddlClients.Items.Clear();
            ddlClients.DataSource = objTariff.getSuppliers();
            ddlClients.DataTextField = "supplier_name";
            ddlClients.DataValueField = "supplier_id";
            ddlClients.DataBind();
            ddlClients.Items.Insert(0, "--Select--");

        }
        else if (ddlMeetingCalledBy.SelectedValue == "--Select--")
        {
            ddlClients.Items.Clear();
            ddlClients.Items.Insert(0, "--Select--");
        }
        else 
        {
            ddlClients.Items.Clear();
            ddlClients.DataSource = objsetup.getCalledby(Convert.ToInt16(ddlMeetingCalledBy.SelectedValue));
            ddlClients.DataTextField = "name";
            ddlClients.DataValueField = "id";
            ddlClients.DataBind();
            ddlClients.Items.Insert(0, "--Select--");
        }

        grdAttendees.Visible = false;
    }


    protected void ddlClients_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            GridValues();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    public void GridValues() 
    {

        grdAttendees.Visible = true;
            DALClientAttendees objClientAttend = new DALClientAttendees();
            DataSet ds = new DataSet();

            int MeetingCalledBy = 0;
            int ClientsID = 0;

            if (ddlMeetingCalledBy.SelectedIndex != 0)
                MeetingCalledBy = Convert.ToInt16(ddlMeetingCalledBy.SelectedValue);

            if (ddlClients.SelectedIndex != 0)
                ClientsID = Convert.ToInt16(ddlClients.SelectedValue);

            ds = objClientAttend.getClientAttendees(ClientsID,MeetingCalledBy);            

            DataTable dtnull = new DataTable();
            dtnull.Columns.Add("ID");
            dtnull.Columns.Add("Name");
            dtnull.Columns.Add("Designation");

            if (ds.Tables[0].Rows.Count != 0)
            {

                grdAttendees.DataSource = ds;
                grdAttendees.DataBind();

            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["ID"] = 0;
                d["Name"] = null;
                d["Designation"] = null;
                dtnull.Rows.Add(d);
                grdAttendees.DataSource = dtnull;
                grdAttendees.DataBind();
                grdAttendees.Rows[0].Visible = false;
                grdAttendees.Rows[0].Controls.Clear();
            }

}






}