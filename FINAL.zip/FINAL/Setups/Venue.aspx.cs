﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Setups_Venue : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        
        if (!IsPostBack)
        {   
            if (Session["RoleID"] == null)
                Response.Redirect("../login.asp");
            getAllVenue();

        }

    }

    public void getAllVenue()
    {

        try
        {

        DALSetup objsetup = new DALSetup();
        DataSet ds = new DataSet();

        ds = objsetup.getAllVenue();    
        
        DataTable dtnull = new DataTable();     
        dtnull.Columns.Add("VenueID"); 
        dtnull.Columns.Add("Name"); 
        dtnull.Columns.Add("Description"); 
    
       if (ds.Tables[0].Rows.Count != 0)
       {
           
           GridView1.DataSource = ds; 
           GridView1.DataBind(); 
       
       } 
       else 
       {  
            
            DataRow d = dtnull.NewRow();
            d["VenueID"] = 0;
            d["Name"] = null;
            d["Description"] = null;            
            dtnull.Rows.Add(d); 
            GridView1.DataSource = dtnull; 
            GridView1.DataBind(); 
            GridView1.Rows[0].Visible = false; 
            GridView1.Rows[0].Controls.Clear(); 
        }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }


    }


    protected void AddNewCustomer(object sender, EventArgs e)
    {
        
        DALSetup objsetup = new DALSetup();
        
        string Name = ((TextBox)GridView1.FooterRow.FindControl("txtName")).Text;
        string Desc = ((TextBox)GridView1.FooterRow.FindControl("txtDescription")).Text;

        GridView1.DataSource = objsetup.InsertVenue(Name, Desc);
        GridView1.DataBind();

        

    }


    protected void GridView1_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                GridView1.Columns[3].Visible = true;
                TableCell cell1 = GridView1.FooterRow.Cells[5];
                TableCell cell2 = GridView1.FooterRow.Cells[3];
                GridView1.FooterRow.Cells.RemoveAt(5);
                GridView1.FooterRow.Cells.RemoveAt(3);
                GridView1.FooterRow.Cells.AddAt(3, cell1);
                GridView1.FooterRow.Cells.AddAt(5, cell2);
            }
            else
            {
                GridView1.Columns[3].Visible = false;
                TableCell cell1 = GridView1.FooterRow.Cells[5];
                TableCell cell2 = GridView1.FooterRow.Cells[4];
                GridView1.FooterRow.Cells.RemoveAt(5);
                //GridView1.FooterRow.Cells.RemoveAt(3);
                GridView1.FooterRow.Cells.AddAt(4, cell1);
                GridView1.FooterRow.Cells.AddAt(5, cell2);
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    protected void UpdateCustomer(object sender, GridViewUpdateEventArgs e)
    {


        DALSetup objsetup = new DALSetup();


        string VenueID = ((Label)GridView1.Rows[e.RowIndex].FindControl("lblVenueID")).Text;
        string Name = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtName")).Text;
        string Desc = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDescription")).Text;

        GridView1.EditIndex = -1;

        GridView1.DataSource = objsetup.UpdateVenue(Convert.ToInt32(VenueID), Name, Desc);
        GridView1.DataBind(); 

        
    }

    protected void EditCustomer(object sender, GridViewEditEventArgs e)
    {

        GridView1.EditIndex = e.NewEditIndex;
        getAllVenue();
    
    }   

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        
        GridView1.EditIndex = -1;
        getAllVenue();

    }


    protected void DeleteCustomer(object sender, EventArgs e)
    {

        DALSetup objsetup = new DALSetup();

        LinkButton lnkRemove = (LinkButton)sender;
        GridView1.DataSource = objsetup.DeleteVenue(Convert.ToInt32(lnkRemove.CommandArgument));
        GridView1.DataBind(); 

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }


}