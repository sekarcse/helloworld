﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class CommissionReport : System.Web.UI.Page
{


    string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

    static Int32 iValidData = 0;
    
    
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }




    /// <summary>
    /// Clicking the Validate button would load the Excel file to Grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnValidateCommissionReport_Click(object sender, EventArgs e)
    {
        try
        {
            //// Check to see if file was uploaded
            if (fileUploadCommissionReport.PostedFile != null)
            {
                //// Get a reference to PostedFile object
                HttpPostedFile myFile = fileUploadCommissionReport.PostedFile;

                //// Get the size of uploaded file
                int nFileLen = myFile.ContentLength;

                //// make sure the size of the file is > 0
                if (nFileLen > 0)
                {
                    //// Allocate a buffer for reading of the file
                    byte[] myData = new byte[nFileLen];

                    //// Read uploaded file from the Stream
                    myFile.InputStream.Read(myData, 0, nFileLen);

                    //// Create a name for the file to store
                    string strFilename = Path.GetFileName(myFile.FileName);

                    //// Write data into a file
                    String sWebServerFolderName = System.Configuration.ConfigurationManager.AppSettings["CommissionReportFolderName"].ToString();
                    WriteToFile(Server.MapPath("~\\" + sWebServerFolderName + "\\" + strFilename), ref myData);
                    Import_To_Grid(Server.MapPath("~\\" + sWebServerFolderName + "\\" + strFilename), ".xlsx", "true");

                    ////SSRS Reporting Starts
                    DisplayCommissionReport();
                    ////SSRS Reporting Ends

                }
            }
        }
        catch (Exception ex)
        {
            lblCommissionReportGridError.Text = "Error in excel file";
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Default", "btnValidateCommissionReport_Click", ex.Message);
        }
    }



    public void DisplayCommissionReport()
    {
        try
        {
            ////ReportViewer starts
            CommissionReportViewer.ServerReport.ReportServerCredentials =
                           new MyReportServerCredentials();


            string sReportServerURL = "http://monarchsql/reportserver";


            CommissionReportViewer.ProcessingMode = Microsoft.Reporting.WebForms.ProcessingMode.Remote;
            CommissionReportViewer.ServerReport.ReportServerUrl = new Uri(sReportServerURL);
            string sReportPath = "";
            sReportPath = "/Commission Report/New Commission Report";

            CommissionReportViewer.ServerReport.ReportPath = sReportPath;

            CommissionReportViewer.ShowParameterPrompts = false;
            CommissionReportViewer.ShowPromptAreaButton = false;
            CommissionReportViewer.LocalReport.Refresh();
            CommissionReportViewer.Visible = true;
            ////ReportViewer ends
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "CommissionReport", "DisplayCommissionReport", ex.Message);
        }
    }


    /// <summary>
    /// Writes the Excel file to the newly created file in Web Server Folder
    /// </summary>
    /// <param name="filepath"></param>
    /// <param name="Buffer"></param> 
    private void WriteToFile(string filepath, ref byte[] Buffer)
    {
        //// Create a file
        FileStream newFile = new FileStream(filepath, FileMode.Create);

        //// Write data to the file
        newFile.Write(Buffer, 0, Buffer.Length);

        //// Close file
        newFile.Close();
    }

    /// <summary>
    /// Import the file into the Grid
    /// </summary>
    /// <param name="FilePath"></param>
    /// <param name="Extension"></param>
    /// <param name="isHDR"></param>
    private void Import_To_Grid(string FilePath, string Extension, string isHDR)
    {
        string conStr = "";

        switch (Extension)
        {
            case ".xls": ////Excel 97-03
                conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                break;
            case ".xlsx": ////Excel 07
                conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                break;
        }

        conStr = String.Format(conStr, FilePath, isHDR);

        OleDbConnection connExcel = new OleDbConnection(conStr);
        OleDbCommand cmdExcel = new OleDbCommand();
        OleDbDataAdapter oda = new OleDbDataAdapter();

        DataTable dt = new DataTable();

        cmdExcel.Connection = connExcel;

        ////Get the name of First Sheet
        ////http://www.microsoft.com/en-us/download/confirmation.aspx?id=23734 -  install the following for 32 bit machine (King)
        ////http://www.microsoft.com/en-us/download/details.aspx?id=13255      -  install the following for 64 bit machine (Fileserver) [check]

        connExcel.Open();

        DataTable dtExcelSchema;
        dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
        string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
        connExcel.Close();

        ////Read Data from First Sheet
        connExcel.Open();
        cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
        oda.SelectCommand = cmdExcel;
        oda.Fill(dt);
        connExcel.Close();

        lblTariffGridHeading.Visible = true;
        lblFileName.Visible = true;
        lblCommissionReportGridError.Visible = true;
        
        
        ////btnImportAll.Enabled = true;        
        btnNewCommissionReportFileUpload.Visible = true;
        lblUploadCommissionReport.Visible = false;
        fileUploadCommissionReport.Visible = false;
        btnValidateCommissionReport.Visible = false;

        //// SQLBulkCopy starts
        //// To delete the existing records in Temp_CommissionReport starts - temp
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            SqlCommand cmdDelete = new SqlCommand(
                "DELETE FROM " +
                "Temp_CommissionReport;",
                connection);
            cmdDelete.ExecuteNonQuery();
            connection.Close();
        }
        //// To delete the existing records in Temp_CommissionReport ends - temp

        // Open a connection to the database. 
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            // Perform an initial count on the destination table.
            SqlCommand commandRowCount = new SqlCommand(
                "SELECT COUNT(*) FROM " +
                "Temp_CommissionReport;",
                connection);
            long countStart = System.Convert.ToInt32(
                commandRowCount.ExecuteScalar());
            // lblRecordsBeforeImport.Text = "Number of rows before import : " + countStart;            

            // Create a data table 
            //DataTable dtbulkcopy = dt;
            DataTable dtbulkcopy = new DataTable();
            dtbulkcopy = dt;
            DataColumn Import = dtbulkcopy.Columns.Add("Import", typeof(bool));
            Import.SetOrdinal(0);
            //dtbulkcopy.Columns.Add("ImportID", typeof(Int32));
            DataColumn ImportID = dtbulkcopy.Columns.Add("ImportID", typeof(Int32));
            ImportID.SetOrdinal(1);
            int iImportID = 0;
            foreach (DataRow dr in dtbulkcopy.Rows)
            {
                iImportID += 1;
                dr["Import"] = true;
                dr["ImportID"] = iImportID;

            }

            // Create the SqlBulkCopy object.  
            // Note that the column positions in the source DataTable  
            // match the column positions in the destination table so  
            // there is no need to map columns.  
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
            {
                bulkCopy.DestinationTableName = "Temp_CommissionReport";

                try
                {
                    // Write from the source to the destination.
                    bulkCopy.WriteToServer(dtbulkcopy);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            // Perform a final count on the destination  
            // table to see how many rows were added. 
            long countEnd = System.Convert.ToInt32(commandRowCount.ExecuteScalar());

            //// close the connection once imported
            connection.Close();
        }
        //// SQLBulkCopy ends

        lblFileName.Text = "Uploaded File Name : " + Path.GetFileName(FilePath);
        //// Populate data into Grid from the database table
        //BindData();
    }

    /// <summary>
    /// Populate data into Grid from the datatable starts
    /// </summary>
    /// <param name="FilePath"></param>
    private void BindData()
    {
        DataTable dtPoulateGrid = new DataTable();
        try
        {
            string sTariffTableName = "Temp_CommissionReport";
            dtPoulateGrid = TariffDetails(sTariffTableName);
            if (dtPoulateGrid != null)
            {
                Session["CommissionReportGrid"] = dtPoulateGrid;
                
                

                if (iValidData == 0)
                {
                    //btnImportAll.Enabled = true;
                }
                else
                {
                    //btnImportAll.Enabled = false;
                }
            }
        }
        catch (Exception ex)
        {
            lblCommissionReportGridError.Text = ex.ToString();
        }
    }

    /// <summary>
    /// Read the data from excel to data table.
    /// </summary>
    /// <param name="sTariffTableName"></param>
    /// <returns></returns>
    public DataTable TariffDetails(string sTariffTableName)
    {
        //// DBConnection is the web config name
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlDataAdapter daTariff = null;
        DataTable dtTariff = new DataTable();
        SqlCommand cmdTariff = new SqlCommand();

        try
        {
            cmdTariff.CommandType = CommandType.StoredProcedure;
            cmdTariff.CommandText = "SPGetTariffDetails";
            cmdTariff.Connection = conn;
            cmdTariff.Parameters.Add(new SqlParameter("@TariffTableName", sTariffTableName));
            daTariff = new SqlDataAdapter();
            daTariff.SelectCommand = cmdTariff;
            daTariff.Fill(dtTariff);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            daTariff.Dispose();
            cmdTariff.Dispose();
            conn.Close();
            conn.Dispose();
        }
        return dtTariff;
    }

    /// <summary>
    /// clear the grid and display the file upload screen
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnNewCommissionReportFileUpload_Click(object sender, EventArgs e)
    {
        lblTariffGridHeading.Visible = false;
        lblFileName.Visible = false;
        lblCommissionReportGridError.Visible = false;
        
        
        btnNewCommissionReportFileUpload.Visible = false;
        lblUploadCommissionReport.Visible = true;
        fileUploadCommissionReport.Visible = true;
        btnValidateCommissionReport.Visible = true;


        Response.Redirect("CommissionReport.aspx");


    }






}