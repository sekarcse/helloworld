﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;


public partial class ClientMeetingViewDetail : System.Web.UI.Page
{
    DALSetup objsetup = new DALSetup();
    DALTariff objTariff = new DALTariff();
    DALLogin objLogin = new DALLogin();
    DALMeetingHist objMeetingHist = new DALMeetingHist();
    DataSet ds = new DataSet();
    DataSet dsView = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            
            if (!IsPostBack)
            {

                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");

                //else if (Convert.ToInt16(Session["RoleID"]) == 1)
                //    btnAdd.Visible = true;
                //else
                //    btnAdd.Visible = false;

                getAllData(); 
                loadPageData();
            }
        }
    }


    public void loadPageData()
    {
        try
        {           
            
            string value = Request.QueryString["value"];            
            ds = objMeetingHist.ViewEditMeetingHistory(Convert.ToInt32(value));
            txt_enddate.Text = ds.Tables[0].Rows[0]["Meeting_date"].ToString();            
            txtMinuteofMeeting.Text = Server.HtmlDecode(ds.Tables[0].Rows[0]["MeetingMinutes"].ToString());
            ddlVenue.SelectedValue = ds.Tables[0].Rows[0]["Venue_id"].ToString();            
            ddlAuthorisedBy.SelectedValue = ds.Tables[0].Rows[0]["AuthorisedBy_Name"].ToString();
            ddlMonarchUser.SelectedValue = ds.Tables[0].Rows[0]["MonarchAction_PName"].ToString();            
            ddlMeetingCalledBy.SelectedValue = ds.Tables[0].Rows[0]["MeetingCalledBy_Id"].ToString();            
            hfFileName.Value = ds.Tables[0].Rows[0]["FileName"].ToString();
            hfFilePath.Value = ds.Tables[0].Rows[0]["FilePath"].ToString();
            lnkFile.Text = ds.Tables[0].Rows[0]["FileName"].ToString();

            if (lnkFile.Text == "")
                lnkFile.Visible = false;
            else
                lnkFile.Visible = true;


            getCalledby();

            if (ds.Tables[0].Rows[0]["MeetingCalledBy_Id"].ToString() == "2" || ds.Tables[0].Rows[0]["MeetingCalledBy_Id"].ToString() == "6")
            {
                dllCustomers.SelectedValue = ds.Tables[0].Rows[0]["CalledBy_Id"].ToString();
            }
            else
            {
                dllCustomers.SelectedValue = ds.Tables[0].Rows[0]["CalledBy_Id"].ToString();
            }

            ClientListValues();

            ddlClientActionPerson.SelectedValue = ds.Tables[0].Rows[0]["ClientAction_PersonName"].ToString();

            //RePopulateValues(grdMonarchAttendees, ds.Tables[0].Rows[0]["Attendees_Monrach"].ToString());
            //RePopulateValues(grdOtherAttendees,  ds.Tables[0].Rows[0]["Attendees_Client"].ToString());
            //RePopulateValues(grdMeetingPurpose, ds.Tables[0].Rows[0]["MeetingPurpose"].ToString());
            //RePopulateValues(grdMeetingResult, ds.Tables[0].Rows[0]["MeetingResult"].ToString());
            //RePopulateValues(grdMonarchAction, ds.Tables[0].Rows[0]["MonarchAction"].ToString());
            //RePopulateValues(grdClientAction, ds.Tables[0].Rows[0]["clientAction"].ToString());

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }

    public void getAllData()
    {

        ddlVenue.DataSource = objsetup.getAllVenue();
        ddlVenue.DataTextField = "Name";
        ddlVenue.DataValueField = "VenueID";
        ddlVenue.DataBind();
        ddlVenue.Items.Insert(0, "--Select--");       

        ddlAuthorisedBy.DataSource = objLogin.getAllUsers();
        ddlAuthorisedBy.DataTextField = "name";
        ddlAuthorisedBy.DataValueField = "username";
        ddlAuthorisedBy.DataBind();
        ddlAuthorisedBy.Items.Insert(0, "--Select--");

        ddlMonarchUser.DataSource = objLogin.getAllUsers();
        ddlMonarchUser.DataTextField = "name";
        ddlMonarchUser.DataValueField = "username";
        ddlMonarchUser.DataBind();
        ddlMonarchUser.Items.Insert(0, "--Select--");

        ddlMeetingCalledBy.DataSource = objsetup.getMeetingCalledBy();
        ddlMeetingCalledBy.DataTextField = "Name";
        ddlMeetingCalledBy.DataValueField = "ID";
        ddlMeetingCalledBy.DataBind();
        ddlMeetingCalledBy.Items.Insert(0, "--Select--");        
        

        txt_enddate.Text = DateTime.Now.ToShortDateString();
        dllCustomers.Items.Insert(0, "--Select--");

        string value = Request.QueryString["value"];        
        dsView = objMeetingHist.ViewMeetingHistory(Convert.ToInt32(value));

        if (dsView.Tables[0] != null)
                {
                    grdMonarchAttendees.DataSource = dsView.Tables[0];
                    grdMonarchAttendees.DataBind();
                }

        if (dsView.Tables[2] != null)
                {
                    grdMeetingResult.DataSource = dsView.Tables[2];
                    grdMeetingResult.DataBind();
                }

        if (dsView.Tables[3] != null)
                {
                    grdMeetingPurpose.DataSource = dsView.Tables[3];
                    grdMeetingPurpose.DataBind();
                }

        if (dsView.Tables[4] != null)
                {
                    grdMonarchAction.DataSource = dsView.Tables[4];
                    grdMonarchAction.DataBind();
                }

        if (dsView.Tables[5] != null)
                {
                    grdClientAction.DataSource = dsView.Tables[5];
                    grdClientAction.DataBind();
                }
    }


    private void RePopulateValues(GridView gv, string strComma)
    {           
        string[] strArray;
        strArray = strComma.Split(new char[] { ',' });

        for (int i = 0; i < strArray.Length; i++)        
        {
            foreach (GridViewRow row in gv.Rows)
            {
                Label lblName = (Label)row.FindControl("lblName");
                if (lblName.Text.ToString().Equals(strArray[i].ToString().TrimStart()))
                {
                    CheckBox myCheckBox = (CheckBox)row.FindControl("cb");
                    myCheckBox.Checked = true;
                    break;
                }
            }
        }
    }



    protected void lnkFile_Click(object sender, EventArgs e)

    {
        Response.ClearContent();

        Response.AddHeader("content-disposition", "attachment; filename=" + hfFileName.Value);

        Response.ContentType = "";


        FileStream MyFileStream;
        long FileSize;

        MyFileStream = new FileStream(hfFilePath.Value, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;

        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();

        Response.BinaryWrite(Buffer);

        Response.End();

    }

    private void SortListBox(ListBox lb1)
    {
        List<ListItem> t = new List<ListItem>();
        Comparison<ListItem> compare = new Comparison<ListItem>(CompareListItems);
        foreach (ListItem lbItem in lb1.Items)
            t.Add(lbItem);

        t.Sort(compare);
        lb1.Items.Clear();
        lb1.Items.AddRange(t.ToArray());

    }

    int CompareListItems(ListItem li1, ListItem li2)
    {
        return String.Compare(li1.Value, li2.Value);
    }   


    protected void btnAdd_Click(object sender, EventArgs e)
    {

        try
        {

            DALMeetingHist objMeetHist = new DALMeetingHist();

            string CurrentFilePath = "", CurrentFileName = "";

            if (FileUpload.HasFile)
            {

                CurrentFileName = FileUpload.FileName;

                FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\MeetingHistory\\") + FileUpload.FileName);

                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\MeetingHistory\\") +
                   FileUpload.FileName;
            }
            else if (lblFileUpload.Text != "") 
            {
                CurrentFileName = hfFileName.Value.ToString();
                CurrentFilePath = hfFilePath.Value.ToString();
            }

            // - To get values from Monarch Attendees Grid 
            CheckBox chkMonarchAttendees = new CheckBox();
            Label lblchkMonarchAttendees = new Label();
            string strMonarchAttendees = "";
            foreach (GridViewRow oItem in grdMonarchAttendees.Rows)
            {
                chkMonarchAttendees = (CheckBox)oItem.FindControl("cb");
                if (chkMonarchAttendees.Checked)
                {
                    lblchkMonarchAttendees = (Label)oItem.FindControl("lblID");
                    strMonarchAttendees = strMonarchAttendees + lblchkMonarchAttendees.Text.Trim() + ',';
                }
            }

            // - To get values from Other Attendees Grid 
            CheckBox chkOtherAttendees = new CheckBox();
            Label lblOtherAttendees = new Label();
            string strOtherAttendees = "";
            foreach (GridViewRow oItem in grdOtherAttendees.Rows)
            {
                chkOtherAttendees = (CheckBox)oItem.FindControl("cb");
                if (chkOtherAttendees.Checked)
                {
                    lblOtherAttendees = (Label)oItem.FindControl("lblID");
                    strOtherAttendees = strOtherAttendees + lblOtherAttendees.Text.Trim() + ',';
                }
            }

            // - To get values from Meeting Purpose Grid 
            CheckBox chkPurpose = new CheckBox();
            Label lblPurpose = new Label();
            string strPurpose = "";
            foreach (GridViewRow oItem in grdMeetingPurpose.Rows)
            {
                chkPurpose = (CheckBox)oItem.FindControl("cb");
                if (chkPurpose.Checked)
                {
                    lblPurpose = (Label)oItem.FindControl("lblID");
                    strPurpose = strPurpose + lblPurpose.Text.Trim() + ',';
                }
            }

            // - To get values from Meeting Result Grid 
            CheckBox chkResult = new CheckBox();
            Label lblResult = new Label();
            string strResult = "";
            foreach (GridViewRow oItem in grdMeetingResult.Rows)
            {
                chkResult = (CheckBox)oItem.FindControl("cb");
                if (chkResult.Checked)
                {
                    lblResult = (Label)oItem.FindControl("lblID");
                    strResult = strResult + lblResult.Text.Trim() + ',';
                }
            }

            // - To get values from Monarch Action Grid 
            CheckBox chkMonarchAction = new CheckBox();
            Label lblMonarchAction = new Label();
            string strMonarchAction = "";
            foreach (GridViewRow oItem in grdMonarchAction.Rows)
            {
                chkMonarchAction = (CheckBox)oItem.FindControl("cb");
                if (chkMonarchAction.Checked)
                {
                    lblMonarchAction = (Label)oItem.FindControl("lblID");
                    strMonarchAction = strMonarchAction + lblMonarchAction.Text.Trim() + ',';
                }
            }
            
            // - To get values from Other Action Grid 
            CheckBox chkOtherAction = new CheckBox();
            Label lblOtherAction = new Label();
            string strOtherAction = "";
            foreach (GridViewRow oItem in grdClientAction.Rows)
            {
                chkOtherAction = (CheckBox)oItem.FindControl("cb");
                if (chkOtherAction.Checked)
                {
                    lblOtherAction = (Label)oItem.FindControl("lblID");
                    strOtherAction = strOtherAction + lblOtherAction.Text.Trim() + ',';
                }
            }

            int MeetingCalledBy_Id = Convert.ToInt32(ddlMeetingCalledBy.SelectedValue);            
            int CalledBy_Id = Convert.ToInt32(dllCustomers.SelectedValue);
            int VenueID = Convert.ToInt32(ddlVenue.SelectedValue);
            string AuthorisedBy = ddlAuthorisedBy.SelectedValue.ToString();
            DateTime dtMeetingDate = Convert.ToDateTime(txt_enddate.Text);                    
            string MonarchAction_PersonName = Convert.ToString(ddlMonarchUser.SelectedValue);            
            string ClientAction_PersonName = Convert.ToString(ddlClientActionPerson.SelectedItem.ToString());
            string FileName = CurrentFileName;
            string FilePath = CurrentFilePath;
            string MeetingMinutes = Server.HtmlEncode(txtMinuteofMeeting.Text); 
            string value = Request.QueryString["value"];

            string Update_User = Session["UserName"].ToString();

            objMeetHist.UpdateMeetingHistory(Convert.ToInt16(value), MeetingCalledBy_Id, CalledBy_Id, "", VenueID, AuthorisedBy, dtMeetingDate, strMonarchAttendees, strOtherAttendees, strPurpose, strResult, ClientAction_PersonName, strOtherAction, MonarchAction_PersonName, strMonarchAction, FileName, FilePath, MeetingMinutes, Update_User);            
            Page.RegisterStartupScript("CLOSE", "<script language='javascript'>window.opener.location.reload();self.close();</script>");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {

        }
    }


    protected void ddlMeetingCalledBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        getCalledby();
    }
    
    public void getCalledby()
    {
        try
        {
            if (ddlMeetingCalledBy.SelectedValue == "2")
            {
                dllCustomers.Items.Clear();
                dllCustomers.DataSource = objTariff.getCustomers();
                dllCustomers.DataTextField = "company_name";
                dllCustomers.DataValueField = "customer_id";
                dllCustomers.DataBind();
                dllCustomers.Items.Insert(0, "--Select--");
            }
            else if (ddlMeetingCalledBy.SelectedValue == "6")
            {
                dllCustomers.Items.Clear();
                dllCustomers.DataSource = objTariff.getSuppliers();
                dllCustomers.DataTextField = "supplier_name";
                dllCustomers.DataValueField = "supplier_id";
                dllCustomers.DataBind();
                dllCustomers.Items.Insert(0, "--Select--");
            }
            else if (ddlMeetingCalledBy.SelectedValue == "--Select--")
            {
                dllCustomers.Items.Clear();
                dllCustomers.Items.Insert(0, "--Select--");
            }
            else
            {
                dllCustomers.Items.Clear();
                dllCustomers.DataSource = objsetup.getCalledby(Convert.ToInt16(ddlMeetingCalledBy.SelectedValue));
                dllCustomers.DataTextField = "name";
                dllCustomers.DataValueField = "id";
                dllCustomers.DataBind();
                dllCustomers.Items.Insert(0, "--Select--");
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {

        }

    }

    protected void dllCustomers_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClientListValues();
    }


    public void ClientListValues()
    {
        
        DALClientAttendees objClientAttend = new DALClientAttendees();
        DataSet ds = new DataSet();

        int MeetingCalledBy = 0;
        int ClientsID = 0;

        if (ddlMeetingCalledBy.SelectedIndex != 0)
            MeetingCalledBy = Convert.ToInt16(ddlMeetingCalledBy.SelectedValue);

        if (dllCustomers.SelectedIndex != 0)
            ClientsID = Convert.ToInt16(dllCustomers.SelectedValue);

        ds = objClientAttend.getClientAttendees(ClientsID, MeetingCalledBy);        

        DataTable dtnull = new DataTable();
        dtnull.Columns.Add("ID");
        dtnull.Columns.Add("Name");
        dtnull.Columns.Add("Designation");

        ddlClientActionPerson.Items.Clear();
        ddlClientActionPerson.DataSource = ds;
        ddlClientActionPerson.DataTextField = "Name";
        ddlClientActionPerson.DataValueField = "Name";
        ddlClientActionPerson.DataBind();
        ddlClientActionPerson.Items.Insert(0, "--Select--");

        if (dsView.Tables[1] != null)
        {
            grdOtherAttendees.DataSource = dsView.Tables[1];
            grdOtherAttendees.DataBind();
        }

    }


    //protected void lstClientForward_Click(object sender, EventArgs e)
    //{

    //    try
    //    {

    //        if (lstClientMain.SelectedIndex > -1)
    //        {

    //            ArrayList arr = new ArrayList();
    //            int j = 0;
    //            int count = 0;

    //            for (int i = 0; i <= lstClientMain.Items.Count - 1; i++)
    //            {
    //                if (lstClientMain.Items[i].Selected)
    //                {
    //                    lstClientSelect.Items.Add(new ListItem(lstClientMain.Items[i].Text, lstClientMain.Items[i].Value));
    //                    count = count + 1;
    //                    arr.Add(lstClientMain.Items.IndexOf(lstClientMain.Items[i]));
    //                }
    //            }

    //            for (j = count - 1; j >= 0; j--)
    //            {
    //                int k = Convert.ToInt32(arr[j].ToString());
    //                lstClientMain.Items.RemoveAt(k);
    //            }

    //            SortListBox(lstClientSelect);
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        ex.ToString();
    //    }

    //}
    //protected void lstClientBack_Click(object sender, EventArgs e)
    //{

    //    try
    //    {

    //        if (lstClientSelect.SelectedIndex > -1)
    //        {

    //            ArrayList arr = new ArrayList();
    //            int j = 0;
    //            int count = 0;

    //            for (int i = 0; i <= lstClientSelect.Items.Count - 1; i++)
    //            {
    //                if (lstClientSelect.Items[i].Selected)
    //                {
    //                    lstClientMain.Items.Add(new ListItem(lstClientSelect.Items[i].Text, lstClientSelect.Items[i].Value));
    //                    count = count + 1;
    //                    arr.Add(lstClientSelect.Items.IndexOf(lstClientSelect.Items[i]));
    //                }
    //            }

    //            for (j = count - 1; j >= 0; j--)
    //            {
    //                int k = Convert.ToInt32(arr[j].ToString());
    //                lstClientSelect.Items.RemoveAt(k);
    //            }

    //            SortListBox(lstClientMain);
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        ex.ToString();
    //    }
    //}

}