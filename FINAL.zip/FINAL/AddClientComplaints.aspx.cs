﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class AddClientComplaints : System.Web.UI.Page
{
    int Cust_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {


        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getClientComplaint();        
        }

    }


    protected void grdComplaint_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdComplaint.Columns[6].Visible = true;
                grdComplaint.Columns[7].Visible = true;
                TableCell cell1 = grdComplaint.FooterRow.Cells[8];
                TableCell cell2 = grdComplaint.FooterRow.Cells[6];
                grdComplaint.FooterRow.Cells.RemoveAt(8);
                grdComplaint.FooterRow.Cells.RemoveAt(6);
                grdComplaint.FooterRow.Cells.AddAt(6, cell1);
                grdComplaint.FooterRow.Cells.AddAt(8, cell2);
            }
            else
            {
                grdComplaint.Columns[6].Visible = false;
                grdComplaint.Columns[7].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    public void getClientComplaint()
    {

        try
        {
            DALClient_Complaint objCC = new DALClient_Complaint();

            DataSet ds = new DataSet();

           // Cust_id = 5;

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objCC.getClient_Complaint(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("ComplaintMadeby");
            dtnull.Columns.Add("ComplaintModeText");
            dtnull.Columns.Add("ComplaintNatureText");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdComplaint.DataSource = ds;
                grdComplaint.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["ComplaintMadeby"] = null;
                d["ComplaintModeText"] = null;
                d["ComplaintNatureText"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdComplaint.DataSource = dtnull;
                grdComplaint.DataBind();
                grdComplaint.Rows[0].Visible = false;
                grdComplaint.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    protected void AddComplaint(object sender, EventArgs e)
    {

        try
        {
            DALClient_Complaint objCC = new DALClient_Complaint();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            //Cust_id = 5;

            DateTime txtDate = Convert.ToDateTime(((TextBox)grdComplaint.FooterRow.FindControl("txtDate")).Text);
            string strComplaint_Made_by = ((TextBox)grdComplaint.FooterRow.FindControl("txtComplaint_Made_by")).Text;
            int ComplaintMode = ((DropDownList)grdComplaint.FooterRow.FindControl("ddlComplaintMode")).SelectedIndex;
            int ComplaintNature = Convert.ToInt32(((DropDownList)grdComplaint.FooterRow.FindControl("ddlComplaintNature")).SelectedValue);
            FileUpload fUpload = (FileUpload)grdComplaint.FooterRow.FindControl("FileUpload");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ClientComplaints\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);

                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ClientComplaints\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;

            }

            grdComplaint.DataSource = objCC.InsertClient_Complaint(Cust_id, txtDate, strComplaint_Made_by, ComplaintMode,ComplaintNature, CurrentFileName,CurrentFilePath, Create_User);
            grdComplaint.DataBind();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateComplaint(object sender, GridViewUpdateEventArgs e)
    {

        try
        {
            DALClient_Complaint objCC = new DALClient_Complaint();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            //Cust_id = 5;

            int Id = Convert.ToInt32(((Label)grdComplaint.Rows[e.RowIndex].FindControl("Id")).Text);
            DateTime txtDate = Convert.ToDateTime(((TextBox)grdComplaint.Rows[e.RowIndex].FindControl("txtDate")).Text);
            string strComplaint_Made_by = ((TextBox)grdComplaint.Rows[e.RowIndex].FindControl("txtComplaint_Made_by")).Text;
            int ComplaintMode = ((DropDownList)grdComplaint.Rows[e.RowIndex].FindControl("ddlComplaintMode")).SelectedIndex;
            int ComplaintNature = Convert.ToInt32(((DropDownList)grdComplaint.Rows[e.RowIndex].FindControl("ddlComplaintNature")).SelectedValue);
            FileUpload fUpload = (FileUpload)grdComplaint.Rows[e.RowIndex].FindControl("FileUpload");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ClientComplaints\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);

                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ClientComplaints\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;

            }

            grdComplaint.EditIndex = -1;
            grdComplaint.DataSource = objCC.UpdateClient_Complaint(Id,Cust_id, txtDate, strComplaint_Made_by, ComplaintMode, ComplaintNature, CurrentFileName, CurrentFilePath, Update_User);
            grdComplaint.DataBind();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditComplaint(object sender, GridViewEditEventArgs e)
    {

        grdComplaint.EditIndex = e.NewEditIndex;
        getClientComplaint();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {

        grdComplaint.EditIndex = -1;
        getClientComplaint();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {

        LinkButton lnkRemove = (LinkButton)sender;
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }

    protected void DeleteComplaint(object sender, EventArgs e)
    {

        try
        {
            DALClient_Complaint objCC = new DALClient_Complaint();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            //Cust_id = 5;

            ds = objCC.delClient_Complaint(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("ComplaintMadeby");
            dtnull.Columns.Add("ComplaintModeText");
            dtnull.Columns.Add("ComplaintNatureText");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdComplaint.DataSource = ds;
                grdComplaint.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["ComplaintMadeby"] = null;
                d["ComplaintModeText"] = null;
                d["ComplaintNatureText"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdComplaint.DataSource = dtnull;
                grdComplaint.DataBind();
                grdComplaint.Rows[0].Visible = false;
                grdComplaint.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

    }


    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        try
        {
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                DALSetup objsetup = new DALSetup();
                DataSet ds = new DataSet();

                ds = objsetup.getComplaint_Nature(2);
                DropDownList ddlComplaintNature = (DropDownList)e.Row.FindControl("ddlComplaintNature");
                ddlComplaintNature.DataSource = ds;
                ddlComplaintNature.DataTextField = "Name";
                ddlComplaintNature.DataValueField = "Id";
                ddlComplaintNature.DataBind();
                ddlComplaintNature.Items.Insert(0, "--Select--");
            }

            if (e.Row.RowState == DataControlRowState.Edit || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Edit)))
            {
                DALSetup objsetup = new DALSetup();
                DataSet ds = new DataSet();
                ds = objsetup.getComplaint_Nature(2);
                DropDownList ddlComplaintNature = (DropDownList)e.Row.FindControl("ddlComplaintNature");
                ddlComplaintNature.DataSource = ds;
                ddlComplaintNature.DataTextField = "Name";
                ddlComplaintNature.DataValueField = "Id";
                ddlComplaintNature.DataBind();
                ddlComplaintNature.Items.Insert(0, "--Select--");
                ddlComplaintNature.SelectedIndex = ddlComplaintNature.Items.IndexOf(ddlComplaintNature.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "Name").ToString()));
                DropDownList ddlComplaintMode = (DropDownList)e.Row.FindControl("ddlComplaintMode");
                ddlComplaintMode.SelectedIndex = ddlComplaintMode.Items.IndexOf(ddlComplaintMode.Items.FindByValue(DataBinder.Eval(e.Row.DataItem, "ComplaintMode").ToString()));
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }
}