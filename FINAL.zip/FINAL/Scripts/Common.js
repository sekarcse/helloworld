﻿
function CheckInteger(str) {
    return /^\+?(0|[1-9]\d*)$/.test(str);
}

function CheckDecimal(str) {
    return /^\d+(\.\d{0,4})?$/.test(str);
}

function CheckFromDateToDate(oSrc, args) {
    var str1 = $("#txtFromDate").val();
    var str2 = $("#txtToDate").val();
    if (str1.length > 0) {
        var dt1 = parseInt(str1.substring(0, 2), 10);
        var mon1 = parseInt(str1.substring(3, 5), 10);
        var yr1 = parseInt(str1.substring(6, 10), 10);
        var dt2 = parseInt(str2.substring(0, 2), 10);
        var mon2 = parseInt(str2.substring(3, 5), 10);
        var yr2 = parseInt(str2.substring(6, 10), 10);
        var date1 = new Date(yr1, mon1, dt1);
        var date2 = new Date(yr2, mon2, dt2);
        if (date2 < date1) {
            $("#txtToDate").attr('title', 'To date should not be lesser than from date');
            $("#lblToDateError").text("*");
            $("#lblToDateError").attr('title', 'To date should not be lesser than from date');
            $("#txtToDate").addClass('invalid');
            args.IsValid = false;
        }
        else {
            args.IsValid = true;
            $("#txtToDate").removeClass('invalid');
            $("#txtToDate").attr('title', '');
            $("#lblToDateError").text("");
            $("#lblToDateError").attr('title', '');
        }
    }
    else if (str2.length > 0) {
        args.IsValid = true;
        $("#txtToDate").removeClass('invalid');
        $("#txtToDate").attr('title', '');
        $("#lblToDateError").text("");
        $("#lblToDateError").attr('title', '');
    }
}

function CheckFromDate(oSrc, args) {
    var FromDate = $("#txtFromDate").val();

    if (FromDate.length == 10) {
        if ($.trim($("#txtFromDate").val()) != "__/__/____") {
            $("#lblFromDateError").text("");
            $("#lblFromDateError").attr('title', '');
        }
    }
    else if (FromDate.length == 0) {
        $("#txtFromDate").addClass('invalid');
        $("#txtFromDate").attr('title', 'Please enter the from date');
        $("#lblFromDateError").text("*");
        $("#lblFromDateError").attr('title', 'Please enter the from date');
    }
}

function CheckToDate(oSrc, args) {
    var ToDate = $("#txtToDate").val();

    if (ToDate.length == 10) {
        if ($.trim($("#txtToDate").val()) != "__/__/____") {
            $("#lblToDateError").text("");
            $("#lblToDateError").attr('title', '');
        }
    }
    else if (ToDate.length == 0) {
        $("#txtToDate").addClass('invalid');
        $("#txtToDate").attr('title', 'Please enter the to date');
        $("#lblToDateError").text("*");
        $("#lblToDateError").attr('title', 'Please enter the to date');
    }
}

