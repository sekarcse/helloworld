﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ScannedCNBsAddNew : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
        Session["CommandScannedCNBs"] = "save";
        try
        {
            DALScannedCNB objScannedCNB = new DALScannedCNB();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());


            DateTime startDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime EndDate = Convert.ToDateTime(txtToDate.Text);

            int Utilitytype = Convert.ToInt32(ddlUtility_type.SelectedIndex);

            string CNB = Convert.ToString(txtCNB.Text);
            
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (FileUpload.HasFile)
            {
                CurrentFileName = FileUpload.FileName;

                if (Utilitytype == 1)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Electric\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Electric\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                    else
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Electric\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Electric\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                }
                else if (Utilitytype == 2)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Gas\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Gas\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                    else
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Gas\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Gas\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                }
                else if (Utilitytype == 3)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Telecom\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Telecom\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                    else
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Telecom\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Telecom\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                }
                else if (Utilitytype == 4)
                {
                    if ((int)EndDate.Year <= 2020 && (int)EndDate.Year >= 2005)
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Water\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\" + EndDate.Year + "\\Water\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                    else
                    {
                        FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Water\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                        CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ScannedCNBFiles\\OtherYears\\Water\\") +
                        dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
                    }
                }
            }
            objScannedCNB.InsertScannedCNB(Cust_id, CurrentFileName, CurrentFilePath, Create_User, startDate, EndDate, Utilitytype, CNB);
            
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveScannedCNBsAddNew()", true);

            string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

            // ASP.NET 2.0
            if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Dashboard History CNBs Scanned CNBs", "btnSave_Click", ex.Message);
        }
    }  

}