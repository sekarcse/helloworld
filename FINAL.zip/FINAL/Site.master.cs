﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Security.Cryptography;

public partial class SiteMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {  
       
        if (Session["RoleID"] != null)
            {
                if (Convert.ToInt32(Session["RoleID"].ToString()) < 3)
                {
                    //lblWelcome.Visible = true;
                    //lblUserName.Text = Session["UserName"].ToString();
                    lblCustomerId.Text = "Customer Id: " + Session["CustID"].ToString();
                    lblCompanyName.Text = "Company Name: " + Session["CompanyName"].ToString();
                    linkbutton.Visible = true;
                    lnkMatrix.Visible = true;
                }
                else if (Convert.ToInt32(Session["RoleID"].ToString()) == 3)
                {
                    //lblWelcome.Visible = true;
                    //lblUserName.Text = Session["UserName"].ToString();
                    lblCustomerId.Text = "Customer Id: " + Session["CustID"].ToString();
                    lblCompanyName.Text = "Company Name: " + Session["CompanyName"].ToString();
                    linkbutton.Visible = true;
                    NavigationMenu.Visible = false;
                    NavigationMenuRold3.Visible = true;
                    lnkMatrix.Visible = true;
                }
                else
                {
                    //lblWelcome.Visible = false;
                    linkbutton.Visible = false;
                    lnkMatrix.Visible = false;
                }
            }

    }
    protected void linkbutton_Click(object sender, EventArgs e)
    {
        try
        {

            if (Session["RoleID"] != null)
                Session["RoleID"] = null;
            if (Session["UserName"] != null)
                Session["UserName"] = null;

            Response.Redirect("/login.asp");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {

        }
    }


    protected void lnkMatrix_Click(object sender, EventArgs e)
    {
        try
        {

            if (Session["RoleID"] != null)
                Session["RoleID"] = null;
            if (Session["UserName"] != null)
                Session["UserName"] = null;

            Response.Redirect("/customers/customer.asp");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {

        }
    }
}
