﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class AddLOAs : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getLOA();         
        }
        else
        {
            if (Session["Command"] == "save")
            {
                getLOA();
                Session["Command"] = string.Empty;
            }
        }
    }


    protected void grdLOA_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdLOA.Columns[4].Visible = true;
                grdLOA.Columns[5].Visible = true;
                TableCell cell1 = grdLOA.FooterRow.Cells[6];
                TableCell cell2 = grdLOA.FooterRow.Cells[4];
                grdLOA.FooterRow.Cells.RemoveAt(6);
                grdLOA.FooterRow.Cells.RemoveAt(4);
                grdLOA.FooterRow.Cells.AddAt(4, cell1);
                grdLOA.FooterRow.Cells.AddAt(6, cell2);
                //grdLOA.Columns[5].Visible = false;
            }
            else
            {
                grdLOA.Columns[4].Visible = false;
                grdLOA.Columns[5].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getLOA()
    {
        try
        {
            DALLOA objLOA = new DALLOA();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objLOA.getLOA(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("Fromdate");
            dtnull.Columns.Add("Todate");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["LOAGrid"] = ds;
                grdLOA.DataSource = ds;
                grdLOA.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["Fromdate"] = null;
                d["Todate"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                Session["LOAGrid"] = dtnull;
                grdLOA.DataSource = dtnull;
                grdLOA.DataBind();
                grdLOA.Rows[0].Visible = false;
                grdLOA.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewLOA(object sender, EventArgs e)
    {
        try
        {
            DALLOA objLOA = new DALLOA();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            DateTime FromDate = Convert.ToDateTime(((TextBox)grdLOA.FooterRow.FindControl("txtFromDate")).Text);
            DateTime ToDate = Convert.ToDateTime(((TextBox)grdLOA.FooterRow.FindControl("txtToDate")).Text);

            FileUpload fUpload = (FileUpload)grdLOA.FooterRow.FindControl("FileUpload");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {                
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\LOAFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\LOAFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
            }
            grdLOA.DataSource = objLOA.InsertLOA(Cust_id, CurrentFileName, CurrentFilePath, Create_User, FromDate, ToDate);
            grdLOA.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateLOA(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALLOA objLOA = new DALLOA();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdLOA.Rows[e.RowIndex].FindControl("Id")).Text);

            DateTime FromDate = Convert.ToDateTime(((TextBox)grdLOA.Rows[e.RowIndex].FindControl("txtFromDate")).Text);
            DateTime ToDate = Convert.ToDateTime(((TextBox)grdLOA.Rows[e.RowIndex].FindControl("txtToDate")).Text);

            FileUpload fUpload = (FileUpload)grdLOA.Rows[e.RowIndex].FindControl("FileUpload");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\LOAFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\LOAFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
            }
            grdLOA.EditIndex = -1;
            grdLOA.DataSource = objLOA.UpdateLOA(ID, Cust_id, CurrentFileName, CurrentFilePath, Update_User, FromDate, ToDate);
            grdLOA.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditLOA(object sender, GridViewEditEventArgs e)
    {
        grdLOA.EditIndex = e.NewEditIndex;
        getLOA();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdLOA.EditIndex = -1;
        getLOA();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {   
            LinkButton lnkRemove = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }

    protected void DeleteLOA(object sender, EventArgs e)
    {
        try
        {
            DALLOA objLOA = new DALLOA();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;            

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objLOA.delLOA(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("Fromdate");
            dtnull.Columns.Add("Todate");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["LOAGrid"] = ds;
                grdLOA.DataSource = ds;
                grdLOA.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["Fromdate"] = null;
                d["Todate"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                Session["LOAGrid"] = dtnull;
                grdLOA.DataSource = dtnull;
                grdLOA.DataBind();
                grdLOA.Rows[0].Visible = false;
                grdLOA.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        grdLOA.PageIndex = e.NewPageIndex;
        grdLOA.DataSource = (DataSet)Session["LOAGrid"];
        grdLOA.DataBind();
    }

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "AddLOAPopup()", true);
    }

}