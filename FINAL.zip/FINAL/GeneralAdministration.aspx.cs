﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net.Mail;
using System.Net;


public partial class GeneralAdministration : System.Web.UI.Page
{
    string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
    string sAccountManagerSelectedValue = string.Empty;    

    protected void Page_Load(object sender, EventArgs e)
    {
        Session["EditInitialContactGrid"] = null;        

        if (Session["RoleID"] == null)
        {
            Response.Redirect("login.asp");
        }                   

        if (!Page.IsPostBack)
        {

            if (Session["RoleID"] == null)
            {
                Response.Redirect("login.asp");
            }

            else if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                divGeneralAdministrationSaveContract.Visible = true;
                divGeneralAdministrationContractDetails.Visible = true;
                divAddNewRecordLink.Visible = true;                
            }
            else if (Convert.ToInt16(Session["RoleID"]) == 2)
            {
                divGeneralAdministrationSaveContract.Visible = false;
                divGeneralAdministrationContractDetails.Visible = false;
                divAddNewRecordLink.Visible = true;                
            }
            else
            {
                divGeneralAdministrationSaveContract.Visible = false;
                divGeneralAdministrationContractDetails.Visible = false;
                divAddNewRecordLink.Visible = true;                
            }

            GetAccountManager();
            GetTotalNHH();
            BindGrid();
            BindReasonGrid();
            
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
            DataTable dtGeneralAdministration = new DataTable();

            try
            {
                GetContractSignedDate(Convert.ToInt32(Session["CustID"].ToString()));
                dtGeneralAdministration = objGeneralAdministration.GetGeneralAdministration(Convert.ToInt32(Session["CustID"].ToString()));
                if (dtGeneralAdministration.Rows.Count > 0)
                {
                    hdnGeneralAdministrationID.Value = dtGeneralAdministration.Rows[0][0].ToString();

                    if (dtGeneralAdministration.Rows[0][11].ToString().Length > 0)
                    {
                        divAttachScannedCopy.Visible = false;
                        lnkViewScannedCopy.Text = dtGeneralAdministration.Rows[0][11].ToString();
                        divViewScannedCopy.Visible = true;
                        Session["ScannedCopyFileName"] = dtGeneralAdministration.Rows[0][11].ToString();
                        Session["ScannedCopyFilePath"] = dtGeneralAdministration.Rows[0][12].ToString();
                    }

                    if (dtGeneralAdministration.Rows[0][4].ToString().Length > 0)
                    {
                        txtCopyBillsReceivedUserName.Text = dtGeneralAdministration.Rows[0][4].ToString();
                        txtCopyBillsReceived.Text = dtGeneralAdministration.Rows[0][3].ToString();
                    }
                    if (dtGeneralAdministration.Rows[0][6].ToString().Length > 0)
                    {
                        txtCopyBillsPostedUserName.Text = dtGeneralAdministration.Rows[0][6].ToString();
                        txtCopyBillsPosted.Text = dtGeneralAdministration.Rows[0][5].ToString();
                    }
                    if (dtGeneralAdministration.Rows[0][8].ToString().Length > 0)
                    {
                        txtAllocatedToAnAccountManagerUserName.Text = dtGeneralAdministration.Rows[0][8].ToString();
                        txtAllocatedToAnAccountManager.Text = dtGeneralAdministration.Rows[0][7].ToString();
                    }
                    if (dtGeneralAdministration.Rows[0][10].ToString().Length > 0)
                    {
                        sAccountManagerSelectedValue = dtGeneralAdministration.Rows[0][10].ToString();
                        if (sAccountManagerSelectedValue.Length > 0)
                        {
                            ddlAccountManager.SelectedValue = sAccountManagerSelectedValue;
                            divbgblock2.Visible = true;
                            divGridInitialContactAccountManager.Visible = true;
                            divGeneralAdministrationSignedDetails.Visible = true;                            
                            ddlAccountManager.Enabled = false;

                            if (Session["RoleID"] == null)
                            {
                                Response.Redirect("login.asp");
                            }
                            else if (Convert.ToInt16(Session["RoleID"]) <= 2)
                            {
                                divGeneralAdministrationSaveContract.Visible = false;
                                divGeneralAdministrationSaveCancel.Visible= true;
                            }
                        }
                        else
                        {
                            ddlAccountManager.Enabled = true;
                        }
                    }

                    if (dtGeneralAdministration.Rows[0][17].ToString().Length > 0)
                    {
                        txtSignedNHH.Text = dtGeneralAdministration.Rows[0][17].ToString();
                        if (Convert.ToInt32(txtTotalNumberNHH.Text) > 0)
                        {                     
                            decimal NHH = 100 * Convert.ToDecimal(txtSignedNHH.Text) / Convert.ToDecimal(txtTotalNumberNHH.Text);
                            NHH = Math.Round(NHH, 0);
                            txtPercentageSignedNHH.Text = Convert.ToString(NHH) + " %";
                        }
                        else
                        {
                            txtPercentageSignedNHH.Text = "0 %";
                        }
                    }
                    else
                    {
                        txtPercentageSignedNHH.Text = "0 %";
                    }
                    if (dtGeneralAdministration.Rows[0][18].ToString().Length > 0)
                    {
                        txtSignedHH.Text = dtGeneralAdministration.Rows[0][18].ToString();
                        if (Convert.ToInt32(txtTotalNumberHH.Text) > 0)
                        {
                            decimal HH = 100 * Convert.ToDecimal(txtSignedHH.Text) / Convert.ToDecimal(txtTotalNumberHH.Text);
                            HH = Math.Round(HH, 0);
                            txtPercentageSignedHH.Text = Convert.ToString(HH) + " %";                            
                        }
                        else
                        {
                            txtPercentageSignedHH.Text = "0 %";
                        }                        
                    }
                    else
                    {
                        txtPercentageSignedHH.Text = "0 %";
                    }
                    if (dtGeneralAdministration.Rows[0][19].ToString().Length > 0)
                    {
                        txtSignedGas.Text = dtGeneralAdministration.Rows[0][19].ToString();
                        if (Convert.ToInt32(txtTotalNumberGas.Text) > 0)
                        {
                            decimal Gas = 100 * Convert.ToDecimal(txtSignedGas.Text) / Convert.ToDecimal(txtTotalNumberGas.Text);
                            Gas = Math.Round(Gas, 0);
                            txtPercentageSignedGas.Text = Convert.ToString(Gas) + " %";                                                        
                        }
                        else
                        {
                            txtPercentageSignedGas.Text = "0 %";
                        } 
                    }
                    else
                    {
                        txtPercentageSignedGas.Text = "0 %";
                    }
                    if (dtGeneralAdministration.Rows[0][17].ToString().Length > 0 || dtGeneralAdministration.Rows[0][18].ToString().Length > 0 || dtGeneralAdministration.Rows[0][19].ToString().Length > 0)
                    {
                        txtUserNameTotalNumberSigned.Text = dtGeneralAdministration.Rows[0][20].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                lblGrdException.Text = ex.ToString();
            }                   
           
        }
        else
        {
            BindGrid();
        }
        
    }

    private void BindGrid()
    {
        DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
        DataTable dtInitialContact = new DataTable();
        try
        {
            dtInitialContact = objGeneralAdministration.GetInitialContactGrid(Convert.ToInt32(Session["CustID"].ToString()));
            if (dtInitialContact != null)
            {
                Session["InitialContactGrid"] = dtInitialContact;
                grdInitialContactAccountManager.DataSource = dtInitialContact;
                grdInitialContactAccountManager.DataBind();                
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GeneralAdministration", "BindGrid", ex.Message);
        }
    }

    public void GetAccountManager()
    {
        try
        {
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
            DataTable dt = new DataTable();
            dt = objGeneralAdministration.DisplayAccountManager();
            ddlAccountManager.DataSource = dt;
            ddlAccountManager.DataTextField = "fullname";            
            ddlAccountManager.DataValueField = "username";
            ddlAccountManager.DataBind();
            ddlAccountManager.Items.Insert(0, "Select");            
        }
        catch (Exception ex)
        {
            ex.ToString();
        }        
    }

    public void GetTotalNHH()
    {
        try
        {
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
            DataSet ds = new DataSet();
            int Cust_id = 0;

            if (Session["CustID"] != null)
             Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objGeneralAdministration.getTotalNHH(Cust_id);

            if (ds.Tables[0].Rows.Count != 0)
            {
                txtTotalNumberNHH.Text = ds.Tables[0].Rows[0][0].ToString();
            }
            if (ds.Tables[1].Rows.Count != 0)
            {
                txtTotalNumberHH.Text = ds.Tables[1].Rows[0][0].ToString();
            }
            if (ds.Tables[2].Rows.Count != 0)
            {
                txtTotalNumberGas.Text = ds.Tables[2].Rows[0][0].ToString();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    public void GetContractSignedDate(int CustomerID)
    {
        try
        {
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
            DataTable dt = new DataTable();
            txtDateContractSigned.Text = objGeneralAdministration.DisplayContractSignedDate(CustomerID);
        }
        catch (Exception ex)
        {
            ex.ToString();
        }        
    }

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "AddEditInitialContact()", true);        
    }


    protected void grdInitialContactAccountManager_RowDataBound(object sender, GridViewRowEventArgs e)
    {      
        try
        {            
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Session["BriefDescEdit"] = e.Row.Cells[1].Text;
                Session["DateEdit"] = e.Row.Cells[2].Text;
                ((LinkButton)e.Row.FindControl("lnkEditDetails")).Attributes.Add("onclick", string.Format("PopupEdit('{0}')", (e.Row.FindControl("lnkEditDetails") as LinkButton).CommandArgument));                
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }    


    protected void grdInitialContactAccountManager_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdInitialContactAccountManager.PageIndex = e.NewPageIndex;
        grdInitialContactAccountManager.DataSource = (DataTable)Session["InitialContactGrid"];
        grdInitialContactAccountManager.DataBind();
    }


    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        try
        {
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();         
            LinkButton lnkDelete = (LinkButton)sender; 
            
            objGeneralAdministration.DeleteInitialContact(Convert.ToInt32(lnkDelete.CommandArgument));      
            BindGrid();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }        
    }

    protected void ShowFiles(object sender, EventArgs e)
    {
        LinkButton lnkRemove = (LinkButton)sender;
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string CurrentFilePath = "", CurrentFileName = "";
        DateTime dtNow = DateTime.Now;
        if (fileUploadScannedCopy.HasFile)
        {
            CurrentFileName = fileUploadScannedCopy.FileName;
            fileUploadScannedCopy.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\GeneralAdministrationScannedCopy\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadScannedCopy.FileName);
            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\GeneralAdministrationScannedCopy\\") +
            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadScannedCopy.FileName;
        }

        DateTime DateContractSigned = Convert.ToDateTime(txtDateContractSigned.Text);
        DateTime CopyBillsReceived = Convert.ToDateTime(txtCopyBillsReceived.Text);
        DateTime CopyBillsPosted = Convert.ToDateTime(txtCopyBillsPosted.Text);
        DateTime AllocatedToAnAccountManager = Convert.ToDateTime(txtAllocatedToAnAccountManager.Text);
        string AllocatedAccountManagerName = ddlAccountManager.SelectedValue;

        DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
        objGeneralAdministration.SaveGeneralAdministration(0, DateContractSigned, CopyBillsReceived, CopyBillsPosted, AllocatedToAnAccountManager,Session["UserName"].ToString(),AllocatedAccountManagerName, CurrentFileName, CurrentFilePath);
              
    }

    protected void btnSaveContract_Click(object sender, EventArgs e)
    {
        int ID = Convert.ToInt32(hdnGeneralAdministrationID.Value);
        int CustomerID = Convert.ToInt32(Session["CustID"].ToString());       

        if (txtDateContractSigned.Text.Length > 0)
        {
            string AllocatedAccountManager = string.Empty;

            string CopyBillsReceived = string.Empty;
            string CopyBillsPosted = string.Empty;
            string AllocatedtoanAccountManager = string.Empty;

            if (ddlAccountManager.SelectedValue == "Select")
            {
                AllocatedAccountManager = string.Empty;
            }
            else{
                AllocatedAccountManager = ddlAccountManager.SelectedValue;
                SendMail();
            }

            CopyBillsReceived = txtCopyBillsReceived.Text;
            CopyBillsPosted = txtCopyBillsPosted.Text;
            AllocatedtoanAccountManager = txtAllocatedToAnAccountManager.Text;

            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();            

            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fileUploadScannedCopy.HasFile)
            {
                CurrentFileName = fileUploadScannedCopy.FileName;
                fileUploadScannedCopy.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\GeneralAdministrationScannedCopy\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadScannedCopy.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\GeneralAdministrationScannedCopy\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadScannedCopy.FileName;
                objGeneralAdministration.SaveGeneralAdministrationContract(ID, CustomerID, txtDateContractSigned.Text, CopyBillsReceived, CopyBillsPosted, AllocatedtoanAccountManager, Session["UserName"].ToString(), AllocatedAccountManager, CurrentFileName, CurrentFilePath);
            }
            else
            {
                objGeneralAdministration.SaveGeneralAdministrationContractWithoutScannedCopy(ID, CustomerID, txtDateContractSigned.Text, CopyBillsReceived, CopyBillsPosted, AllocatedtoanAccountManager, Session["UserName"].ToString(), AllocatedAccountManager);
            }

            if (ddlAccountManager.SelectedValue != "Select")
            {
                ddlAccountManager.Enabled = false;
                divbgblock2.Visible = true;
                divGridInitialContactAccountManager.Visible = true;
                divGeneralAdministrationSignedDetails.Visible = true;
                if(Session["RoleID"] == null)
                {
                    Response.Redirect("login.asp");
                }
                else if(Convert.ToInt16(Session["RoleID"]) <= 2)
                {
                    divGeneralAdministrationSaveContract.Visible = false;
                    divGeneralAdministrationSaveCancel.Visible = true;
                }
            }
            else
            {
                ddlAccountManager.Enabled = true;
                divbgblock2.Visible = false;
                divGridInitialContactAccountManager.Visible = false;
                divGeneralAdministrationSignedDetails.Visible = false;
            }

            DataTable dtGeneralAdministration = new DataTable();

            try
            {
                dtGeneralAdministration = objGeneralAdministration.GetGeneralAdministration(Convert.ToInt32(Session["CustID"].ToString()));
                if (dtGeneralAdministration.Rows.Count > 0)
                {
                    hdnGeneralAdministrationID.Value = dtGeneralAdministration.Rows[0][0].ToString();

                    if (dtGeneralAdministration.Rows[0][11].ToString().Length > 0)
                    {
                        divAttachScannedCopy.Visible = false;
                        lnkViewScannedCopy.Text = dtGeneralAdministration.Rows[0][11].ToString();
                        divViewScannedCopy.Visible = true;
                        Session["ScannedCopyFileName"] = dtGeneralAdministration.Rows[0][11].ToString();
                        Session["ScannedCopyFilePath"] = dtGeneralAdministration.Rows[0][12].ToString();
                    }

                    if (dtGeneralAdministration.Rows[0][4].ToString().Length > 0)
                    {
                        txtCopyBillsReceivedUserName.Text = dtGeneralAdministration.Rows[0][4].ToString();                       
                    }
                    if (dtGeneralAdministration.Rows[0][6].ToString().Length > 0)
                    {
                        txtCopyBillsPostedUserName.Text = dtGeneralAdministration.Rows[0][6].ToString();
                    }
                    if (dtGeneralAdministration.Rows[0][8].ToString().Length > 0)
                    {
                        txtAllocatedToAnAccountManagerUserName.Text = dtGeneralAdministration.Rows[0][8].ToString();
                    } 
                }
            }
            catch (Exception ex)
            {
                lblGrdException.Text = ex.ToString();
            }
        }
    }

    protected void btnCancelContract_Click(object sender, EventArgs e)
    {
        Response.Redirect("GeneralAdministration.aspx");
    }

    protected void grdInitialContactAccountManager_PreRender(object sender, EventArgs e)
    {
        try
        {
            if(Session["RoleID"] == null)
            {
                Response.Redirect("login.asp");
            }            
            else if (Session["UserName"].ToString() == "peter.dosanjh" || Session["UserName"].ToString() == "suba.sandhu" || Session["UserName"].ToString() == "arjan.dosanjh")
            {
                grdInitialContactAccountManager.Columns[5].Visible = true;
                grdInitialContactAccountManager.Columns[6].Visible = true;  
            }
            else
            {
                grdInitialContactAccountManager.Columns[5].Visible = false;
                grdInitialContactAccountManager.Columns[6].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }        
    }

    protected void btnSaveSignedDetails_Click(object sender, EventArgs e)
    {  
        int NHHSigned = 0;
        int HHSigned = 0;
        int GasSigned = 0;
        int ID = Convert.ToInt32(hdnGeneralAdministrationID.Value);

        if(txtSignedNHH.Text.Length>0)
        {
            NHHSigned = Convert.ToInt32(txtSignedNHH.Text);
        }
        if(txtSignedHH.Text.Length>0)
        {
            HHSigned = Convert.ToInt32(txtSignedHH.Text);
        }
        if (txtSignedGas.Text.Length > 0)
        {
            GasSigned = Convert.ToInt32(txtSignedGas.Text);
        }

      DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
      if (NHHSigned > 0 || HHSigned > 0 || GasSigned > 0)
      {
        objGeneralAdministration.SaveSignedDetails(ID, NHHSigned, HHSigned, GasSigned, Session["UserName"].ToString(), Convert.ToInt32(Session["CustID"].ToString()));

        DataTable dtGeneralAdministration = new DataTable();
        try
        {
            dtGeneralAdministration = objGeneralAdministration.GetGeneralAdministration(Convert.ToInt32(Session["CustID"].ToString()));
            if (dtGeneralAdministration.Rows.Count > 0)
            {
                if (dtGeneralAdministration.Rows[0][17].ToString().Length > 0)
                {
                    if (Convert.ToInt32(txtTotalNumberNHH.Text) > 0)
                    {
                        decimal NHH = 100 * Convert.ToDecimal(txtSignedNHH.Text) / Convert.ToDecimal(txtTotalNumberNHH.Text) ;
                        NHH = Math.Round(NHH, 0);
                        txtPercentageSignedNHH.Text = Convert.ToString(NHH) + " %";
                    }
                    else
                    {
                        txtPercentageSignedNHH.Text = "0 %";
                    }
                }
                else
                {
                    txtPercentageSignedNHH.Text = "0 %";
                }
                if (dtGeneralAdministration.Rows[0][18].ToString().Length > 0)
                {
                    if (Convert.ToInt32(txtTotalNumberHH.Text) > 0)
                    {
                        decimal HH = 100 * Convert.ToDecimal(txtSignedHH.Text) / Convert.ToDecimal(txtTotalNumberHH.Text);
                        HH = Math.Round(HH, 0);
                        txtPercentageSignedHH.Text = Convert.ToString(HH) + " %";
                    }
                    else
                    {
                        txtPercentageSignedHH.Text = "0 %";
                    }
                }
                else
                {
                    txtPercentageSignedHH.Text = "0 %";
                }
                if (dtGeneralAdministration.Rows[0][19].ToString().Length > 0)
                {
                    if (Convert.ToInt32(txtTotalNumberGas.Text) > 0)
                    {
                        decimal Gas = 100 * Convert.ToDecimal(txtSignedGas.Text) / Convert.ToDecimal(txtTotalNumberGas.Text);
                        Gas = Math.Round(Gas, 0);
                        txtPercentageSignedGas.Text = Convert.ToString(Gas) + " %";
                    }
                    else
                    {
                        txtPercentageSignedGas.Text = "0 %";
                    }
                }
                else
                {
                    txtPercentageSignedGas.Text = "0 %";
                }
                if (dtGeneralAdministration.Rows[0][17].ToString().Length > 0 || dtGeneralAdministration.Rows[0][18].ToString().Length > 0 || dtGeneralAdministration.Rows[0][19].ToString().Length > 0)
                {
                    txtUserNameTotalNumberSigned.Text = dtGeneralAdministration.Rows[0][20].ToString();
                }
            }
        }
        catch (Exception ex)
        {
            lblGrdException.Text = ex.ToString();
        }   
      }           

    }

    protected void btnCancelSignedDetails_Click(object sender, EventArgs e)
    {
        Response.Redirect("GeneralAdministration.aspx");
    }

    protected void lnkViewScannedCopy_Click(object sender, EventArgs e)
    {
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + Convert.ToString(Session["ScannedCopyFileName"]));
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(Convert.ToString(Session["ScannedCopyFilePath"]), FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }

    public void SendMail()
    {
        string[] sCCArray = new string[30];
        string[] sCCEmailID = new string[15];
        int iRole1Count = 0;
        int iCCCount = 0;

        string accountManagerFirstName = string.Empty;
        string accountManagerLastName = string.Empty;

        string userFirstName = string.Empty;
        string userLastName = string.Empty;

        string[] sCCUserName = new string[30];

        try
        {
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
            DataSet ds = new DataSet();

            ds = objGeneralAdministration.GetEmailData(Convert.ToInt32(Session["CustID"].ToString()), Session["UserName"].ToString(), ddlAccountManager.SelectedValue.ToString());

            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["CustomerName"] = ds.Tables[0].Rows[0][1].ToString();
            }
            if (ds.Tables[1].Rows.Count != 0)
            {
                Session["EmailTO"] = ds.Tables[1].Rows[0][4].ToString();
                Session["AccountManagerddlFirstName"] = ds.Tables[1].Rows[0][1].ToString();
                accountManagerFirstName = Session["AccountManagerddlFirstName"].ToString();
                accountManagerFirstName = char.ToUpper(accountManagerFirstName[0]) + accountManagerFirstName.Substring(1);
                Session["AccountManagerddlLastName"] = ds.Tables[1].Rows[0][2].ToString();
                accountManagerLastName = Session["AccountManagerddlLastName"].ToString();
                accountManagerLastName = char.ToUpper(accountManagerLastName[0]) + accountManagerLastName.Substring(1);
            }
            if (ds.Tables[2].Rows.Count != 0)
            {
                foreach (DataRow dr in ds.Tables[2].Rows)
                {
                    sCCArray[iRole1Count] = ds.Tables[2].Rows[iRole1Count][4].ToString();
                    sCCUserName[iRole1Count] = ds.Tables[2].Rows[iRole1Count][0].ToString();
                    iRole1Count++;
                }
            }
            if (ds.Tables[3].Rows.Count != 0)
            {
                Session["EmailFrom"] = ds.Tables[3].Rows[0][4].ToString();
                Session["EmailFromDisplayName"] = ds.Tables[3].Rows[0][1].ToString();
                userFirstName = Session["EmailFromDisplayName"].ToString();
                userFirstName = char.ToUpper(userFirstName[0]) + userFirstName.Substring(1);
                Session["EmailFromLastName"] = ds.Tables[3].Rows[0][2].ToString();
                userLastName = Session["EmailFromLastName"].ToString();
                userLastName = char.ToUpper(userLastName[0]) + userLastName.Substring(1);
            }

            for (int i = 0; i < iRole1Count; i++)
            {
                if (sCCArray[i].ToString() != Session["EmailTO"].ToString())
                {
                    if (sCCUserName[i].ToString() == Session["UserName"].ToString() || sCCUserName[i].ToString() == "peter.dosanjh" || sCCUserName[i].ToString() == "suba.sandhu" || sCCUserName[i].ToString() == "arjan.dosanjh" || sCCUserName[i].ToString() == "karen.bellchamber")
                    {
                        if (sCCArray[i].ToString().Contains("@monarchpartnership.co.uk"))
                        {
                            sCCEmailID[iCCCount] = sCCArray[i].ToString();
                            iCCCount++;
                        }
                    }
                }
            }

            SmtpClient smtpClient = new SmtpClient();
            MailMessage message = new MailMessage();           

            MailAddress fromAddress = new MailAddress(Session["EmailFrom"].ToString(), userFirstName + " " + userLastName );

            smtpClient.Host = "Exchange2010";
            smtpClient.Port = 25;

            message.From = fromAddress;

            message.To.Add(Session["EmailTO"].ToString());

            for (int i = 0; i < iCCCount; i++)
            {
                message.CC.Add(sCCEmailID[i].ToString());
            }

            message.Subject = "Auto generated message - New Account Progress Report(" + Session["CustomerName"].ToString() + ")";

            message.IsBodyHtml = true;

            message.Body = "<font face='Calibri' color='#1F497D'><p>Dear " + accountManagerFirstName + " " + accountManagerLastName + "</p><p>This is to inform you that you have been assigned to a new account <b>" + Session["CustomerName"].ToString() + "</b>.<br/><br/>Please familiarize yourself with this account by reading the Client Information Sheet (CIS) pages and with any other notes made by Sales and/or any documents in the file. The ownership of this account has been allocated to you. It is your responsibility to ensure that the electricity and gas contracts are now negotiated asap. Should you require any further information, please contact Jas.<br/><br/>Please note that you must record all contact (via telephone and email) with this client on the New Account Progress tab on the Dashboard. This is essential as absence of this information would indicate that no contact has been made by you with the new client. There are times when Sales Department may feel that insufficient action is taken  on a new account, therefore, it is your responsibility to ensure that the contact made with the client is recorded.<br/><br/>The recording of this information is required until the electricity and gas contracts have been negotiated. The New Account Progress page is designed to record and display information until the first round of  electricity and gas CNBs have been completed and the account starts to run smoothly.<br/><br/></p></font><font face='Tahoma' color='#808080' size=2><p><b>" + userFirstName + " " + userLastName + "<br/>The Monarch Partnership<br/>Monarch House,<br/>7-9 Stafford Road, Wallington, Surrey SM6 9AN<br/>Main Switchboard: 0208 835 3535 Fax: 0208 835 3536<br/></b></p></font><font face='Calibri' color='#1F497D' size=2><p><b>(Please note this is an auto generated message)</b></p></font>";

            message.Priority = MailPriority.High;
            message.Headers.Add("Disposition-Notification-To", Session["EmailFrom"].ToString());            
            
            smtpClient.Send(message);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GeneralAdministration", "SendMail", ex.Message);
        }
    }



    protected void AddNewReason(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserName"] != null)
            {
                string sReason = string.Empty;
                sReason = ((TextBox)grdReason.FooterRow.FindControl("txtReason")).Text;

                DALGeneralAdministration objAddNewReason = new DALGeneralAdministration();

                DataSet dsLoadReasonAfterAdd = new DataSet();
                dsLoadReasonAfterAdd = objAddNewReason.InsertNewReasonGeneralAdministration(Session["UserName"].ToString(), Convert.ToInt32(Session["CustID"].ToString()), sReason);
                
                DataTable dtHistoryGridAfterAdd = new DataTable("HistoryGridAfterAdd");
                dtHistoryGridAfterAdd = dsLoadReasonAfterAdd.Tables[0];
                Session["ReasonGrid"] = dtHistoryGridAfterAdd;
                grdReason.DataSource = Session["ReasonGrid"];
                grdReason.DataBind();
            }
            else
            {
                Response.Redirect("login.aspx", false);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GeneralAdministration", "AddNewReason", ex.Message);
        }
        finally
        { }
    }

    //private void BindReasonGrid()
    //{
    //    DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
    //    DataTable dtLoadReason = new DataTable();
    //    try
    //    {
    //        dtLoadReason = objGeneralAdministration.LoadGeneralAdministrationReason(Convert.ToInt32(Session["CustID"].ToString()));
    //        if (dtLoadReason != null)
    //        {
    //            Session["ReasonGrid"] = dtLoadReason;
    //            grdReason.DataSource = dtLoadReason;
    //            grdReason.DataBind();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GeneralAdministration", "BindReasonGrid", ex.Message);
    //    }
    //}


    private void BindReasonGrid()
    {
        try
        {
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();

            DataSet ds = new DataSet();

            ds = objGeneralAdministration.LoadGeneralAdministrationReason(Convert.ToInt32(Session["CustID"].ToString()));

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("ID");
            dtnull.Columns.Add("Reason");
            dtnull.Columns.Add("ReasonDate");            

            if (ds.Tables[0].Rows.Count != 0)
            {
                DataTable dtBindReasonGrid = new DataTable("BindReasonGrid");
                dtBindReasonGrid = ds.Tables[0];
                Session["ReasonGrid"] = dtBindReasonGrid;
                grdReason.DataSource = Session["ReasonGrid"];
                grdReason.DataBind();                
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["ID"] = 0;
                d["Reason"] = null;
                d["ReasonDate"] = null;               
                dtnull.Rows.Add(d);
                grdReason.DataSource = dtnull;
                grdReason.DataBind();
                grdReason.Rows[0].Visible = false;
                grdReason.Rows[0].Controls.Clear();                
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GeneralAdministration", "BindReasonGrid", ex.Message);
        }
    }


    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        grdReason.PageIndex = e.NewPageIndex;
        grdReason.DataSource = (DataTable)Session["ReasonGrid"];
        grdReason.DataBind();
    }


}