﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ClientChecklist : System.Web.UI.Page
{
    int Cust_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        //////temp remove later starts
        //Session["CustID"] = "5";
        //Session["CompanyName"] = "testcompantname";
        //Session["RoleID"] = "1";
        //Session["UserName"] = "brakash";
        //////temp remove later ends

        if (Session["RoleID"] == null)
        {
            Response.Redirect("login.asp");
        }

        if (!IsPostBack)
        {
            if (Session["RoleID"] != null && Convert.ToInt32(Session["RoleID"].ToString()) <= 3)
            {
                BindDataClientChecklist();
            }
            else
            {
                Response.Redirect("login.asp");
            }
        } 


    }



    public void BindDataClientChecklist()
    {
        try
        {
            DALGeneralAdministration objLoadHHSTariffParent = new DALGeneralAdministration();
            DataSet dsClientChecklist = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            dsClientChecklist = objLoadHHSTariffParent.LoadClientChecklist(Cust_id);

            if (dsClientChecklist.Tables[0].Rows.Count != 0)
            {
                chkHH_Data.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["HH_Data"]));
                chkNetwork_Capacity_Agreement.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Network_Capacity_Agreement"]));
                chkDistribution_Losses.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Distribution_Losses"]));
                chkTransmission_Losses.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Transmission_Losses"]));
                chkMetering_Related_Charges.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Metering_Related_Charges"]));
                chkBill_Validation_Exceptions.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Bill_Validation_Exceptions"]));
                chkCurrent_NHH_Electricity_Tariff.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Current_NHH_Electricity_Tariff"]));
                chkCurrent_Gas_Tariff.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Current_Gas_Tariff"]));
                chkCurrent_Water_Tariff.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["Current_Water_Tariff"]));
                chkVAT_Charges.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["VAT_Charges"]));
                chkCL_Charges.Checked = Convert.ToBoolean(Convert.ToString(dsClientChecklist.Tables[0].Rows[0]["CL_Charges"]));
            }
            else
            {
                
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "HHS Tariff Parent", "BindDataHHSTariff", ex.Message);
        }
    }




    protected void btnClientCheckListSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int iHH_Data = 0;
            if (chkHH_Data.Checked)
            {
                iHH_Data = 1;               
            }

            int iNetwork_Capacity_Agreement = 0;
            if (chkNetwork_Capacity_Agreement.Checked)
            {
                iNetwork_Capacity_Agreement = 1;
            }

            int iDistribution_Losses = 0;
            if (chkDistribution_Losses.Checked)
            {
                iDistribution_Losses = 1;
            }

            int iTransmission_Losses = 0;
            if (chkTransmission_Losses.Checked)
            {
                iTransmission_Losses = 1;
            }

            int iMetering_Related_Charges = 0;
            if (chkMetering_Related_Charges.Checked)
            {
                iMetering_Related_Charges = 1;
            }

            int iBill_Validation_Exceptions = 0;
            if (chkBill_Validation_Exceptions.Checked)
            {
                iBill_Validation_Exceptions = 1;
            }

            int iCurrent_NHH_Electricity_Tariff = 0;
            if (chkCurrent_NHH_Electricity_Tariff.Checked)
            {
                iCurrent_NHH_Electricity_Tariff = 1;
            }

            int iCurrent_Gas_Tariff = 0;
            if (chkCurrent_Gas_Tariff.Checked)
            {
                iCurrent_Gas_Tariff = 1;
            }

            int iCurrent_Water_Tariff = 0;
            if (chkCurrent_Water_Tariff.Checked)
            {
                iCurrent_Water_Tariff = 1;
            }

            int iVAT_Charges = 0;
            if (chkVAT_Charges.Checked)
            {
                iVAT_Charges = 1;
            }

            int iCL_Charges = 0;
            if (chkCL_Charges.Checked)
            {
                iCL_Charges = 1;
            }                

            DALGeneralAdministration objSaveClientChecklist = new DALGeneralAdministration();

            Int64 iClientChecklistSaved = 0;
            iClientChecklistSaved = objSaveClientChecklist.SaveClientChecklistGA(Cust_id, iHH_Data, iNetwork_Capacity_Agreement, iDistribution_Losses, iTransmission_Losses, iMetering_Related_Charges, iBill_Validation_Exceptions, iCurrent_NHH_Electricity_Tariff, iCurrent_Gas_Tariff, iCurrent_Water_Tariff, iVAT_Charges, iCL_Charges, Convert.ToString(Session["UserName"]));
            if (iClientChecklistSaved > 0)
            {                
                BindDataClientChecklist();
            }
            else if (iClientChecklistSaved == 0)
            {
                //display java script warning message not saved 
                Response.Redirect("ClientChecklist.aspx", false);
            }         
            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "ClientCheckList", "btnClientCheckListSave", ex.Message);
        }
    }

    protected void btnClientCheckListCancel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("ClientChecklist.aspx", false);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "ClientCheckList", "btnClientCheckListCancel", ex.Message);
        }
    }








}