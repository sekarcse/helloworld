﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Calculator : System.Web.UI.Page
{
    string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

    static Int32 iValidData = 0;

    int Cust_id = 0;
    
    protected void Page_Load(object sender, EventArgs e)
    {

        ////////temp remove later starts
        //Session["CustID"] = "3";
        //Session["CompanyName"] = "testcompantname";
        //Session["RoleID"] = "1";
        ////////temp remove later ends
        
        
        iValidData = 0;

        //temp remove later [UNCOMMENT LATER] starts
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
        //temp remove later [UNCOMMENT LATER] ends

        if (!IsPostBack)
        {
            divUploadHalfHourData.Visible = true;            
        }
    }


    /// <summary>
    /// Clicking the Validate button would load the Excel file to Grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnValidateHalfHourData_Click(object sender, EventArgs e)
    {
        try
        {
            //// Check to see if file was uploaded
            if (fileUploadHalfHourDataDetails.PostedFile != null)
            {
                //// Get a reference to PostedFile object
                HttpPostedFile myFile = fileUploadHalfHourDataDetails.PostedFile;

                //// Get the size of uploaded file
                int nFileLen = myFile.ContentLength;

                //// make sure the size of the file is > 0
                if (nFileLen > 0)
                {
                    //// Allocate a buffer for reading of the file
                    byte[] myData = new byte[nFileLen];

                    //// Read uploaded file from the Stream
                    myFile.InputStream.Read(myData, 0, nFileLen);

                    //// Create a name for the file to store
                    string strFilename = Path.GetFileName(myFile.FileName);

                    //// Write data into a file
                    String sWebServerFolderName = System.Configuration.ConfigurationManager.AppSettings["HalfHourlySiteFolderName"].ToString();
                    WriteToFile(Server.MapPath("~\\" + sWebServerFolderName + "\\" + strFilename), ref myData);
                    Import_To_Grid(Server.MapPath("~\\" + sWebServerFolderName + "\\" + strFilename), ".xlsx", "true");
                }
            }
        }
        catch (Exception ex)
        {
            lblHalfHourDataDetailsGridError.Text = "Error in excel file";
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Default", "btnValidateHalfHourData_Click", ex.Message);
        }
    }

    /// <summary>
    /// Writes the Excel file to the newly created file in Web Server Folder
    /// </summary>
    /// <param name="filepath"></param>
    /// <param name="Buffer"></param> 
    private void WriteToFile(string filepath, ref byte[] Buffer)
    {
        //// Create a file
        FileStream newFile = new FileStream(filepath, FileMode.Create);

        //// Write data to the file
        newFile.Write(Buffer, 0, Buffer.Length);

        //// Close file
        newFile.Close();
    }

    /// <summary>
    /// Import the file into the Grid
    /// </summary>
    /// <param name="FilePath"></param>
    /// <param name="Extension"></param>
    /// <param name="isHDR"></param>
    private void Import_To_Grid(string FilePath, string Extension, string isHDR)
    {
        string conStr = "";

        switch (Extension)
        {
            case ".xls": ////Excel 97-03
                conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                break;
            case ".xlsx": ////Excel 07
                conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                break;
        }

        conStr = String.Format(conStr, FilePath, isHDR);

        OleDbConnection connExcel = new OleDbConnection(conStr);
        OleDbCommand cmdExcel = new OleDbCommand();
        OleDbDataAdapter oda = new OleDbDataAdapter();

        DataTable dt = new DataTable();

        cmdExcel.Connection = connExcel;

        ////Get the name of First Sheet
        ////http://www.microsoft.com/en-us/download/confirmation.aspx?id=23734 -  install the following

        connExcel.Open();

        DataTable dtExcelSchema;
        dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
        string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
        connExcel.Close();

        ////Read Data from First Sheet
        connExcel.Open();

        //To handle null records Starts
        //cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
        cmdExcel.CommandText = "SELECT * From [" + SheetName + "] where not Date is null";
        //To handle null records Ends


        oda.SelectCommand = cmdExcel;
        oda.Fill(dt);
        connExcel.Close();

        grdHalfHourDataDetails.Visible = true;        
        divMatchedUnmatchedNewHalfHourlySite.Visible = true;        
        
        divUploadHalfHourData.Visible = false;

        //// SQLBulkCopy starts
        //// To delete the existing records in Temp_HalfHourDataImport starts - temp
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            SqlCommand cmdDelete = new SqlCommand(
                "DELETE FROM " +
                "Temp_HalfHourDataImport;",
                connection);
            cmdDelete.ExecuteNonQuery();
            connection.Close();
        }
        //// To delete the existing records in Temp_HalfHourDataImport ends - temp

        // Open a connection to the database. 
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            // Perform an initial count on the destination table.
            SqlCommand commandRowCount = new SqlCommand(
                "SELECT COUNT(*) FROM " +
                "Temp_HalfHourDataImport;",
                connection);
            long countStart = System.Convert.ToInt32(
                commandRowCount.ExecuteScalar());
            // lblRecordsBeforeImport.Text = "Number of rows before import : " + countStart;            

            // Create a data table 
            //DataTable dtbulkcopy = dt;
            DataTable dtbulkcopy = new DataTable();
            dtbulkcopy = dt;
            DataColumn Import = dtbulkcopy.Columns.Add("Import", typeof(bool));
            Import.SetOrdinal(0);
            //dtbulkcopy.Columns.Add("ImportID", typeof(Int32));
            DataColumn ImportID = dtbulkcopy.Columns.Add("ImportID", typeof(Int32));
            ImportID.SetOrdinal(1);
            int iImportID = 0;
            foreach (DataRow dr in dtbulkcopy.Rows)
            {
                iImportID += 1;
                dr["Import"] = true;
                dr["ImportID"] = iImportID;

            }

            // Create the SqlBulkCopy object.  
            // Note that the column positions in the source DataTable  
            // match the column positions in the destination table so  
            // there is no need to map columns.  
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
            {
                bulkCopy.DestinationTableName = "Temp_HalfHourDataImport";

                try
                {
                    // Write from the source to the destination.
                    bulkCopy.WriteToServer(dtbulkcopy);
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "Import_To_Grid", ex.Message);
                }
            }

            // Perform a final count on the destination  
            // table to see how many rows were added. 
            long countEnd = System.Convert.ToInt32(commandRowCount.ExecuteScalar());

            //// close the connection once imported
            connection.Close();
        }
        //// SQLBulkCopy ends

        lblFileName.Text = "Uploaded File Name : " + Path.GetFileName(FilePath);
        //// Populate data into Grid from the database table
        BindData();
    }

    /// <summary>
    /// Populate data into Grid from the datatable starts
    /// </summary>
    /// <param name="FilePath"></param>
    private void BindData()
    {
        try
        {
            string sHalfHourDataTableName = "Temp_HalfHourDataImport";

            DALCalculator objCalculator = new DALCalculator();
            DataSet ds = new DataSet();

            ds = objCalculator.HalfHourDataDetails(sHalfHourDataTableName);

            

            divUnmatchedMPANGrid.Visible = false;
            divMatchedMPANGrid.Visible = false;
            divCalculatePeriodRateGrid.Visible = false;
            divTariffCalculationGrid.Visible = false;
            divCalculateFactoral.Visible = false;

            divHalfHourDataGrid.Visible = true;

            if (ds.Tables[0] != null)
            {

                Session["HalfHourDataGrid"] = ds.Tables[0];
                grdHalfHourDataDetails.DataSource = Session["HalfHourDataGrid"];
                grdHalfHourDataDetails.DataBind();

                if (iValidData == 0)
                {
                    divMatchedUnmatchedNewHalfHourlySite.Visible = true;
                }
                else
                {
                    divMatchedUnmatchedNewHalfHourlySite.Visible = false;
                }
            }
            else
            {
                
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "BindData", ex.Message);
        }
    }
    

    /// <summary>
    /// validate the uploaded HalfHourData details
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdHalfHourDataDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
    }

    /// <summary>
    /// Row editing event for the GridView
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdHalfHourDataDetails_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdHalfHourDataDetails.EditIndex = e.NewEditIndex;
        //// to reload the data
        grdHalfHourDataDetails.DataSource = (DataTable)Session["HalfHourDataGrid"];
        grdHalfHourDataDetails.DataBind();
    }

    /// <summary>
    /// Row canceling event for the GridView
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdHalfHourDataDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        e.Cancel = true;
        grdHalfHourDataDetails.EditIndex = -1;
        //// to reload the data
        grdHalfHourDataDetails.DataSource = (DataTable)Session["HalfHourDataGrid"];
        grdHalfHourDataDetails.DataBind();
    }

    /// <summary>
    /// Row updating event for the GridView
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void grdHalfHourDataDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
        GridViewRow row = grdHalfHourDataDetails.Rows[e.RowIndex];

        TextBox txtLocationID = (TextBox)row.FindControl("txtLocationID");
        TextBox txtTaxPointDate = (TextBox)row.FindControl("txtTaxPointDate");
        TextBox txtMeterPointReference = (TextBox)row.FindControl("txtMeterPointReference");
        TextBox txtReadingType = (TextBox)row.FindControl("txtReadingType");
        TextBox txtPrice = (TextBox)row.FindControl("txtPrice");

        int importID = Int32.Parse(grdHalfHourDataDetails.DataKeys[e.RowIndex].Value.ToString());

        string sLocationID = txtLocationID.Text;
        string sTaxPointDate = txtTaxPointDate.Text;
        string sMeterPointReference = txtMeterPointReference.Text;
        string sReadingType = txtReadingType.Text;
        string sPrice = txtPrice.Text;

        UpdateProduct(importID, sLocationID, sTaxPointDate, sMeterPointReference, sReadingType, sPrice);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "grdHalfHourDataDetails_RowUpdating", "grdHalfHourDataDetails_RowUpdating", ex.Message);
        }
    }

    /// <summary>
    /// Edit the Imported HalfHourData data
    /// </summary>
    /// <param name="importID"></param>
    /// <param name="sLocationID"></param>
    /// <param name="sTaxPointDate"></param>
    /// <param name="sMeterPointReference"></param>
    /// <param name="sReadingType"></param>
    /// <param name="sPrice"></param>
    private void UpdateProduct(int importID, string sLocationID, string sTaxPointDate, string sMeterPointReference, string sReadingType, string sPrice)
    {
        try
        {
            string query = "UPDATE Temp_HalfHourDataImport SET LocationID = @LocationID, TaxPointDate = @TaxPointDate, MeterPointReference = @MeterPointReference, ReadingType=@ReadingType, Price=@Price WHERE ImportID = @ImportID";

            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand cmdUpdateHalfHourDataDetails = new SqlCommand(query, conn);

            cmdUpdateHalfHourDataDetails.Parameters.Add("@LocationID", SqlDbType.NVarChar).Value = sLocationID;
            cmdUpdateHalfHourDataDetails.Parameters.Add("@TaxPointDate", SqlDbType.NVarChar).Value = sTaxPointDate;
            cmdUpdateHalfHourDataDetails.Parameters.Add("@MeterPointReference", SqlDbType.NVarChar).Value = sMeterPointReference;
            cmdUpdateHalfHourDataDetails.Parameters.Add("@ImportID", SqlDbType.Int).Value = importID;
            cmdUpdateHalfHourDataDetails.Parameters.Add("@ReadingType", SqlDbType.NVarChar).Value = sReadingType;
            cmdUpdateHalfHourDataDetails.Parameters.Add("@Price", SqlDbType.NVarChar).Value = sPrice;

            conn.Open();
            cmdUpdateHalfHourDataDetails.ExecuteNonQuery();
            conn.Close();

            grdHalfHourDataDetails.EditIndex = -1;
            //// to reload the data
            BindData();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator Update Imported Data", "UpdateProduct", ex.Message);
        }
    }

    /// <summary>
    /// To maintain the checked status of the data in database
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public void chkHalfHourDataImport_OnCheckedChanged(object sender, EventArgs e)
    {
        try
        {
        CheckBox chkHalfHourDataImport = (CheckBox)sender;
        GridViewRow row = (GridViewRow)chkHalfHourDataImport.NamingContainer;

        string sImportID = row.Cells[1].Text;
        bool status = chkHalfHourDataImport.Checked;

        string query = "UPDATE Temp_HalfHourDataImport SET Import = @Import WHERE ImportID = @ImportID";

        SqlConnection conChecked = new SqlConnection(connectionString);
        SqlCommand cmdChecked = new SqlCommand(query, conChecked);

        cmdChecked.Parameters.Add("@Import", SqlDbType.Bit).Value = status;
        cmdChecked.Parameters.Add("@ImportID", SqlDbType.Int).Value = sImportID;

        conChecked.Open();
        cmdChecked.ExecuteNonQuery();
        conChecked.Close();

        BindData();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "chkHalfHourDataImport_OnCheckedChanged", "chkHalfHourDataImport_OnCheckedChanged", ex.Message);
        }
    }

    /// <summary>
    /// Retrieve only the MPAN that matches for appropriate Client
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnMatchedMPAN_Click(object sender, EventArgs e)
    {
        try
        {
            divHalfHourDataGrid.Visible = false;
            divUnmatchedMPANGrid.Visible = false;
            divCalculatePeriodRateGrid.Visible = false;
            divTariffCalculationGrid.Visible = false;
            divCalculateFactoral.Visible = false;

            divMatchedMPANGrid.Visible = true;


            DALCalculator objCalculator = new DALCalculator();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objCalculator.getMatchedMPAN(Cust_id);

            if (ds.Tables[0].Rows.Count != null)
            {
                DataTable dtLoadMatchedMPAN = new DataTable("LoadMatchedMPANGrid");
                dtLoadMatchedMPAN = ds.Tables[0];
                Session["MatchedMPANGrid"] = dtLoadMatchedMPAN;
                grdMatchedMPAN.DataSource = Session["MatchedMPANGrid"];
                grdMatchedMPAN.DataBind();
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "btnMatchedMPAN_Click", ex.Message);
        }
    }

    /// <summary>
    /// Display the MPAN that do not match
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnUnmatchedMPAN_Click(object sender, EventArgs e)
    {
        try
        {
            divHalfHourDataGrid.Visible = false;
            divMatchedMPANGrid.Visible = false;
            divCalculatePeriodRateGrid.Visible = false;
            divTariffCalculationGrid.Visible = false;
            divCalculateFactoral.Visible = false;

            divUnmatchedMPANGrid.Visible = true;

            DALCalculator objCalculator = new DALCalculator();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objCalculator.getUnmatchedMPAN(Cust_id);

            if (ds.Tables[0].Rows.Count != null)
            {
                DataTable dtLoadUnmatchedMPAN = new DataTable("LoadUnmatchedMPANGrid");
                dtLoadUnmatchedMPAN = ds.Tables[0];
                Session["UnmatchedMPANGrid"] = dtLoadUnmatchedMPAN;
                grdUnmatchedMPAN.DataSource = Session["UnmatchedMPANGrid"];
                grdUnmatchedMPAN.DataBind();
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "btnUnmatchedMPAN_Click", ex.Message);
        }
    }


    protected void btnNewHalfHourDataFileUpload_Click(object sender, EventArgs e)
    {
        try
        {

        lblErrorTariffMismatch.Visible = false;
        lblErrorTariffMismatch.Text = string.Empty;

        divMatchedUnmatchedNewHalfHourlySite.Visible = false;
        divHalfHourDataGrid.Visible = false;
        divMatchedMPANGrid.Visible = false;
        divUnmatchedMPANGrid.Visible = false;
        divCalculatePeriodRateGrid.Visible = false;
        divTariffCalculationGrid.Visible = false;
        divCalculateFactoral.Visible = false;

        divUploadHalfHourData.Visible = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "btnNewHalfHourDataFileUpload_Click", "btnNewHalfHourDataFileUpload_Click", ex.Message);
        }
    }


    /// <summary>
    /// Calculate rate with Period 1 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCalculatePeriodRate_Click(object sender, EventArgs e)
    {
        try
        {
        
        DALCalculator objCalculatePeriodRate = new DALCalculator();

        DataSet ds = new DataSet();

        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        ds = objCalculatePeriodRate.getCalculatePeriodRate();

        if (ds.Tables[0].Rows != null)
        {
            DataTable dtLoadCalculatePeriodRate = new DataTable("LoadCalculatePeriodRateGrid");
            dtLoadCalculatePeriodRate = ds.Tables[0];
            //Session["CalculatePeriodRateGrid"] = dtLoadCalculatePeriodRate;


            double[] dPeriod1TotalTimeBandsArray;
            dPeriod1TotalTimeBandsArray = new double[500];

            double[] dPeriod2TotalTimeBandsArray;
            dPeriod2TotalTimeBandsArray = new double[500];

            double[] dPeriod3TotalTimeBandsArray;
            dPeriod3TotalTimeBandsArray = new double[500];

            double[] dPeriod4TotalTimeBandsArray;
            dPeriod4TotalTimeBandsArray = new double[500];

            double[] dPeriod5TotalTimeBandsArray;
            dPeriod5TotalTimeBandsArray = new double[500];

            string[] sMPANArray;
            sMPANArray = new string[500];

            int iCalculatePeriodRateMPANCount = 0;
            
            //Get every distinct MPAN Number
            for (int i = 0; i < dtLoadCalculatePeriodRate.Rows.Count; i++)
            {
                DataRow myRow = dtLoadCalculatePeriodRate.Rows[i];
                //string MyValue = myRow["mpan"].ToString();
                string sMPAN = Convert.ToString(myRow["mpan"]).Trim();

                if (sMPAN.Length == 21)
                {
                    string sLineLossCode = string.Empty;
                    string SDistributionID = string.Empty;
                    sLineLossCode = sMPAN.Substring(5, 3);
                    SDistributionID = sMPAN.Substring(8, 2);

                    DataSet dsLineLossUsingDistributionDetails = new DataSet();

                    dsLineLossUsingDistributionDetails = objCalculatePeriodRate.LineLossUsingDistributionDetails(sLineLossCode, SDistributionID);

                    if (dsLineLossUsingDistributionDetails.Tables[0].Rows != null)
                    {
                        if (dsLineLossUsingDistributionDetails.Tables[0].Rows.Count == 1)
                        {
                            String sRegional_Elec_Company = string.Empty;
                            String sDID = string.Empty;
                            String Metered_Voltage = string.Empty;
                            String Period1_DLAFs = string.Empty;
                            String Period2_DLAFs = string.Empty;
                            String Period3_DLAFs = string.Empty;
                            String Period4_DLAFs = string.Empty;
                            String Period5_DLAFs = string.Empty;

                            sRegional_Elec_Company = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Regional_Elec_Company"]).Trim();
                            sDID = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["DID"]).Trim();
                            Metered_Voltage = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Metered_Voltage"]).Trim();
                            Period1_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period1_DLAFs"]).Trim();
                            Period2_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period2_DLAFs"]).Trim();
                            Period3_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period3_DLAFs"]).Trim();
                            Period4_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period4_DLAFs"]).Trim();
                            Period5_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period5_DLAFs"]).Trim();

                            DataSet dsTimeBandsPeriodDetails = new DataSet();
                            dsTimeBandsPeriodDetails = objCalculatePeriodRate.TimeBandsPeriodDetails(sRegional_Elec_Company, sDID);


                            double dConsolidatedTimeBandsValuePeriod1 = 0;
                            double dConsolidatedTimeBandsValuePeriod2 = 0;
                            double dConsolidatedTimeBandsValuePeriod3 = 0;
                            double dConsolidatedTimeBandsValuePeriod4 = 0;
                            double dConsolidatedTimeBandsValuePeriod5 = 0;
                            
                            ////Looping from Period 1 to Period 5 in ST_TimeBands Starts
                            for (int p = 0; p < dsTimeBandsPeriodDetails.Tables[0].Rows.Count; p++)
                            {
                                ////Calculation for Period 1 Starts
                                if (Period1_DLAFs.Length > 0 && Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Period"]).Trim() == "Period 1")
                                {
                                    string sStartDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Day"]).Trim();
                                    string sEndDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Day"]).Trim();
                                    string sStartMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Month"]).Trim();
                                    string sEndMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Month"]).Trim();
                                    string sStartTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Time"]).Trim();
                                    string sEndTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Time"]).Trim();                                    

                                    //Calculate if not null for all 6 Parameters Starts
                                    if (sStartDay.Length > 0 && sEndDay.Length > 0 && sStartMonth.Length > 0 && sEndMonth.Length > 0 && sStartTime.Length > 0 && sEndTime.Length > 0)
                                    {
                                        double[] dSumTimeBandsArray;
                                        dSumTimeBandsArray = new double[50];

                                        int iStartTime = 0;
                                        int iEndTime = 0;

                                        GenericPeriodCalculation(sStartDay, sEndDay, sStartMonth, sEndMonth, sStartTime, sEndTime, sMPAN, dSumTimeBandsArray, iStartTime, iEndTime);

                                        string sStartTimeDecimalNumber = sStartTime.Replace(":", ".");
                                        string sEndTimeDecimalNumber = sEndTime.Replace(":", ".");

                                        iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                        iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);

                                        if (iStartTime <= iEndTime)
                                        {
                                            for (int k = iStartTime + 1; k <= iEndTime; k++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod1 = dConsolidatedTimeBandsValuePeriod1 + dSumTimeBandsArray[k];
                                            }
                                        }
                                        else if (iStartTime > iEndTime)
                                        {
                                            for (int m = iStartTime + 1; m <= 47; m++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod1 = dConsolidatedTimeBandsValuePeriod1 + dSumTimeBandsArray[m];
                                            }
                                            for (int n = 0; n <= iEndTime; n++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod1 = dConsolidatedTimeBandsValuePeriod1 + dSumTimeBandsArray[n];
                                            }
                                        }

                                        
                                    }
                                    //Calculate if not null for all 6 Parameters Ends
                                }
                                ////Calculation for Period 1 Ends

                                ////Calculation for Period 2 Starts
                                if (Period2_DLAFs.Length > 0 && Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Period"]).Trim() == "Period 2")
                                {
                                    string sStartDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Day"]).Trim();
                                    string sEndDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Day"]).Trim();
                                    string sStartMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Month"]).Trim();
                                    string sEndMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Month"]).Trim();
                                    string sStartTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Time"]).Trim();
                                    string sEndTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Time"]).Trim();

                                    //Calculate if not null for all 6 Parameters Starts
                                    if (sStartDay.Length > 0 && sEndDay.Length > 0 && sStartMonth.Length > 0 && sEndMonth.Length > 0 && sStartTime.Length > 0 && sEndTime.Length > 0)
                                    {
                                        double[] dSumTimeBandsArray;
                                        dSumTimeBandsArray = new double[50];

                                        int iStartTime = 0;
                                        int iEndTime = 0;

                                        GenericPeriodCalculation(sStartDay, sEndDay, sStartMonth, sEndMonth, sStartTime, sEndTime, sMPAN, dSumTimeBandsArray, iStartTime, iEndTime);

                                        string sStartTimeDecimalNumber = sStartTime.Replace(":", ".");
                                        string sEndTimeDecimalNumber = sEndTime.Replace(":", ".");

                                        iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                        iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);
                                    
                                        if (iStartTime <= iEndTime)
                                        {
                                            for (int k = iStartTime + 1; k <= iEndTime; k++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod2 = dConsolidatedTimeBandsValuePeriod2 + dSumTimeBandsArray[k];
                                            }
                                        }
                                        else if (iStartTime > iEndTime)
                                        {
                                            for (int m = iStartTime + 1; m <= 47; m++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod2 = dConsolidatedTimeBandsValuePeriod2 + dSumTimeBandsArray[m];
                                            }
                                            for (int n = 0; n <= iEndTime; n++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod2 = dConsolidatedTimeBandsValuePeriod2 + dSumTimeBandsArray[n];
                                            }
                                        }

                                        
                                    }
                                    //Calculate if not null for all 6 Parameters Ends

                                }
                                ////Calculation for Period 2 Ends

                                ////Calculation for Period 3 Starts
                                if (Period3_DLAFs.Length > 0 && Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Period"]).Trim() == "Period 3")
                                {
                                    string sStartDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Day"]).Trim();
                                    string sEndDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Day"]).Trim();
                                    string sStartMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Month"]).Trim();
                                    string sEndMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Month"]).Trim();
                                    string sStartTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Time"]).Trim();
                                    string sEndTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Time"]).Trim();

                                    //Calculate if not null for all 6 Parameters Starts
                                    if (sStartDay.Length > 0 && sEndDay.Length > 0 && sStartMonth.Length > 0 && sEndMonth.Length > 0 && sStartTime.Length > 0 && sEndTime.Length > 0)
                                    {
                                        double[] dSumTimeBandsArray;
                                        dSumTimeBandsArray = new double[50];

                                        int iStartTime = 0;
                                        int iEndTime = 0;

                                        GenericPeriodCalculation(sStartDay, sEndDay, sStartMonth, sEndMonth, sStartTime, sEndTime, sMPAN, dSumTimeBandsArray, iStartTime, iEndTime);

                                        string sStartTimeDecimalNumber = sStartTime.Replace(":", ".");
                                        string sEndTimeDecimalNumber = sEndTime.Replace(":", ".");

                                        iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                        iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);
                                    
                                        if (iStartTime <= iEndTime)
                                        {
                                            for (int k = iStartTime + 1; k <= iEndTime; k++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod3 = dConsolidatedTimeBandsValuePeriod3 + dSumTimeBandsArray[k];
                                            }
                                        }
                                        else if (iStartTime > iEndTime)
                                        {
                                            for (int m = iStartTime + 1; m <= 47; m++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod3 = dConsolidatedTimeBandsValuePeriod3 + dSumTimeBandsArray[m];
                                            }
                                            for (int n = 0; n <= iEndTime; n++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod3 = dConsolidatedTimeBandsValuePeriod3 + dSumTimeBandsArray[n];
                                            }
                                        }

                                        
                                    }
                                    //Calculate if not null for all 6 Parameters Ends
                                }
                                ////Calculation for Period 3 Ends

                                ////Calculation for Period 4 Starts
                                if (Period4_DLAFs.Length > 0 && Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Period"]).Trim() == "Period 4")
                                {
                                    string sStartDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Day"]).Trim();
                                    string sEndDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Day"]).Trim();
                                    string sStartMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Month"]).Trim();
                                    string sEndMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Month"]).Trim();
                                    string sStartTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Time"]).Trim();
                                    string sEndTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Time"]).Trim();

                                    //Calculate if not null for all 6 Parameters Starts
                                    if (sStartDay.Length > 0 && sEndDay.Length > 0 && sStartMonth.Length > 0 && sEndMonth.Length > 0 && sStartTime.Length > 0 && sEndTime.Length > 0)
                                    {
                                        double[] dSumTimeBandsArray;
                                        dSumTimeBandsArray = new double[50];

                                        int iStartTime = 0;
                                        int iEndTime = 0;

                                        GenericPeriodCalculation(sStartDay, sEndDay, sStartMonth, sEndMonth, sStartTime, sEndTime, sMPAN, dSumTimeBandsArray, iStartTime, iEndTime);

                                        string sStartTimeDecimalNumber = sStartTime.Replace(":", ".");
                                        string sEndTimeDecimalNumber = sEndTime.Replace(":", ".");

                                        iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                        iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);
                                    
                                        if (iStartTime <= iEndTime)
                                        {
                                            for (int k = iStartTime + 1; k <= iEndTime; k++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod4 = dConsolidatedTimeBandsValuePeriod4 + dSumTimeBandsArray[k];
                                            }
                                        }
                                        else if (iStartTime > iEndTime)
                                        {
                                            for (int m = iStartTime + 1; m <= 47; m++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod4 = dConsolidatedTimeBandsValuePeriod4 + dSumTimeBandsArray[m];
                                            }
                                            for (int n = 0; n <= iEndTime; n++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod4 = dConsolidatedTimeBandsValuePeriod4 + dSumTimeBandsArray[n];
                                            }
                                        }

                                        
                                    }
                                    //Calculate if not null for all 6 Parameters Ends
                                }
                                ////Calculation for Period 4 Ends

                                ////Calculation for Period 5 Starts
                                if (Period5_DLAFs.Length > 0 && Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Period"]).Trim() == "Period 5")
                                {
                                    string sStartDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Day"]).Trim();
                                    string sEndDay = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Day"]).Trim();
                                    string sStartMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Month"]).Trim();
                                    string sEndMonth = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Month"]).Trim();
                                    string sStartTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["Start_Time"]).Trim();
                                    string sEndTime = Convert.ToString(dsTimeBandsPeriodDetails.Tables[0].Rows[p]["End_Time"]).Trim();

                                    //Calculate if not null for all 6 Parameters Starts
                                    if (sStartDay.Length > 0 && sEndDay.Length > 0 && sStartMonth.Length > 0 && sEndMonth.Length > 0 && sStartTime.Length > 0 && sEndTime.Length > 0)
                                    {
                                        double[] dSumTimeBandsArray;
                                        dSumTimeBandsArray = new double[50];

                                        int iStartTime = 0;
                                        int iEndTime = 0;

                                        GenericPeriodCalculation(sStartDay, sEndDay, sStartMonth, sEndMonth, sStartTime, sEndTime, sMPAN, dSumTimeBandsArray, iStartTime, iEndTime);

                                        string sStartTimeDecimalNumber = sStartTime.Replace(":", ".");
                                        string sEndTimeDecimalNumber = sEndTime.Replace(":", ".");

                                        iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                        iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);

                                        if (iStartTime <= iEndTime)
                                        {
                                            for (int k = iStartTime + 1; k <= iEndTime; k++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod5 = dConsolidatedTimeBandsValuePeriod5 + dSumTimeBandsArray[k];
                                            }
                                        }
                                        else if (iStartTime > iEndTime)
                                        {
                                            for (int m = iStartTime + 1; m <= 47; m++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod5 = dConsolidatedTimeBandsValuePeriod5 + dSumTimeBandsArray[m];
                                            }
                                            for (int n = 0; n <= iEndTime; n++)
                                            {
                                                dConsolidatedTimeBandsValuePeriod5 = dConsolidatedTimeBandsValuePeriod5 + dSumTimeBandsArray[n];
                                            }
                                        }

                                        
                                    }
                                    //Calculate if not null for all 6 Parameters Ends
                                }
                                ////Calculation for Period 5 Ends

                            }
                            ////Looping from Period 1 to Period 5 in ST_TimeBands Ends

                            //code for grid starts here                            
                            sMPANArray[i] = sMPAN;                            

                            if (Period1_DLAFs.Length > 0)
                            {
                                dPeriod1TotalTimeBandsArray[i] = dConsolidatedTimeBandsValuePeriod1 * Convert.ToDouble(Period1_DLAFs);
                            }
                            
                            if (Period2_DLAFs.Length > 0)
                            {
                                dPeriod2TotalTimeBandsArray[i] = dConsolidatedTimeBandsValuePeriod2 * Convert.ToDouble(Period2_DLAFs);
                            }
                            
                            if (Period3_DLAFs.Length > 0)
                            {
                                dPeriod3TotalTimeBandsArray[i] = dConsolidatedTimeBandsValuePeriod3 * Convert.ToDouble(Period3_DLAFs);
                            }
                            
                            if (Period4_DLAFs.Length > 0)
                            {
                                dPeriod4TotalTimeBandsArray[i] = dConsolidatedTimeBandsValuePeriod4 * Convert.ToDouble(Period4_DLAFs);
                            }

                            if (Period5_DLAFs.Length > 0)
                            {
                                dPeriod5TotalTimeBandsArray[i] = dConsolidatedTimeBandsValuePeriod5 * Convert.ToDouble(Period5_DLAFs);
                            }

                            iCalculatePeriodRateMPANCount = iCalculatePeriodRateMPANCount + 1;                            

                        }
                        //end of if when ST_LineLoss has only one record so that we can identify correct Period1_DLAFs to Period5_DLAFs value
                    }
                }
                //end of if loop(mpan is 21 digits)
            }
            //end of for loop for every distinct mpan number(MPAN for loop ends)

            BindCalculationPeriodRateGrid(sMPANArray, dPeriod1TotalTimeBandsArray, dPeriod2TotalTimeBandsArray, dPeriod3TotalTimeBandsArray, dPeriod4TotalTimeBandsArray, dPeriod5TotalTimeBandsArray, iCalculatePeriodRateMPANCount);

        }
        //end of if for finding unique mpan number
        }
        //end of try block
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "btnCalculatePeriodRate_Click", ex.Message);
        }
    }
    
    public void GenericPeriodCalculation(string sStartDay, string sEndDay, string sStartMonth, string sEndMonth, string sStartTime, string sEndTime, string sMPAN, double[] dSumTimeBandsArray, int iStartTime, int iEndTime)
    {
        try
        {
            int iStartDay = 0;
            int iEndDay = 0;
            int iStartMonth = 0;
            int iEndMonth = 0;

            switch (sStartDay.ToLower())
            {
                case "sun":
                    iStartDay = 1;
                    break;
                case "mon":
                    iStartDay = 2;
                    break;
                case "tue":
                    iStartDay = 3;
                    break;
                case "wed":
                    iStartDay = 4;
                    break;
                case "thu":
                    iStartDay = 5;
                    break;
                case "fri":
                    iStartDay = 6;
                    break;
                case "sat":
                    iStartDay = 7;
                    break;
                default:
                    iStartDay = 0;
                    break;
            }

            switch (sEndDay.ToLower())
            {
                case "sun":
                    iEndDay = 1;
                    break;
                case "mon":
                    iEndDay = 2;
                    break;
                case "tue":
                    iEndDay = 3;
                    break;
                case "wed":
                    iEndDay = 4;
                    break;
                case "thu":
                    iEndDay = 5;
                    break;
                case "fri":
                    iEndDay = 6;
                    break;
                case "sat":
                    iEndDay = 7;
                    break;
                default:
                    iEndDay = 0;
                    break;
            }

            switch (sStartMonth.ToLower())
            {
                case "jan":
                    iStartMonth = 1;
                    break;
                case "feb":
                    iStartMonth = 2;
                    break;
                case "mar":
                    iStartMonth = 3;
                    break;
                case "apr":
                    iStartMonth = 4;
                    break;
                case "may":
                    iStartMonth = 5;
                    break;
                case "jun":
                    iStartMonth = 6;
                    break;
                case "jul":
                    iStartMonth = 7;
                    break;
                case "aug":
                    iStartMonth = 8;
                    break;
                case "sep":
                    iStartMonth = 9;
                    break;
                case "oct":
                    iStartMonth = 10;
                    break;
                case "nov":
                    iStartMonth = 11;
                    break;
                case "dec":
                    iStartMonth = 12;
                    break;
                default:
                    iStartMonth = 0;
                    break;
            }


            switch (sEndMonth.ToLower())
            {
                case "jan":
                    iEndMonth = 1;
                    break;
                case "feb":
                    iEndMonth = 2;
                    break;
                case "mar":
                    iEndMonth = 3;
                    break;
                case "apr":
                    iEndMonth = 4;
                    break;
                case "may":
                    iEndMonth = 5;
                    break;
                case "jun":
                    iEndMonth = 6;
                    break;
                case "jul":
                    iEndMonth = 7;
                    break;
                case "aug":
                    iEndMonth = 8;
                    break;
                case "sep":
                    iEndMonth = 9;
                    break;
                case "oct":
                    iEndMonth = 10;
                    break;
                case "nov":
                    iEndMonth = 11;
                    break;
                case "dec":
                    iEndMonth = 12;
                    break;
                default:
                    iEndMonth = 0;
                    break;
            }

            DALCalculator objGenericPeriodCalculation = new DALCalculator();

            DataSet dsCalculateTotalUnitsFromTimeBands = new DataSet();
            dsCalculateTotalUnitsFromTimeBands = objGenericPeriodCalculation.CalculateTotalUnitsFromTimeBands(iStartDay, iEndDay, iStartMonth, iEndMonth, sStartTime, sEndTime, sMPAN);
            
            DataTable dtCalculateTotalUnitsFromTimeBands = new DataTable("CalculateTotalUnitsFromTimeBands");
            dtCalculateTotalUnitsFromTimeBands = dsCalculateTotalUnitsFromTimeBands.Tables[0];
                              
            for (int j = 0; j < dtCalculateTotalUnitsFromTimeBands.Rows.Count; j++)
            {
                dSumTimeBandsArray[0] = dSumTimeBandsArray[0] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["00:00"]).Trim());
                dSumTimeBandsArray[1] = dSumTimeBandsArray[1] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["00:30"]).Trim());
                dSumTimeBandsArray[2] = dSumTimeBandsArray[2] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["01:00"]).Trim());
                dSumTimeBandsArray[3] = dSumTimeBandsArray[3] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["01:30"]).Trim());
                dSumTimeBandsArray[4] = dSumTimeBandsArray[4] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["02:00"]).Trim());
                dSumTimeBandsArray[5] = dSumTimeBandsArray[5] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["02:30"]).Trim());
                dSumTimeBandsArray[6] = dSumTimeBandsArray[6] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["03:00"]).Trim());
                dSumTimeBandsArray[7] = dSumTimeBandsArray[7] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["03:30"]).Trim());
                dSumTimeBandsArray[8] = dSumTimeBandsArray[8] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["04:00"]).Trim());
                dSumTimeBandsArray[9] = dSumTimeBandsArray[9] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["04:30"]).Trim());
                dSumTimeBandsArray[10] = dSumTimeBandsArray[10] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["05:00"]).Trim());
                dSumTimeBandsArray[11] = dSumTimeBandsArray[11] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["05:30"]).Trim());
                dSumTimeBandsArray[12] = dSumTimeBandsArray[12] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["06:00"]).Trim());
                dSumTimeBandsArray[13] = dSumTimeBandsArray[13] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["06:30"]).Trim());
                dSumTimeBandsArray[14] = dSumTimeBandsArray[14] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["07:00"]).Trim());
                dSumTimeBandsArray[15] = dSumTimeBandsArray[15] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["07:30"]).Trim());
                dSumTimeBandsArray[16] = dSumTimeBandsArray[16] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["08:00"]).Trim());
                dSumTimeBandsArray[17] = dSumTimeBandsArray[17] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["08:30"]).Trim());
                dSumTimeBandsArray[18] = dSumTimeBandsArray[18] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["09:00"]).Trim());
                dSumTimeBandsArray[19] = dSumTimeBandsArray[19] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["09:30"]).Trim());
                dSumTimeBandsArray[20] = dSumTimeBandsArray[20] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["10:00"]).Trim());
                dSumTimeBandsArray[21] = dSumTimeBandsArray[21] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["10:30"]).Trim());
                dSumTimeBandsArray[22] = dSumTimeBandsArray[22] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["11:00"]).Trim());
                dSumTimeBandsArray[23] = dSumTimeBandsArray[23] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["11:30"]).Trim());
                dSumTimeBandsArray[24] = dSumTimeBandsArray[24] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["12:00"]).Trim());
                dSumTimeBandsArray[25] = dSumTimeBandsArray[25] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["12:30"]).Trim());
                dSumTimeBandsArray[26] = dSumTimeBandsArray[26] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["13:00"]).Trim());
                dSumTimeBandsArray[27] = dSumTimeBandsArray[27] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["13:30"]).Trim());
                dSumTimeBandsArray[28] = dSumTimeBandsArray[28] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["14:00"]).Trim());
                dSumTimeBandsArray[29] = dSumTimeBandsArray[29] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["14:30"]).Trim());
                dSumTimeBandsArray[30] = dSumTimeBandsArray[30] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["15:00"]).Trim());
                dSumTimeBandsArray[31] = dSumTimeBandsArray[31] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["15:30"]).Trim());
                dSumTimeBandsArray[32] = dSumTimeBandsArray[32] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["16:00"]).Trim());
                dSumTimeBandsArray[33] = dSumTimeBandsArray[33] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["16:30"]).Trim());
                dSumTimeBandsArray[34] = dSumTimeBandsArray[34] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["17:00"]).Trim());
                dSumTimeBandsArray[35] = dSumTimeBandsArray[35] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["17:30"]).Trim());
                dSumTimeBandsArray[36] = dSumTimeBandsArray[36] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["18:00"]).Trim());
                dSumTimeBandsArray[37] = dSumTimeBandsArray[37] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["18:30"]).Trim());
                dSumTimeBandsArray[38] = dSumTimeBandsArray[38] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["19:00"]).Trim());
                dSumTimeBandsArray[39] = dSumTimeBandsArray[39] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["19:30"]).Trim());
                dSumTimeBandsArray[40] = dSumTimeBandsArray[40] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["20:00"]).Trim());
                dSumTimeBandsArray[41] = dSumTimeBandsArray[41] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["20:30"]).Trim());
                dSumTimeBandsArray[42] = dSumTimeBandsArray[42] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["21:00"]).Trim());
                dSumTimeBandsArray[43] = dSumTimeBandsArray[43] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["21:30"]).Trim());
                dSumTimeBandsArray[44] = dSumTimeBandsArray[44] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["22:00"]).Trim());
                dSumTimeBandsArray[45] = dSumTimeBandsArray[45] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["22:30"]).Trim());
                dSumTimeBandsArray[46] = dSumTimeBandsArray[46] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["23:00"]).Trim());
                dSumTimeBandsArray[47] = dSumTimeBandsArray[47] + Convert.ToDouble(Convert.ToString(dtCalculateTotalUnitsFromTimeBands.Rows[j]["23:30"]).Trim());

            }            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GenericPeriodCalculation", "GenericPeriodCalculation", ex.Message);
        }
    }


    private void BindCalculationPeriodRateGrid(string[] sMPANArray, double[] dPeriod1TotalTimeBandsArray, double[] dPeriod2TotalTimeBandsArray, double[] dPeriod3TotalTimeBandsArray, double[] dPeriod4TotalTimeBandsArray, double[] dPeriod5TotalTimeBandsArray, int iCalculatePeriodRateMPANCount)
    {
        try
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("lblCalculatePeriodRateMPAN");
            dt.Columns.Add("lblCalculatePeriodRatePeriod1");
            dt.Columns.Add("lblCalculatePeriodRatePeriod2");
            dt.Columns.Add("lblCalculatePeriodRatePeriod3");
            dt.Columns.Add("lblCalculatePeriodRatePeriod4");
            dt.Columns.Add("lblCalculatePeriodRatePeriod5");            

            for (int i = 0; i < iCalculatePeriodRateMPANCount; i++)
            {
                dt.Rows.Add();
                dt.Rows[i]["lblCalculatePeriodRateMPAN"] = Convert.ToString(sMPANArray[i]);
                dt.Rows[i]["lblCalculatePeriodRatePeriod1"] = Convert.ToString(dPeriod1TotalTimeBandsArray[i]);
                dt.Rows[i]["lblCalculatePeriodRatePeriod2"] = Convert.ToString(dPeriod2TotalTimeBandsArray[i]);
                dt.Rows[i]["lblCalculatePeriodRatePeriod3"] = Convert.ToString(dPeriod3TotalTimeBandsArray[i]);
                dt.Rows[i]["lblCalculatePeriodRatePeriod4"] = Convert.ToString(dPeriod4TotalTimeBandsArray[i]);
                dt.Rows[i]["lblCalculatePeriodRatePeriod5"] = Convert.ToString(dPeriod5TotalTimeBandsArray[i]);  
            }

            divUnmatchedMPANGrid.Visible = false;
            divMatchedMPANGrid.Visible = false;
            divHalfHourDataGrid.Visible = false; 
            divTariffCalculationGrid.Visible = false;
            divCalculateFactoral.Visible = false;

            divCalculatePeriodRateGrid.Visible = true;            

            if (dt != null)
            {
                grdCalculatePeriodRate.DataSource = dt;
                grdCalculatePeriodRate.DataBind();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "BindCalculationPeriodRateGrid", ex.Message);
        }
    }


    protected void btnCalculateTariff_Click(object sender, EventArgs e)
    {
        try
        {
            DALCalculator objValidateTariff = new DALCalculator();

            DataSet dsValidateTariff = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            dsValidateTariff = objValidateTariff.ValidateTariff(Cust_id);

            if (dsValidateTariff.Tables[0].Rows != null && dsValidateTariff.Tables[1].Rows != null)
            {
                DateTime dTariffStartDate = Convert.ToDateTime(dsValidateTariff.Tables[0].Rows[0]["TariffStartDate"]);
                DateTime dTariffEndDate = Convert.ToDateTime(dsValidateTariff.Tables[0].Rows[0]["TariffEndDate"]);

                DateTime dExcelMinimumDate = Convert.ToDateTime(dsValidateTariff.Tables[1].Rows[0]["ExcelMinimumDate"]);
                DateTime dExcelMaximumDate = Convert.ToDateTime(dsValidateTariff.Tables[1].Rows[0]["ExcelMaximumDate"]);
                //txtDateElecRenewal.Text = dRetainElecRenewalDate.ToShortDateString();

                if (dTariffEndDate >= dTariffStartDate)
                {
                    if (dTariffStartDate <= dExcelMaximumDate && dTariffEndDate >= dExcelMinimumDate)
                    {

                        DALCalculator objMPANforTariffCalculation = new DALCalculator();

                        DataSet ds = new DataSet();

                        if (Session["CustID"] != null)
                            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

                        ds = objMPANforTariffCalculation.GetMPANforTariffCalculation();

                        if (ds.Tables[0].Rows != null)
                        {
                            DataTable dtLoadMPANforTariffCalculation = new DataTable("LoadMPANforTariffCalculation");
                            dtLoadMPANforTariffCalculation = ds.Tables[0];

                            double[] dArrayTariffCalculationDay;
                            dArrayTariffCalculationDay = new double[500];

                            double[] dArrayTariffCalculationNight;
                            dArrayTariffCalculationNight = new double[500];

                            string[] sMPANArrayTariff;
                            sMPANArrayTariff = new string[500];

                            int iTariffCalculationMPANCount = 0;

                            //to display start date in Grid(Declaration) Starts
                            string sHHS_Tariff_Start_date = string.Empty;

                            string sHHS_Tariff_Reading_StartTimeDay = string.Empty;
                            string sHHS_Tariff_Reading_EndTimeDay = string.Empty;

                            string sHHS_Tariff_Reading_StartTimeNight = string.Empty;
                            string sHHS_Tariff_Reading_EndTimeNight = string.Empty;

                            string sStanding_Charge = string.Empty;
                            //to display start date in Grid(Declaration) Ends

                            //Get every distinct MPAN Number Starts
                            for (int i = 0; i < dtLoadMPANforTariffCalculation.Rows.Count; i++)
                            {
                                DataRow myRow = dtLoadMPANforTariffCalculation.Rows[i];
                                string sMPAN = Convert.ToString(myRow["mpan"]).Trim();

                                if (sMPAN.Length == 21)
                                {
                                    DALCalculator objCalculateTariff = new DALCalculator();

                                    DataSet dsCalculateTariff = new DataSet();
                                    dsCalculateTariff = objCalculateTariff.getCalculateTariff(Cust_id);

                                    if (dsCalculateTariff.Tables[0].Rows.Count > 0)
                                    {
                                        double dConsolidatedTimeTariffDay = 0;
                                        double dConsolidatedTimeTariffNight = 0;

                                        double dConsolidatedTimeTariffDayWithRate = 0;
                                        double dConsolidatedTimeTariffNightWithRate = 0;

                                        //to display start date in Grid Starts
                                        sHHS_Tariff_Start_date = Convert.ToString(dsCalculateTariff.Tables[0].Rows[0]["Start_date"]).Trim();
                                        //to display start date in Grid Ends

                                        ////to display Standing Charge in Grid Starts
                                        sStanding_Charge = Convert.ToString(dsCalculateTariff.Tables[0].Rows[0]["std_charge_day"]).Trim();
                                        ////to display Standing Charge in Grid Ends

                                        ////Looping from day read to night read in HHs_Tariff starts
                                        for (int p = 0; p < dsCalculateTariff.Tables[0].Rows.Count; p++)
                                        {

                                            ////Calculation for Tariff Day Starts
                                            if (Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_Type"]).Trim().ToLower() == "day")
                                            {
                                                string sStart_date = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Start_date"]).Trim();
                                                string sEnd_date = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["End_date"]).Trim();
                                                string sReading_StartTime = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_StartTime"]).Trim();
                                                string sReading_EndTime = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_EndTime"]).Trim();
                                                double dRate = Convert.ToDouble(Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Rate"]).Trim());

                                                //to display start time and end time for DAY in Grid Starts
                                                sHHS_Tariff_Reading_StartTimeDay = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_StartTime"]).Trim();
                                                sHHS_Tariff_Reading_EndTimeDay = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_EndTime"]).Trim();
                                                //to display start time and end time for DAY in Grid Ends


                                                //Calculate if not null for all 4 Parameters Starts
                                                if (sStart_date.Length > 0 && sEnd_date.Length > 0 && sReading_StartTime.Length > 0 && sReading_EndTime.Length > 0)
                                                {
                                                    DateTime dStart_date = Convert.ToDateTime(sStart_date);
                                                    DateTime dEnd_date = Convert.ToDateTime(sEnd_date);

                                                    double[] dSumTariffWithTime;
                                                    dSumTariffWithTime = new double[50];

                                                    int iStartTime = 0;
                                                    int iEndTime = 0;

                                                    GenericTariffCalculation(dStart_date, dEnd_date, sReading_StartTime, sReading_EndTime, sMPAN, dSumTariffWithTime, iStartTime, iEndTime);

                                                    string sStartTimeDecimalNumber = sReading_StartTime.Replace(":", ".");
                                                    string sEndTimeDecimalNumber = sReading_EndTime.Replace(":", ".");

                                                    iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                                    iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);

                                                    if (iStartTime <= iEndTime)
                                                    {
                                                        //Start time should be excluded hence it should be iStartTime + 1
                                                        //for (int k = iStartTime; k <= iEndTime; k++)
                                                        //for (int k = iStartTime + 1; k <= iEndTime; k++)
                                                        for (int k = iStartTime; k <= iEndTime - 1; k++)
                                                        {
                                                            dConsolidatedTimeTariffDay = dConsolidatedTimeTariffDay + dSumTariffWithTime[k];
                                                        }
                                                    }
                                                    else if (iStartTime > iEndTime)
                                                    {
                                                        //Start time should be excluded hence it should be iStartTime + 1
                                                        //for (int m = iStartTime; m <= 47; m++)
                                                        //for (int m = iStartTime + 1; m <= 47; m++)
                                                        for (int m = iStartTime; m <= 47; m++)
                                                        {
                                                            dConsolidatedTimeTariffDay = dConsolidatedTimeTariffDay + dSumTariffWithTime[m];
                                                        }
                                                        for (int n = 0; n <= iEndTime - 1; n++)
                                                        {
                                                            dConsolidatedTimeTariffDay = dConsolidatedTimeTariffDay + dSumTariffWithTime[n];
                                                        }
                                                    }
                                                    dConsolidatedTimeTariffDayWithRate = dConsolidatedTimeTariffDay * dRate;
                                                }
                                                //Calculate if not null for all 4 Parameters Ends
                                            }
                                            ////Calculation for Tariff Day Ends

                                            ////Calculation for Tariff Night Starts
                                            if (Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_Type"]).Trim().ToLower() == "night")
                                            {
                                                string sStart_date = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Start_date"]).Trim();
                                                string sEnd_date = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["End_date"]).Trim();
                                                string sReading_StartTime = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_StartTime"]).Trim();
                                                string sReading_EndTime = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_EndTime"]).Trim();
                                                double dRate = Convert.ToDouble(Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Rate"]).Trim());

                                                //to display start time and end time for NIGHT in Grid Starts
                                                sHHS_Tariff_Reading_StartTimeNight = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_StartTime"]).Trim();
                                                sHHS_Tariff_Reading_EndTimeNight = Convert.ToString(dsCalculateTariff.Tables[0].Rows[p]["Reading_EndTime"]).Trim();
                                                //to display start time and end time for NIGHT in Grid Ends

                                                //Calculate if not null for all 4 Parameters Starts
                                                if (sStart_date.Length > 0 && sEnd_date.Length > 0 && sReading_StartTime.Length > 0 && sReading_EndTime.Length > 0)
                                                {
                                                    DateTime dStart_date = Convert.ToDateTime(sStart_date);
                                                    DateTime dEnd_date = Convert.ToDateTime(sEnd_date);

                                                    double[] dSumTariffWithTime;
                                                    dSumTariffWithTime = new double[50];

                                                    int iStartTime = 0;
                                                    int iEndTime = 0;

                                                    GenericTariffCalculation(dStart_date, dEnd_date, sReading_StartTime, sReading_EndTime, sMPAN, dSumTariffWithTime, iStartTime, iEndTime);

                                                    string sStartTimeDecimalNumber = sReading_StartTime.Replace(":", ".");
                                                    string sEndTimeDecimalNumber = sReading_EndTime.Replace(":", ".");

                                                    iStartTime = Convert.ToInt32(Convert.ToDecimal(sStartTimeDecimalNumber) * 2);
                                                    iEndTime = Convert.ToInt32(Convert.ToDecimal(sEndTimeDecimalNumber) * 2);

                                                    if (iStartTime <= iEndTime)
                                                    {
                                                        for (int k = iStartTime; k <= iEndTime - 1; k++)
                                                        {
                                                            dConsolidatedTimeTariffNight = dConsolidatedTimeTariffNight + dSumTariffWithTime[k];
                                                        }
                                                    }
                                                    else if (iStartTime > iEndTime)
                                                    {
                                                        for (int m = iStartTime; m <= 47; m++)
                                                        {
                                                            dConsolidatedTimeTariffNight = dConsolidatedTimeTariffNight + dSumTariffWithTime[m];
                                                        }
                                                        for (int n = 0; n <= iEndTime - 1; n++)
                                                        {
                                                            dConsolidatedTimeTariffNight = dConsolidatedTimeTariffNight + dSumTariffWithTime[n];
                                                        }
                                                    }
                                                    dConsolidatedTimeTariffNightWithRate = dConsolidatedTimeTariffNight * dRate;

                                                }
                                                //Calculate if not null for all 4 Parameters Ends
                                            }
                                            ////Calculation for Tariff Night Ends

                                        }
                                        ////Looping from day read to night read in HHs_Tariff starts

                                        sMPANArrayTariff[i] = sMPAN;
                                        //dArrayTariffCalculationDay[i] = dConsolidatedTimeTariffDay * some formula;

                                        ////Before adding Rate in Table Starts
                                        //dArrayTariffCalculationDay[i] = dConsolidatedTimeTariffDay;
                                        //dArrayTariffCalculationNight[i] = dConsolidatedTimeTariffNight;
                                        ////Before adding Rate in Table Ends

                                        //After adding Rate in Table Starts
                                        dArrayTariffCalculationDay[i] = dConsolidatedTimeTariffDayWithRate / 100;
                                        dArrayTariffCalculationNight[i] = dConsolidatedTimeTariffNightWithRate / 100;
                                        //Before adding Rate in Table Ends

                                        iTariffCalculationMPANCount = iTariffCalculationMPANCount + 1;
                                    }
                                    //end of if loop for dsCalculateTariff != null                     
                                }
                                //end of if loop  (mpan is 21 digits)

                            }
                            //Get every distinct MPAN Number Ends(MPAN for loop ends)

                            BindTariffCalculationGrid(sMPANArrayTariff, dArrayTariffCalculationDay, dArrayTariffCalculationNight, iTariffCalculationMPANCount, sHHS_Tariff_Start_date, sHHS_Tariff_Reading_StartTimeDay, sHHS_Tariff_Reading_EndTimeDay, sHHS_Tariff_Reading_StartTimeNight, sHHS_Tariff_Reading_EndTimeNight, sStanding_Charge);
                        }
                        lblErrorTariffMismatch.Visible = false;
                        lblErrorTariffMismatch.Text = string.Empty;
                    }
                    else if (dTariffStartDate > dExcelMaximumDate)
                    {
                        //tariff start date is higher than all the date in import file
                        //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "TariffStartDateHigher()", true);
                        lblErrorTariffMismatch.Visible = true;
                        lblErrorTariffMismatch.Text = "Tariff start date is higher than the date in Excel file";
                    }
                    else if (dTariffEndDate < dExcelMinimumDate)
                    {
                        //tariff end date is smaller than all the date in import file
                        //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "TariffEndDateLower()", true);
                        lblErrorTariffMismatch.Visible = true;
                        lblErrorTariffMismatch.Text = "Tariff end date is smaller than the date in Excel file";
                        
                    }                    
                }
                else if(dTariffEndDate < dTariffStartDate)
                {
                    lblErrorTariffMismatch.Visible = true;
                    lblErrorTariffMismatch.Text = "Tariff end date is smaller than Tariff start date";
                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "btnCalculateTariff_Click", "btnCalculateTariff_Click", ex.Message);
        }
    }
     


    public void GenericTariffCalculation(DateTime dStart_date, DateTime dEnd_date, string sReading_StartTime, string sReading_EndTime, string sMPAN, double[] dSumTariffWithTime, int iStartTime, int iEndTime)
    {
        try
        {
            DALCalculator objGenericTariffCalculation = new DALCalculator();

            DataSet dsCalculateTariffTotalWithTime = new DataSet();
            dsCalculateTariffTotalWithTime = objGenericTariffCalculation.CalculateTariffTotalWithTime(dStart_date, dEnd_date, sReading_StartTime, sReading_EndTime, sMPAN);
            
            DataTable dtCalculateTariffTotalWithTime = new DataTable("CalculateTariffTotalWithTime");
            dtCalculateTariffTotalWithTime = dsCalculateTariffTotalWithTime.Tables[0];
            
            for (int j = 0; j < dtCalculateTariffTotalWithTime.Rows.Count; j++)
            {
                dSumTariffWithTime[0] = dSumTariffWithTime[0] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["00:00"]).Trim());
                dSumTariffWithTime[1] = dSumTariffWithTime[1] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["00:30"]).Trim());
                dSumTariffWithTime[2] = dSumTariffWithTime[2] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["01:00"]).Trim());
                dSumTariffWithTime[3] = dSumTariffWithTime[3] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["01:30"]).Trim());
                dSumTariffWithTime[4] = dSumTariffWithTime[4] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["02:00"]).Trim());
                dSumTariffWithTime[5] = dSumTariffWithTime[5] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["02:30"]).Trim());
                dSumTariffWithTime[6] = dSumTariffWithTime[6] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["03:00"]).Trim());
                dSumTariffWithTime[7] = dSumTariffWithTime[7] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["03:30"]).Trim());
                dSumTariffWithTime[8] = dSumTariffWithTime[8] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["04:00"]).Trim());
                dSumTariffWithTime[9] = dSumTariffWithTime[9] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["04:30"]).Trim());
                dSumTariffWithTime[10] = dSumTariffWithTime[10] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["05:00"]).Trim());
                dSumTariffWithTime[11] = dSumTariffWithTime[11] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["05:30"]).Trim());
                dSumTariffWithTime[12] = dSumTariffWithTime[12] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["06:00"]).Trim());
                dSumTariffWithTime[13] = dSumTariffWithTime[13] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["06:30"]).Trim());
                dSumTariffWithTime[14] = dSumTariffWithTime[14] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["07:00"]).Trim());
                dSumTariffWithTime[15] = dSumTariffWithTime[15] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["07:30"]).Trim());
                dSumTariffWithTime[16] = dSumTariffWithTime[16] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["08:00"]).Trim());
                dSumTariffWithTime[17] = dSumTariffWithTime[17] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["08:30"]).Trim());
                dSumTariffWithTime[18] = dSumTariffWithTime[18] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["09:00"]).Trim());
                dSumTariffWithTime[19] = dSumTariffWithTime[19] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["09:30"]).Trim());
                dSumTariffWithTime[20] = dSumTariffWithTime[20] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["10:00"]).Trim());
                dSumTariffWithTime[21] = dSumTariffWithTime[21] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["10:30"]).Trim());
                dSumTariffWithTime[22] = dSumTariffWithTime[22] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["11:00"]).Trim());
                dSumTariffWithTime[23] = dSumTariffWithTime[23] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["11:30"]).Trim());
                dSumTariffWithTime[24] = dSumTariffWithTime[24] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["12:00"]).Trim());
                dSumTariffWithTime[25] = dSumTariffWithTime[25] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["12:30"]).Trim());
                dSumTariffWithTime[26] = dSumTariffWithTime[26] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["13:00"]).Trim());
                dSumTariffWithTime[27] = dSumTariffWithTime[27] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["13:30"]).Trim());
                dSumTariffWithTime[28] = dSumTariffWithTime[28] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["14:00"]).Trim());
                dSumTariffWithTime[29] = dSumTariffWithTime[29] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["14:30"]).Trim());
                dSumTariffWithTime[30] = dSumTariffWithTime[30] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["15:00"]).Trim());
                dSumTariffWithTime[31] = dSumTariffWithTime[31] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["15:30"]).Trim());
                dSumTariffWithTime[32] = dSumTariffWithTime[32] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["16:00"]).Trim());
                dSumTariffWithTime[33] = dSumTariffWithTime[33] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["16:30"]).Trim());
                dSumTariffWithTime[34] = dSumTariffWithTime[34] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["17:00"]).Trim());
                dSumTariffWithTime[35] = dSumTariffWithTime[35] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["17:30"]).Trim());
                dSumTariffWithTime[36] = dSumTariffWithTime[36] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["18:00"]).Trim());
                dSumTariffWithTime[37] = dSumTariffWithTime[37] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["18:30"]).Trim());
                dSumTariffWithTime[38] = dSumTariffWithTime[38] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["19:00"]).Trim());
                dSumTariffWithTime[39] = dSumTariffWithTime[39] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["19:30"]).Trim());
                dSumTariffWithTime[40] = dSumTariffWithTime[40] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["20:00"]).Trim());
                dSumTariffWithTime[41] = dSumTariffWithTime[41] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["20:30"]).Trim());
                dSumTariffWithTime[42] = dSumTariffWithTime[42] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["21:00"]).Trim());
                dSumTariffWithTime[43] = dSumTariffWithTime[43] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["21:30"]).Trim());
                dSumTariffWithTime[44] = dSumTariffWithTime[44] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["22:00"]).Trim());
                dSumTariffWithTime[45] = dSumTariffWithTime[45] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["22:30"]).Trim());
                dSumTariffWithTime[46] = dSumTariffWithTime[46] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["23:00"]).Trim());
                dSumTariffWithTime[47] = dSumTariffWithTime[47] + Convert.ToDouble(Convert.ToString(dtCalculateTariffTotalWithTime.Rows[j]["23:30"]).Trim());
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GenericTariffCalculation", "GenericTariffCalculation", ex.Message);
        }
    }


    private void BindTariffCalculationGrid(string[] sMPANArrayTariff, double[] dArrayTariffCalculationDay, double[] dArrayTariffCalculationNight, int iTariffCalculationMPANCount, string sHHS_Tariff_Start_date, string sHHS_Tariff_Reading_StartTimeDay, string sHHS_Tariff_Reading_EndTimeDay, string sHHS_Tariff_Reading_StartTimeNight, string sHHS_Tariff_Reading_EndTimeNight, string sStanding_Charge)
    {
        try
        {

            DataTable dt = new DataTable();
            dt.Columns.Add("lblTariffCalculationStartDate");
            dt.Columns.Add("lblMPANTariffCalculation");
            dt.Columns.Add("lblTariffCalculationDay");
            dt.Columns.Add("lblTariffCalculationNight");
            dt.Columns.Add("lblStandingCharge");
            
            for (int i = 0; i < iTariffCalculationMPANCount; i++)
            {
                dt.Rows.Add();

                dt.Rows[i]["lblTariffCalculationStartDate"] = Convert.ToString(sHHS_Tariff_Start_date.Substring(0,10));

                dt.Rows[i]["lblMPANTariffCalculation"] = Convert.ToString(sMPANArrayTariff[i]);

                //dt.Rows[i]["lblTariffCalculationDay"] = Convert.ToString(dArrayTariffCalculationDay[i]);
                if (dArrayTariffCalculationDay[i] == 0 || dArrayTariffCalculationDay[i] == 0.0)
                {
                    dt.Rows[i]["lblTariffCalculationDay"] = string.Empty;
                }
                else
                {
                    dt.Rows[i]["lblTariffCalculationDay"] = Convert.ToString(Math.Round(Convert.ToDecimal(dArrayTariffCalculationDay[i]), 2));
                }
                
                //dt.Rows[i]["lblTariffCalculationNight"] = Convert.ToString(dArrayTariffCalculationNight[i]);
                if (dArrayTariffCalculationNight[i] == 0 || dArrayTariffCalculationNight[i] == 0.0)
                {
                    dt.Rows[i]["lblTariffCalculationNight"] = string.Empty;
                }
                else
                {
                    dt.Rows[i]["lblTariffCalculationNight"] = Convert.ToString(Math.Round(Convert.ToDecimal(dArrayTariffCalculationNight[i]), 2));
                }

                //dt.Rows[i]["lblStandingCharge"] = Convert.ToString(sStanding_Charge); 
                dt.Rows[i]["lblStandingCharge"] = Convert.ToString(Math.Round(Convert.ToDecimal(sStanding_Charge), 2));                   
            }
            
            divUnmatchedMPANGrid.Visible = false;
            divMatchedMPANGrid.Visible = false;
            divHalfHourDataGrid.Visible = false;
            divCalculatePeriodRateGrid.Visible = false;
            divCalculateFactoral.Visible = false;            

            divTariffCalculationGrid.Visible = true;

            if (sHHS_Tariff_Reading_StartTimeDay.Length > 0)
            {
                hdnTariffCalculationDayStartTimeEndTime.Value = sHHS_Tariff_Reading_StartTimeDay + " to " + sHHS_Tariff_Reading_EndTimeDay;
            }
            else
            {
                hdnTariffCalculationDayStartTimeEndTime.Value = string.Empty;
            }
            if (sHHS_Tariff_Reading_StartTimeNight.Length > 0)
            {
                hdnTariffCalculationNightStartTimeEndTime.Value = sHHS_Tariff_Reading_StartTimeNight + " to " + sHHS_Tariff_Reading_EndTimeNight;
            }
            else
            {
                hdnTariffCalculationNightStartTimeEndTime.Value = string.Empty;
            }

            if (dt != null)
            {
                grdTariffCalculation.DataSource = dt;
                grdTariffCalculation.DataBind();                
            }            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "BindTariffCalculationGrid", ex.Message);
        }
    }



    protected void grdTariffCalculation_RowCreated(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView HeaderGrid = (GridView)sender;
                GridViewRow HeaderGridRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Edit);

                TableHeaderCell HeaderCell = new TableHeaderCell();
                HeaderCell.Text = "";
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableHeaderCell();
                HeaderCell.Text = "";
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableHeaderCell();
                HeaderCell.Text = "";
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableHeaderCell();
                HeaderCell.Text = hdnTariffCalculationDayStartTimeEndTime.Value;
                HeaderCell.ColumnSpan = 1;
                HeaderGridRow.Cells.Add(HeaderCell);



                HeaderCell = new TableHeaderCell();
                HeaderCell.Text = hdnTariffCalculationNightStartTimeEndTime.Value;
                HeaderCell.ColumnSpan = 1;
                HeaderGridRow.Cells.Add(HeaderCell);

                //HeaderCell = new TableHeaderCell();
                //HeaderCell.Text = "";
                //HeaderGridRow.Cells.Add(HeaderCell);

                //HeaderCell = new TableHeaderCell();
                //HeaderCell.Text = "";
                //HeaderGridRow.Cells.Add(HeaderCell);

                grdTariffCalculation.Controls[0].Controls.AddAt(0, HeaderGridRow);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "grdTariffCalculation_RowCreated", "grdTariffCalculation_RowCreated", ex.Message);
        }
    }





    protected void btnFactoral_Click(object sender, EventArgs e)
    {
        try
        {
            lblErrorTariffMismatch.Visible = false;
            lblErrorTariffMismatch.Text = string.Empty;

            divUnmatchedMPANGrid.Visible = false;
            divMatchedMPANGrid.Visible = false;
            divHalfHourDataGrid.Visible = false;
            divCalculatePeriodRateGrid.Visible = false;
            divTariffCalculationGrid.Visible = false;

            divCalculateFactoral.Visible = true;


            GenericUpdateQueryFactoral();

            DALCalculator objCalculator = new DALCalculator();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objCalculator.getCalculateFactoral(Cust_id);

            if (ds.Tables[0].Rows.Count != null)
            {
                DataTable dtLoadCalculateFactoral = new DataTable("LoadCalculateFactoralGrid");
                dtLoadCalculateFactoral = ds.Tables[0];
                Session["CalculateFactoralGrid"] = dtLoadCalculateFactoral;
                grdCalculateFactoral.DataSource = Session["CalculateFactoralGrid"];
                grdCalculateFactoral.DataBind();
            }
        }        
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Calculator", "btnFactoral_Click", ex.Message);
        }
    }



    public void GenericUpdateQueryFactoral()
    {
        try
        {
            DALCalculator objCalculatePeriodRate = new DALCalculator();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objCalculatePeriodRate.getCalculatePeriodRate();

            if (ds.Tables[0].Rows != null)
            {
                DataTable dtLoadCalculatePeriodRate = new DataTable("LoadCalculatePeriodRateGrid");
                dtLoadCalculatePeriodRate = ds.Tables[0];

                double[] dPeriod1TotalTimeBandsArray;
                dPeriod1TotalTimeBandsArray = new double[500];

                double[] dPeriod2TotalTimeBandsArray;
                dPeriod2TotalTimeBandsArray = new double[500];

                double[] dPeriod3TotalTimeBandsArray;
                dPeriod3TotalTimeBandsArray = new double[500];

                double[] dPeriod4TotalTimeBandsArray;
                dPeriod4TotalTimeBandsArray = new double[500];

                double[] dPeriod5TotalTimeBandsArray;
                dPeriod5TotalTimeBandsArray = new double[500];

                string[] sMPANArray;
                sMPANArray = new string[500];

                int iCalculatePeriodRateMPANCount = 0;

                //Get every distinct MPAN Number
                for (int i = 0; i < dtLoadCalculatePeriodRate.Rows.Count; i++)
                {
                    DataRow myRow = dtLoadCalculatePeriodRate.Rows[i];
                    //string MyValue = myRow["mpan"].ToString();
                    string sMPAN = Convert.ToString(myRow["mpan"]).Trim();

                    if (sMPAN.Length == 21)
                    {
                        string sLineLossCode = string.Empty;
                        string SDistributionID = string.Empty;
                        sLineLossCode = sMPAN.Substring(5, 3);
                        SDistributionID = sMPAN.Substring(8, 2);

                        DataSet dsLineLossUsingDistributionDetails = new DataSet();

                        dsLineLossUsingDistributionDetails = objCalculatePeriodRate.LineLossUsingDistributionDetails(sLineLossCode, SDistributionID);

                        if (dsLineLossUsingDistributionDetails.Tables[0].Rows != null)
                        {
                            if (dsLineLossUsingDistributionDetails.Tables[0].Rows.Count == 1)
                            {
                                String sRegional_Elec_Company = string.Empty;
                                String sDID = string.Empty;
                                String Metered_Voltage = string.Empty;
                                String Period1_DLAFs = string.Empty;
                                String Period2_DLAFs = string.Empty;
                                String Period3_DLAFs = string.Empty;
                                String Period4_DLAFs = string.Empty;
                                String Period5_DLAFs = string.Empty;

                                sRegional_Elec_Company = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Regional_Elec_Company"]).Trim();
                                sDID = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["DID"]).Trim();
                                Metered_Voltage = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Metered_Voltage"]).Trim();
                                Period1_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period1_DLAFs"]).Trim();
                                Period2_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period2_DLAFs"]).Trim();
                                Period3_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period3_DLAFs"]).Trim();
                                Period4_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period4_DLAFs"]).Trim();
                                Period5_DLAFs = Convert.ToString(dsLineLossUsingDistributionDetails.Tables[0].Rows[0]["Period5_DLAFs"]).Trim();

                                //DataSet dsTimeBandsPeriodDetails = new DataSet();
                                //dsTimeBandsPeriodDetails = objCalculatePeriodRate.TimeBandsPeriodDetails(sRegional_Elec_Company, sDID);


                                double dConsolidatedTimeBandsValuePeriod1 = 0;
                                double dConsolidatedTimeBandsValuePeriod2 = 0;
                                double dConsolidatedTimeBandsValuePeriod3 = 0;
                                double dConsolidatedTimeBandsValuePeriod4 = 0;
                                double dConsolidatedTimeBandsValuePeriod5 = 0;                                                               

                                //code for grid starts here                            
                                sMPANArray[i] = sMPAN;
                                //if (Metered_Voltage == "Low Voltage Network" && sDID == "19")
                                //{
                                //    //550 and 19
                                //    objCalculatePeriodRate.UpdateWithPeriodSouthEastLowVoltageNetwork19(sMPAN);
                                //}
                                //else if(Metered_Voltage == "Low Voltage Network" && sDID == "12")
                                //{
                                //    objCalculatePeriodRate.UpdateWithPeriodLondonLowVoltageNetwork12(sMPAN);
                                //}


                                if (sDID == "19" || sDID == "10" || sDID == "12")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodSouthEastDID19(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "11" || sDID == "14")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodEastMidlandsDID11(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "17" || sDID == "20")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodScottishHydroDID17(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "21")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodSWALECDID21(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "22")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodSWEBDID22(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "23")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodYorkshireDID23(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "13" || sDID == "18")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodMANWEBDID13(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "16")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodNorthWestDID16(sMPAN, Metered_Voltage, sDID);
                                }
                                else if (sDID == "15")
                                {
                                    objCalculatePeriodRate.UpdateWithPeriodNorthernDID15(sMPAN, Metered_Voltage, sDID);
                                }

                                //iCalculatePeriodRateMPANCount = iCalculatePeriodRateMPANCount + 1;

                            }
                            //end of if when ST_LineLoss has only one record so that we can identify correct Period1_DLAFs to Period5_DLAFs value
                        }
                    }
                    //end of if loop(mpan is 21 digits)
                }
                //end of for loop for every distinct mpan number(MPAN for loop ends)

                //BindCalculationPeriodRateGrid(sMPANArray, dPeriod1TotalTimeBandsArray, dPeriod2TotalTimeBandsArray, dPeriod3TotalTimeBandsArray, dPeriod4TotalTimeBandsArray, dPeriod5TotalTimeBandsArray, iCalculatePeriodRateMPANCount);

            }
            //end of if for finding unique mpan number
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "GenericUpdateQueryFactoral", "GenericUpdateQueryFactoral", ex.Message);
        }
    }


    //protected void grdCalculateFactoral_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {                          
    //        //// Testing for 00:00
    //        double d0000 = 0;
    //        Label lbl0000 = ((Label)e.Row.FindControl("lbl0000"));
    //        if (lbl0000 != null)
    //        {
    //            e.Row.Cells[2].Text = Convert.ToString(Convert.ToDouble(lbl0000.Text) * Convert.ToDouble(5.5));
    //        }
    //        else{               
    //        }
    //    }
    //    //end of if e.Row.RowType == DataControlRowType.DataRow
    //}


}