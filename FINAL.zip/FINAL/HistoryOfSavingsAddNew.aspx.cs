﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HistoryOfSavingsAddNew : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["CommandHOS"] = "cancel";
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "CancelHOSAddNew()", true);
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Session["CommandHOS"] = "save";
        try
        {
            DALHistorySavings objSavings = new DALHistorySavings();
            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            DateTime DateFrom = Convert.ToDateTime(txtFromDate.Text);
            DateTime DateTo = Convert.ToDateTime(txtToDate.Text);
            int SavingType = Convert.ToInt32(ddlSaving_type.SelectedIndex);
            int Utilitytype = Convert.ToInt32(ddlUtility_type.SelectedIndex);
            double Amount = Convert.ToDouble(txtAmount.Text);
            int CNB = Convert.ToInt32(txtCNB.Text);
            string Description = Convert.ToString(txtShortSummary.Text);
            string Create_User = Session["UserName"].ToString();
            objSavings.AddNewInserthistorysavings(Cust_id, DateFrom, DateTo, SavingType, Utilitytype, Amount, Description, Create_User, CNB);
           
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveHOSAddNew()", true);

            string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

            // ASP.NET 2.0
            if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


}