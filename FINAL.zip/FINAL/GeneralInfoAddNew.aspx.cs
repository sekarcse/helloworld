﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GeneralInfoAddNew : System.Web.UI.Page
{
    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
    }    

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["RoleID"] == null)
            Response.Redirect("login.asp");
        Session["CommandGeneralInfo"] = "save";
        try
        {
            DALGeneralInfo objGeneralInfo = new DALGeneralInfo();
            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            DateTime Date = Convert.ToDateTime(txtDate.Text);
            string Description = Convert.ToString(txtDescription.Text);
            
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;

            if (FileUpload.HasFile)
            {
                CurrentFileName = FileUpload.FileName;
                FileUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\GeneralInfoFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\GeneralInfoFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + FileUpload.FileName;
            }
            objGeneralInfo.GeneralInfoAddNewInsertHistoryGeneralInfo(Cust_id, Date, CurrentFileName, CurrentFilePath, Description, Create_User);
            
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveGeneralInfoAddNew()", true);

            string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

            // ASP.NET 2.0
            if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Dashboard History General Information", "btnSave_Click", ex.Message);
        }
    }  



}