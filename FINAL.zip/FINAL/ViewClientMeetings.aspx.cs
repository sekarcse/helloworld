﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class ViewClientMeetings : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["RoleID"] == null)
            Response.Redirect("login.asp");

            getMeetingHist();
        }
    }

    public void getMeetingHist()
    {

        DALMeetingHist objMeetingHist = new DALMeetingHist();
        DataSet ds = new DataSet();

        int Cust_id = 0;
        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        ds = objMeetingHist.getAllMeetingHistories(2,Cust_id);

        grdViewDetails.DataSource = ds.Tables[0];
        grdViewDetails.DataBind();

        if (Convert.ToInt16(Session["RoleID"]) == 1)
            grdViewDetails.Columns[7].Visible = true;
        else
            grdViewDetails.Columns[7].Visible = false;
        

    }


    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ((LinkButton)e.Row.FindControl("lnkViewDetails")).Attributes.Add("onclick", string.Format("PopupView('{0}')", (e.Row.FindControl("lnkViewDetails") as LinkButton).CommandArgument));
                ((LinkButton)e.Row.FindControl("lnkEditDetails")).Attributes.Add("onclick", string.Format("PopupEdit('{0}')", (e.Row.FindControl("lnkEditDetails") as LinkButton).CommandArgument));
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {

        getMeetingHist();
        grdViewDetails.PageIndex = e.NewPageIndex;
        grdViewDetails.DataBind();

    }




}