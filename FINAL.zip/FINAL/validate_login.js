  function validateLogin(fldUsername, fldPassword)
  {
    var username = fldUsername.value;

    if(username === '') 
    {
      alert("Please enter your Username");
      fldUsername.focus();
      return false;
    }



    var password = fldPassword.value;

    if(password === '') 
    {
      alert("Please enter your Password");
      fldPassword.focus();
      return false;
    }

    return true;
  }
  
  isSubmitted = false;
       
  function confirmSubmission()
  {
     
      
    if(!isSubmitted)
     {
       isSubmitted = true;
       return true;
     }
          
     return false;
  }

  function validate(form)
      {
        return validateLogin(form.f_loginid, form.f_password) && confirmSubmission();
      }

