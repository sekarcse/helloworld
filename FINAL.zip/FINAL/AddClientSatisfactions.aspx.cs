﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class AddClientSatisfactions : System.Web.UI.Page
{
    int Cust_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {



        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getClientSatisfaction();        
        }


    }


    protected void grdSatisfaction_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdSatisfaction.Columns[6].Visible = true;
                grdSatisfaction.Columns[7].Visible = true;
                TableCell cell1 = grdSatisfaction.FooterRow.Cells[8];
                TableCell cell2 = grdSatisfaction.FooterRow.Cells[6];
                grdSatisfaction.FooterRow.Cells.RemoveAt(8);
                grdSatisfaction.FooterRow.Cells.RemoveAt(6);
                grdSatisfaction.FooterRow.Cells.AddAt(6, cell1);
                grdSatisfaction.FooterRow.Cells.AddAt(8, cell2);
            }
            else
            {
                grdSatisfaction.Columns[6].Visible = false;
                grdSatisfaction.Columns[7].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }


    public void getClientSatisfaction()
    {

        try
        {

            DALClient_Satisfaction objCC = new DALClient_Satisfaction();

            DataSet ds = new DataSet();

           // Cust_id = 5;

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objCC.getClient_Satisfaction(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("SatisfactionMadeby");
            dtnull.Columns.Add("SatisfactionModeText");
            dtnull.Columns.Add("SatisfactionNatureText");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSatisfaction.DataSource = ds;
                grdSatisfaction.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["SatisfactionMadeby"] = null;
                d["SatisfactionModeText"] = null;
                d["SatisfactionNatureText"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdSatisfaction.DataSource = dtnull;
                grdSatisfaction.DataBind();
                grdSatisfaction.Rows[0].Visible = false;
                grdSatisfaction.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    protected void AddSatisfaction(object sender, EventArgs e)
    {


        try
        {
            DALClient_Satisfaction objCC = new DALClient_Satisfaction();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            //Cust_id = 5;

            DateTime txtDate = Convert.ToDateTime(((TextBox)grdSatisfaction.FooterRow.FindControl("txtDate")).Text);
            string strSatisfaction_Made_by = ((TextBox)grdSatisfaction.FooterRow.FindControl("txtSatisfaction_Made_by")).Text;
            int SatisfactionMode = ((DropDownList)grdSatisfaction.FooterRow.FindControl("ddlSatisfactionMode")).SelectedIndex;
            int SatisfactionNature = Convert.ToInt32(((DropDownList)grdSatisfaction.FooterRow.FindControl("ddlSatisfactionNature")).SelectedValue);
            FileUpload fUpload = (FileUpload)grdSatisfaction.FooterRow.FindControl("FileUpload");
            string Create_User = Session["UserName"].ToString(); // "msiddique.bhatti";
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ClientSatisfactions\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);

                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ClientSatisfactions\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;

            }

            grdSatisfaction.DataSource = objCC.InsertClient_Satisfaction(Cust_id, txtDate, strSatisfaction_Made_by, SatisfactionMode,SatisfactionNature, CurrentFileName,CurrentFilePath, Create_User);
            grdSatisfaction.DataBind();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void UpdateSatisfaction(object sender, GridViewUpdateEventArgs e)
    {


        try
        {
            DALClient_Satisfaction objCC = new DALClient_Satisfaction();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            //Cust_id = 5;

            int Id = Convert.ToInt32(((Label)grdSatisfaction.Rows[e.RowIndex].FindControl("Id")).Text);
            DateTime txtDate = Convert.ToDateTime(((TextBox)grdSatisfaction.Rows[e.RowIndex].FindControl("txtDate")).Text);
            string strSatisfaction_Made_by = ((TextBox)grdSatisfaction.Rows[e.RowIndex].FindControl("txtSatisfaction_Made_by")).Text;
            int SatisfactionMode = ((DropDownList)grdSatisfaction.Rows[e.RowIndex].FindControl("ddlSatisfactionMode")).SelectedIndex;
            int SatisfactionNature = Convert.ToInt32(((DropDownList)grdSatisfaction.Rows[e.RowIndex].FindControl("ddlSatisfactionNature")).SelectedValue);
            FileUpload fUpload = (FileUpload)grdSatisfaction.Rows[e.RowIndex].FindControl("FileUpload");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpload.HasFile)
            {
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\ClientSatisfactions\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);

                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\ClientSatisfactions\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;

            }

            grdSatisfaction.EditIndex = -1;
            grdSatisfaction.DataSource = objCC.UpdateClient_Satisfaction(Id,Cust_id, txtDate, strSatisfaction_Made_by, SatisfactionMode, SatisfactionNature, CurrentFileName, CurrentFilePath, Update_User);
            grdSatisfaction.DataBind();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditSatisfaction(object sender, GridViewEditEventArgs e)
    {


        grdSatisfaction.EditIndex = e.NewEditIndex;
        getClientSatisfaction();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {


        grdSatisfaction.EditIndex = -1;
        getClientSatisfaction();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {


        LinkButton lnkRemove = (LinkButton)sender;
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }

    protected void DeleteSatisfaction(object sender, EventArgs e)
    {

        try
        {
            DALClient_Satisfaction objCC = new DALClient_Satisfaction();
            DataSet ds = new DataSet();
            LinkButton lnkRemove = (LinkButton)sender;
            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            //Cust_id = 5;
            ds = objCC.delClient_Satisfaction(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);
            DataTable dtnull = new DataTable();
            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("SatisfactionMadeby");
            dtnull.Columns.Add("SatisfactionModeText");
            dtnull.Columns.Add("SatisfactionNatureText");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdSatisfaction.DataSource = ds;
                grdSatisfaction.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["SatisfactionMadeby"] = null;
                d["SatisfactionModeText"] = null;
                d["SatisfactionNatureText"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                grdSatisfaction.DataSource = dtnull;
                grdSatisfaction.DataBind();
                grdSatisfaction.Rows[0].Visible = false;
                grdSatisfaction.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {


    }


    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {


        try
        {
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                DALSetup objsetup = new DALSetup();
                DataSet ds = new DataSet();

                ds = objsetup.getComplaint_Nature(1);
                DropDownList ddlSatisfactionNature = (DropDownList)e.Row.FindControl("ddlSatisfactionNature");
                ddlSatisfactionNature.DataSource = ds;
                ddlSatisfactionNature.DataTextField = "Name";
                ddlSatisfactionNature.DataValueField = "Id";
                ddlSatisfactionNature.DataBind();
                ddlSatisfactionNature.Items.Insert(0, "--Select--");
            }

            if (e.Row.RowState == DataControlRowState.Edit || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Edit)))
            {
                DALSetup objsetup = new DALSetup();
                DataSet ds = new DataSet();
                ds = objsetup.getComplaint_Nature(1);
                DropDownList ddlSatisfactionNature = (DropDownList)e.Row.FindControl("ddlSatisfactionNature");
                ddlSatisfactionNature.DataSource = ds;
                ddlSatisfactionNature.DataTextField = "Name";
                ddlSatisfactionNature.DataValueField = "Id";
                ddlSatisfactionNature.DataBind();
                ddlSatisfactionNature.Items.Insert(0, "--Select--");
                ddlSatisfactionNature.SelectedIndex = ddlSatisfactionNature.Items.IndexOf(ddlSatisfactionNature.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "Name").ToString()));
                DropDownList ddlSatisfactionMode = (DropDownList)e.Row.FindControl("ddlSatisfactionMode");
                ddlSatisfactionMode.SelectedIndex = ddlSatisfactionMode.Items.IndexOf(ddlSatisfactionMode.Items.FindByValue(DataBinder.Eval(e.Row.DataItem, "SatisfactionMode").ToString()));
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }


}