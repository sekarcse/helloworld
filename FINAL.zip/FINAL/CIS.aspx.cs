﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CIS : System.Web.UI.Page
{

    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            if (Convert.ToInt16(Session["RoleID"]) > 2)
            {
                btnAddMain.Visible = false;
                btnAddContacts.Visible = false;
                btnMonarchTerms.Visible = false;
                bthStep2Skip.Text = "Next";
                bthStep3Skip.Text = "Next";
                
            }
            else
            {
                bthStep1Next.Visible = false;
            }
            getAllCISData();
            getAllCIS();            
        }
    }


    protected void grdCIS_PreRender(object sender, EventArgs e)

    {


        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                grdCIS.Columns[7].Visible = true;
                grdCIS.Columns[8].Visible = true;
                TableCell cell1 = grdCIS.FooterRow.Cells[9];
                TableCell cell2 = grdCIS.FooterRow.Cells[7];
                grdCIS.FooterRow.Cells.RemoveAt(9);
                grdCIS.FooterRow.Cells.RemoveAt(7);
                grdCIS.FooterRow.Cells.AddAt(7, cell1);
                grdCIS.FooterRow.Cells.AddAt(9, cell2);
                //grdCIS.Columns[9].Visible = false;
            }
            else if (Convert.ToInt16(Session["RoleID"]) == 2)
            {
                grdCIS.Columns[7].Visible = false;
                grdCIS.Columns[8].Visible = false;
                //TableCell cell1 = grdCIS.FooterRow.Cells[9];
                //TableCell cell2 = grdCIS.FooterRow.Cells[8];
                //grdCIS.FooterRow.Cells.RemoveAt(9);
                //grdCIS.FooterRow.Cells.AddAt(8, cell1);
                //grdCIS.FooterRow.Cells.AddAt(9, cell2);
            }
            else
            {
                grdCIS.Columns[7].Visible = false;
                grdCIS.Columns[8].Visible = false;
                grdCIS.Columns[9].Visible = false;
                grdCIS.ShowFooter = false;
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    protected void btnAddMain_Click(object sender, EventArgs e)
    {

        try
        {

            DALCIS objCIS = new DALCIS();
            int Customer_id = 0;
            if (hdf.Value != "")
            {
                Customer_id = Convert.ToInt32(hdf.Value.ToString());
            }

            string Company_name = txtClientName.Text.Trim(); 
            string Company_Reg_No = txtRegNumber.Text.Trim(); 
            string Signatory = txtSalesContact.Text.Trim();
            string Title = txtTitle.Text.Trim();
            string Address_line1 = txtAddress1.Text.Trim();
            string Address_line2 = txtAddress2.Text.Trim(); 
            string Address_line3 = txtAddress3.Text.Trim();
            string Telephone = txtTelephone.Text.Trim(); 
            string Mobile = txtMobile.Text.Trim(); 
            string Email = txtEmail.Text.Trim(); 
            string Fax = txtFax.Text.Trim();
            string City = txtCity.Text.Trim();
            string County = txtCounty.Text.Trim();
            string Postcode = txtPostCode.Text.Trim();
            DateTime Contract_Signed_date = DateTime.Now;
            DateTime ContractFrom = DateTime.Now;
            DateTime ContractTo = DateTime.Now; 
            string ContractType = "";
            string ShareOfRefund = "";
            int LOAProvided = 0;
            string MonarchTermEnterBy = "";
            DateTime MonarchTermDate = DateTime.Now;
            string Create_User = Session["UserName"].ToString();
            string Update_User = Session["UserName"].ToString();
            string Note = Server.HtmlEncode(txtNote.Text);

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int CID;

            if (Customer_id > 0)
            {
                CID = objCIS.UpdateCIS(Customer_id, Cust_id, Company_name, Company_Reg_No, Signatory, Title,
                                                Address_line1, Address_line2, Address_line3, Telephone, Mobile,
                                                Email, Fax, City, County, Postcode, Contract_Signed_date,
                                                ContractFrom, ContractTo, ContractType, ShareOfRefund, LOAProvided,
                                                MonarchTermEnterBy, MonarchTermDate, Note, Create_User, Update_User, 0);
            }
            else
            {
                CID = objCIS.AddCIS(Customer_id, Cust_id, Company_name, Company_Reg_No, Signatory, Title,
                                     Address_line1, Address_line2, Address_line3, Telephone, Mobile,
                                     Email, Fax, City, County, Postcode, Contract_Signed_date,
                                     ContractFrom, ContractTo, ContractType, ShareOfRefund, LOAProvided,
                                     MonarchTermEnterBy, MonarchTermDate, Note, Create_User, Update_User, 0);
            }


            if (CID > 0)
            {
                hdf.Value = Convert.ToString(CID);
            }

            TabContainer1.ActiveTab = TabContainer1.Tabs[1];            
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step1Next()", true);

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void btnMonarchTerms_Click(object sender, EventArgs e)
    {
        try
        {
            DALCIS objCIS = new DALCIS();
            int Customer_id = 1;

            if (hdf.Value != "")
                Customer_id = Convert.ToInt32(hdf.Value.ToString());

            string Company_name = "";
            string Company_Reg_No = "";
            string Signatory = "";
            string Title = "";
            string Address_line1 = "";
            string Address_line2 = "";
            string Address_line3 = "";
            string Telephone = "";
            string Mobile = "";
            string Email = "";
            string Fax = "";
            string City = "";
            string County = "";
            string Postcode = "";
            DateTime Contract_Signed_date = Convert.ToDateTime(txtContractDate.Text.ToString());
            DateTime ContractFrom = Convert.ToDateTime(txtContractDurationFrom.Text.ToString());
            DateTime ContractTo = Convert.ToDateTime(txtContractDurationTo.Text.ToString());
            string ContractType = txtContractType.Text.ToString();
            string ShareOfRefund = txtShareOfRefund.Text.ToString();
            int LOAProvided = 0;
            if (rdobtnYes.Checked)
                LOAProvided = 1;
            string MonarchTermEnterBy = Session["UserName"].ToString();
            DateTime MonarchTermDate = DateTime.Now;
            string Create_User = Session["UserName"].ToString();
            string Update_User = Session["UserName"].ToString();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int CID = objCIS.UpdateCIS(Customer_id, Cust_id, Company_name, Company_Reg_No, Signatory, Title,
                                 Address_line1, Address_line2, Address_line3, Telephone, Mobile,
                                 Email, Fax, City, County, Postcode, Contract_Signed_date,
                                 ContractFrom, ContractTo, ContractType, ShareOfRefund, LOAProvided,
                                 MonarchTermEnterBy, MonarchTermDate,"", Create_User, Update_User,1);
            if (CID > 0)
                hdf.Value = Convert.ToString(CID);

            TabContainer1.ActiveTab = TabContainer1.Tabs[3];
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step3Next()", true);
        
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void btnAddContacts_Click(object sender, EventArgs e)

    {
        try
        {
            
            DataSet ds = new DataSet();
            DALCIS objCISContacts = new DALCIS();
            int Contact_Id = 0;
            int Contact_Id2 = 0;
            int CIS_Id = 0; 
                
            if (hdf.Value != "")
                CIS_Id = Convert.ToInt32(hdf.Value.ToString());

            if (hdfContact1.Value != "")
                Contact_Id = Convert.ToInt32(hdfContact1.Value.ToString());

            if (hdfContact2.Value != "")
                Contact_Id2 = Convert.ToInt32(hdfContact2.Value.ToString());

            string Contact = txtAccountManagerContact.Text; 
            string Title = txtAMTitle.Text;
            string Telephone = txtAMTelephone.Text;
            string Mobile = txtAMMobile.Text;
            string Fax = txtAMFax.Text; 
            string Email = txtAMEmail.Text;
            string Create_User = Session["UserName"].ToString();
            string Update_User = Session["UserName"].ToString();
            string Contact2 = txtAlternativeContact.Text; 
            string Title2 = txtACTitle.Text; 
            string Telephone2 = txtACTelephone.Text;
            string Mobile2 = txtACMobile.Text; 
            string Fax2 = txtACFax.Text; 
            string Email2 = txtACEmail.Text;

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            if (Contact_Id > 1)
            {
                ds = objCISContacts.UpdateCIS_Contacts(Contact_Id, Cust_id, Contact, Title, Telephone, Mobile,
                                                    Fax, Email, Create_User, Update_User, Contact_Id2,
                                                    Contact2, Title2, Telephone2, Mobile2, Fax2, Email2);
            }
            else
            {
                ds = objCISContacts.AddCIS_Contacts(Contact_Id, Cust_id, Contact, Title, Telephone, Mobile,
                                                        Fax, Email, Create_User, Update_User, Contact_Id2,
                                                        Contact2, Title2, Telephone2, Mobile2, Fax2, Email2);            
            }

            if (ds.Tables.Count > 0)
                hdfContact1.Value = Convert.ToString(ds.Tables[0].Rows[0][0]);
            if (ds.Tables.Count > 1)
                hdfContact2.Value = Convert.ToString(ds.Tables[1].Rows[0][0]);

            TabContainer1.ActiveTab = TabContainer1.Tabs[2];
            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step2Next()", true); 
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }


    public void getAllCISData()
    {

        try
        {

            DALCIS objgetCIS = new DALCIS();
            DataSet dsCIS = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            dsCIS = objgetCIS.getCIS(Cust_id);

            if (dsCIS.Tables.Count > 0)
            {
                if (dsCIS.Tables[0].Rows.Count > 0)
                {
                    txtClientName.Text = dsCIS.Tables[0].Rows[0]["Company_name"].ToString();
                    txtRegNumber.Text = dsCIS.Tables[0].Rows[0]["Company_Reg_no"].ToString();
                    txtSalesContact.Text = dsCIS.Tables[0].Rows[0]["Signatory"].ToString();
                    txtTitle.Text = dsCIS.Tables[0].Rows[0]["Title"].ToString();
                    txtAddress1.Text = dsCIS.Tables[0].Rows[0]["Address_line1"].ToString();
                    txtAddress2.Text = dsCIS.Tables[0].Rows[0]["Address_line2"].ToString();
                    txtAddress3.Text = dsCIS.Tables[0].Rows[0]["Address_line3"].ToString();
                    txtTelephone.Text = dsCIS.Tables[0].Rows[0]["Telephone"].ToString();
                    txtMobile.Text = dsCIS.Tables[0].Rows[0]["Mobile"].ToString();
                    txtEmail.Text = dsCIS.Tables[0].Rows[0]["Email"].ToString();
                    txtFax.Text = dsCIS.Tables[0].Rows[0]["Fax"].ToString();
                    txtCity.Text = dsCIS.Tables[0].Rows[0]["City"].ToString();
                    txtCounty.Text = dsCIS.Tables[0].Rows[0]["County"].ToString();
                    txtPostCode.Text = dsCIS.Tables[0].Rows[0]["Postcode"].ToString();
                    txtNote.Text = Server.HtmlDecode(dsCIS.Tables[0].Rows[0]["Note"].ToString());
                    if (!string.IsNullOrEmpty(dsCIS.Tables[0].Rows[0]["Contract_Signed_date"].ToString()))
                        txtContractDate.Text = Convert.ToDateTime(dsCIS.Tables[0].Rows[0]["Contract_Signed_date"]).ToString("dd/MM/yyyy");
                    if (!string.IsNullOrEmpty(dsCIS.Tables[0].Rows[0]["ContractFrom"].ToString()))
                        txtContractDurationFrom.Text = Convert.ToDateTime(dsCIS.Tables[0].Rows[0]["ContractFrom"]).ToString("dd/MM/yyyy");
                    if (!string.IsNullOrEmpty(dsCIS.Tables[0].Rows[0]["ContractTo"].ToString()))
                        txtContractDurationTo.Text = Convert.ToDateTime(dsCIS.Tables[0].Rows[0]["ContractTo"]).ToString("dd/MM/yyyy");
                    txtContractType.Text = dsCIS.Tables[0].Rows[0]["ContractType"].ToString();
                    txtShareOfRefund.Text = dsCIS.Tables[0].Rows[0]["ShareOfRefund"].ToString();
                    if (!string.IsNullOrEmpty(dsCIS.Tables[0].Rows[0]["LOAProvided"].ToString()))
                    {
                        if (dsCIS.Tables[0].Rows[0]["LOAProvided"].ToString().Equals("1"))
                        {
                            rdobtnYes.Checked = true;
                        }
                        else
                            rdobtnNo.Checked = true;
                    }
                    hdf.Value = Convert.ToString(dsCIS.Tables[0].Rows[0]["Customer_id"].ToString());

                    if (Convert.ToInt16(Session["RoleID"]) <= 2)
                    {
                        bthStep1Next.Visible = true;
                        bthStep1Next.Text = "Skip";
                    }
                }
            }
            if (dsCIS.Tables.Count > 1)
            {
                if (dsCIS.Tables[1].Rows.Count > 0)
                {
                    txtAccountManagerContact.Text = dsCIS.Tables[1].Rows[0]["Contact"].ToString();
                    txtAMTitle.Text = dsCIS.Tables[1].Rows[0]["Title"].ToString();
                    txtAMTelephone.Text = dsCIS.Tables[1].Rows[0]["Telephone"].ToString();
                    txtAMMobile.Text = dsCIS.Tables[1].Rows[0]["Mobile"].ToString();
                    txtAMFax.Text = dsCIS.Tables[1].Rows[0]["Fax"].ToString();
                    txtAMEmail.Text = dsCIS.Tables[1].Rows[0]["Email"].ToString();
                    hdfContact1.Value = Convert.ToString(dsCIS.Tables[1].Rows[0]["Contact_Id"].ToString());
                    if (dsCIS.Tables[1].Rows.Count > 1)
                    {
                        txtAlternativeContact.Text = dsCIS.Tables[1].Rows[1]["Contact"].ToString();
                        txtACTitle.Text = dsCIS.Tables[1].Rows[1]["Title"].ToString();
                        txtACTelephone.Text = dsCIS.Tables[1].Rows[1]["Telephone"].ToString();
                        txtACMobile.Text = dsCIS.Tables[1].Rows[1]["Mobile"].ToString();
                        txtACFax.Text = dsCIS.Tables[1].Rows[1]["Fax"].ToString();
                        txtACEmail.Text = dsCIS.Tables[1].Rows[1]["Email"].ToString();
                        hdfContact2.Value = Convert.ToString(dsCIS.Tables[1].Rows[1]["Contact_Id"].ToString());
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    public void getAllCIS()
        {

        try
        {

        DALCIS objgetCIS = new DALCIS();
        DataSet ds = new DataSet();
        int CIS_Id = 0;
        if (hdf.Value != "")
            CIS_Id = Convert.ToInt32(hdf.Value.ToString());

        ds = objgetCIS.getAllCISInfo(CIS_Id);    
        
        DataTable dtnull = new DataTable();
        dtnull.Columns.Add("Id");
        dtnull.Columns.Add("Util_type");
        dtnull.Columns.Add("NumberofSite");
        dtnull.Columns.Add("supplier_name");
        dtnull.Columns.Add("Contract_Renewal_Date");
        dtnull.Columns.Add("Copy_Contracts_Provided");
        dtnull.Columns.Add("Copy_Invoices_Provided");
    
       if (ds.Tables[0].Rows.Count != 0)
       {           
           grdCIS.DataSource = ds; 
           grdCIS.DataBind();        
       } 
       else 
       {             
           
            DataRow d = dtnull.NewRow();
            d["Id"] = 0;
            d["Util_type"] = null;
            d["NumberofSite"] = null;
            d["supplier_name"] = null;
            d["Contract_Renewal_Date"] = 0;
            d["Copy_Contracts_Provided"] = null;
            d["Copy_Invoices_Provided"] = null;
            dtnull.Rows.Add(d);
            grdCIS.DataSource = dtnull;
            grdCIS.DataBind(); 
            grdCIS.Rows[0].Visible = false; 
            grdCIS.Rows[0].Controls.Clear(); 
        }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    protected void AddNewCIS(object sender, EventArgs e)
    {
        try
        {
            DALCIS objCIS = new DALCIS();
            
            int CIS_Id = 1;

            if (hdf.Value != "")
                CIS_Id = Convert.ToInt32(hdf.Value.ToString());

            int Utility_type = ((DropDownList)grdCIS.FooterRow.FindControl("ddlUtility_type")).SelectedIndex;
            int NumberofSite = Convert.ToInt32(((TextBox)grdCIS.FooterRow.FindControl("txtTotal_Number_of_Sites")).Text);
            int Supplier_Id = Convert.ToInt32(((DropDownList)grdCIS.FooterRow.FindControl("ddlSupplier")).SelectedValue);
            DateTime Contract_Renewal_Date = Convert.ToDateTime(((TextBox)grdCIS.FooterRow.FindControl("txtContract_Renewal_Date")).Text);
            int Copy_Contracts_Provided = ((CheckBox)grdCIS.FooterRow.FindControl("chkContracts")).Checked ? 1 : 0;
            int Copy_Invoices_Provided = ((CheckBox)grdCIS.FooterRow.FindControl("chkInvoice")).Checked ? 1 : 0;
            string Create_User = Session["UserName"].ToString();
            grdCIS.DataSource = objCIS.InsertCISInfo(CIS_Id, Utility_type, NumberofSite, Supplier_Id, Contract_Renewal_Date, Copy_Contracts_Provided, Copy_Invoices_Provided, Create_User);
            grdCIS.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {}
    }

    protected void UpdateCIS(object sender, GridViewUpdateEventArgs e)
    {
        try
        {   
            DALCIS objCIS = new DALCIS();

            int ID = Convert.ToInt32(((Label)grdCIS.Rows[e.RowIndex].FindControl("Id")).Text);

            int CIS_Id = 1;
            if (hdf.Value != "")
                CIS_Id = Convert.ToInt32(hdf.Value.ToString());
            
            int Utility_type = ((DropDownList)grdCIS.Rows[e.RowIndex].FindControl("ddlUtility_type")).SelectedIndex;
            int NumberofSite = Convert.ToInt32(((TextBox)grdCIS.Rows[e.RowIndex].FindControl("txtTotal_Number_of_Sites")).Text);
            int Supplier_Id = Convert.ToInt32(((DropDownList)grdCIS.Rows[e.RowIndex].FindControl("ddlSupplier")).SelectedValue);
            DateTime Contract_Renewal_Date = Convert.ToDateTime(((TextBox)grdCIS.Rows[e.RowIndex].FindControl("txtContract_Renewal_Date")).Text);
            int Copy_Contracts_Provided = ((CheckBox)grdCIS.Rows[e.RowIndex].FindControl("chkContracts")).Checked ? 1 : 0;
            int Copy_Invoices_Provided = ((CheckBox)grdCIS.Rows[e.RowIndex].FindControl("chkInvoice")).Checked ? 1 : 0;
            string Update_User = Session["UserName"].ToString();

            grdCIS.EditIndex = -1;

            grdCIS.DataSource = objCIS.UpdateCIS_UtilityInfoWithId(CIS_Id, Utility_type, NumberofSite, Supplier_Id, Contract_Renewal_Date, Copy_Contracts_Provided, Copy_Invoices_Provided, Update_User, ID);
            grdCIS.DataBind();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally 
        { 
        }
    }

    protected void EditCIS(object sender, GridViewEditEventArgs e)
    {
        grdCIS.EditIndex = e.NewEditIndex;
        getAllCIS();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdCIS.EditIndex = -1;
        getAllCIS();
    }

    protected void DeleteCIS(object sender, EventArgs e)
    {
        try
        {
            DALCIS objCIS = new DALCIS();
            DataSet ds = new DataSet();
            LinkButton lnkRemove = (LinkButton)sender;
            
            int CIS_Id = 1;
            if (hdf.Value != "")
                CIS_Id = Convert.ToInt32(hdf.Value.ToString());

            ds = objCIS.delCIS_UtilityInfo(Convert.ToInt32(lnkRemove.CommandArgument), CIS_Id);

            DataTable dtnull = new DataTable();
            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("Util_type");
            dtnull.Columns.Add("NumberofSite");
            dtnull.Columns.Add("supplier_name");
            dtnull.Columns.Add("Contract_Renewal_Date");
            dtnull.Columns.Add("Copy_Contracts_Provided");
            dtnull.Columns.Add("Copy_Invoices_Provided");

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdCIS.DataSource = ds;
                grdCIS.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["Util_type"] = null;
                d["NumberofSite"] = null;
                d["supplier_name"] = null;
                d["Contract_Renewal_Date"] = 0;
                d["Copy_Contracts_Provided"] = null;
                d["Copy_Invoices_Provided"] = null;
                dtnull.Rows.Add(d);
                grdCIS.DataSource = dtnull;
                grdCIS.DataBind();
                grdCIS.Rows[0].Visible = false;
                grdCIS.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { 
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
    }

    protected void grdCIS_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                DALTariff objTariff = new DALTariff();
                DataSet ds = new DataSet();
                ds = objTariff.getSuppliers();
                DropDownList ddlSupplier = (DropDownList)e.Row.FindControl("ddlSupplier");
                ddlSupplier.DataSource = ds;
                ddlSupplier.DataTextField = "supplier_name";
                ddlSupplier.DataValueField = "supplier_id";
                ddlSupplier.DataBind();
                ddlSupplier.Items.Insert(0, "--Select--");
            }

            if (e.Row.RowState == DataControlRowState.Edit || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Edit)))
            {                
                DALTariff objTariff = new DALTariff();
                DataSet ds = new DataSet();
                ds = objTariff.getSuppliers();
                DropDownList ddlSupplier = (DropDownList)e.Row.FindControl("ddlSupplier");
                ddlSupplier.DataSource = ds;
                ddlSupplier.DataTextField = "supplier_name";
                ddlSupplier.DataValueField = "supplier_id";
                ddlSupplier.DataBind();
                ddlSupplier.Items.Insert(0, "--Select--");
                ddlSupplier.SelectedIndex = ddlSupplier.Items.IndexOf(ddlSupplier.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "supplier_name").ToString()));
                DropDownList ddlUtility_type = (DropDownList)e.Row.FindControl("ddlUtility_type");
                ddlUtility_type.SelectedIndex = ddlUtility_type.Items.IndexOf(ddlUtility_type.Items.FindByValue(DataBinder.Eval(e.Row.DataItem, "Utility_type").ToString())); 
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }

    protected void btnStep2Back_Click(object sender, EventArgs e)
    {
        TabContainer1.ActiveTab = TabContainer1.Tabs[0];
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step2Back()", true);
    }

    protected void bthStep2Skip_Click(object sender, EventArgs e)
    {
        TabContainer1.ActiveTab = TabContainer1.Tabs[2];
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step2Next()", true);
    }

    protected void btnStep3Back_Click(object sender, EventArgs e)
    {
        TabContainer1.ActiveTab = TabContainer1.Tabs[1];
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step3Back()", true);
    }

    protected void bthStep3Skip_Click(object sender, EventArgs e)
    {
        TabContainer1.ActiveTab = TabContainer1.Tabs[3];
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step3Next()", true);
    }

    protected void btnStep4Back_Click(object sender, EventArgs e)
    {
        TabContainer1.ActiveTab = TabContainer1.Tabs[2];
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step4Back()", true);
    }

    protected void bthStep1Next_Click(object sender, EventArgs e)
    {
        TabContainer1.ActiveTab = TabContainer1.Tabs[1];
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "Step1Next()", true);
    }

}