﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class AddContacts : System.Web.UI.Page
{

    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getContacts();         
        }
        else
        {
            if (Convert.ToString(Session["CommandAddContacts"]) == "save")
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");
                getContacts();
                Session["CommandAddContacts"] = string.Empty;
            }
        }
    }


    protected void grdContacts_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                
                grdContacts.Columns[3].Visible = true;
                grdContacts.Columns[4].Visible = true;
                TableCell cell1 = grdContacts.FooterRow.Cells[6];
                TableCell cell2 = grdContacts.FooterRow.Cells[4];
                grdContacts.FooterRow.Cells.RemoveAt(6);
                grdContacts.FooterRow.Cells.RemoveAt(4);
                grdContacts.FooterRow.Cells.AddAt(4, cell1);
                grdContacts.FooterRow.Cells.AddAt(6, cell2);
                //grdContacts.Columns[5].Visible = false;
            }
            else
            {
                grdContacts.Columns[4].Visible = false;
                grdContacts.Columns[5].Visible = false;
                //TableCell cell1 = grdCIS.FooterRow.Cells[9];
                //TableCell cell2 = grdCIS.FooterRow.Cells[8];
                //grdCIS.FooterRow.Cells.RemoveAt(9);
                //grdCIS.FooterRow.Cells.AddAt(8, cell1);
                //grdCIS.FooterRow.Cells.AddAt(9, cell2);
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getContacts()
    {
        try
        {
            DALContact objContact = new DALContact();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objContact.getClient_Contacts(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("Employee_Name");
            dtnull.Columns.Add("Attitude");

            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["AddContactGrid"] = ds;
                grdContacts.DataSource = ds;
                grdContacts.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["Employee_Name"] = null;
                d["Attitude"] = null;
                dtnull.Rows.Add(d);
                Session["AddContactGrid"] = dtnull;
                grdContacts.DataSource = dtnull;
                grdContacts.DataBind();
                grdContacts.Rows[0].Visible = false;
                grdContacts.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewContact(object sender, EventArgs e)
    {
        
        DALContact objContact = new DALContact();
        
        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());
        
        string Employee_Name = ((TextBox)grdContacts.FooterRow.FindControl("txtName")).Text;
        DateTime Date = Convert.ToDateTime(((TextBox)grdContacts.FooterRow.FindControl("txtDate")).Text);        
        string Attitude = ((TextBox)grdContacts.FooterRow.FindControl("txtAttitude")).Text;        
        string Create_User = Session["UserName"].ToString();
        grdContacts.DataSource = objContact.InsertClient_Contacts(Cust_id, Employee_Name, Attitude, Create_User, Date);
        grdContacts.DataBind();

    }

    protected void UpdateContact(object sender, GridViewUpdateEventArgs e)
    {        
        DALContact objContact = new DALContact();
        string ID = ((Label)grdContacts.Rows[e.RowIndex].FindControl("Id")).Text;

        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());
        
        string Employee_Name = ((TextBox)grdContacts.Rows[e.RowIndex].FindControl("txtName")).Text;
        DateTime Date = Convert.ToDateTime(((TextBox)grdContacts.Rows[e.RowIndex].FindControl("txtDate")).Text);        
        string Attitude = ((TextBox)grdContacts.Rows[e.RowIndex].FindControl("txtAttitude")).Text;
        string Update_User = Session["UserName"].ToString();
        grdContacts.EditIndex = -1;
        grdContacts.DataSource = objContact.UpdateClient_Contacts(Convert.ToInt32(ID), Cust_id, Employee_Name, Attitude, Update_User, Date);
        grdContacts.DataBind();
    }

    protected void EditContact(object sender, GridViewEditEventArgs e)
    {
        grdContacts.EditIndex = e.NewEditIndex;
        getContacts();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdContacts.EditIndex = -1;
        getContacts();
    }
    
    protected void DeleteContact(object sender, EventArgs e)
    {
        DALContact objContact = new DALContact();


        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        LinkButton lnkRemove = (LinkButton)sender;
        grdContacts.DataSource = objContact.delClient_Contacts(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);        
        getContacts();
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        grdContacts.PageIndex = e.NewPageIndex;
        grdContacts.DataSource = (DataSet)Session["AddContactGrid"];
        grdContacts.DataBind();
    }
}