﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class GeneralInfo : System.Web.UI.Page
{

    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getGeneralInfo();         
        }
        else
        {
            if (Convert.ToString(Session["CommandGeneralInfo"]) == "save")
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");
                getGeneralInfo();
                Session["CommandGeneralInfo"] = string.Empty;
            }
        }
    }


    protected void grdGeneralInfo_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                
                grdGeneralInfo.Columns[3].Visible = true;
                grdGeneralInfo.Columns[4].Visible = true;
                TableCell cell1 = grdGeneralInfo.FooterRow.Cells[6];
                TableCell cell2 = grdGeneralInfo.FooterRow.Cells[4];
                grdGeneralInfo.FooterRow.Cells.RemoveAt(6);
                grdGeneralInfo.FooterRow.Cells.RemoveAt(4);
                grdGeneralInfo.FooterRow.Cells.AddAt(4, cell1);
                grdGeneralInfo.FooterRow.Cells.AddAt(6, cell2);                
            }
            else
            {
                grdGeneralInfo.Columns[4].Visible = false;
                grdGeneralInfo.Columns[5].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }


    public void getGeneralInfo()
    {
        try
        {
            DALGeneralInfo objGeneralInfo = new DALGeneralInfo();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objGeneralInfo.getHistoryGeneralInfo(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");
            dtnull.Columns.Add("Description");

            if (ds.Tables[0].Rows.Count != 0)
            {
				Session["GeneralInfoGrid"] = ds;
                grdGeneralInfo.DataSource = ds;
                grdGeneralInfo.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                d["Description"] = null;
                dtnull.Rows.Add(d);
				Session["GeneralInfoGrid"] = dtnull;
                grdGeneralInfo.DataSource = dtnull;
                grdGeneralInfo.DataBind();
                grdGeneralInfo.Rows[0].Visible = false;
                grdGeneralInfo.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewContact(object sender, EventArgs e)
    {

        DALGeneralInfo objGeneralInfo = new DALGeneralInfo();
        
        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        DateTime Date = Convert.ToDateTime(((TextBox)grdGeneralInfo.FooterRow.FindControl("txtDate")).Text);        

        string Description = ((TextBox)grdGeneralInfo.FooterRow.FindControl("txtDescription")).Text;  
      
        FileUpload fUpload = (FileUpload)grdGeneralInfo.FooterRow.FindControl("FileUpload");

        string Create_User = Session["UserName"].ToString();

        string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;

            if (fUpload.HasFile)
            {                
                CurrentFileName = fUpload.FileName;
                fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\GeneralInfoFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\GeneralInfoFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
            }

            grdGeneralInfo.DataSource = objGeneralInfo.InsertHistoryGeneralInfo(Cust_id, Date, CurrentFileName, CurrentFilePath, Description, Create_User);
            grdGeneralInfo.DataBind();

    }

    protected void UpdateContact(object sender, GridViewUpdateEventArgs e)
    {
        DALGeneralInfo objGeneralInfo = new DALGeneralInfo();
        string ID = ((Label)grdGeneralInfo.Rows[e.RowIndex].FindControl("Id")).Text;

        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        DateTime Date = Convert.ToDateTime(((TextBox)grdGeneralInfo.Rows[e.RowIndex].FindControl("txtDate")).Text);
        string Description = ((TextBox)grdGeneralInfo.Rows[e.RowIndex].FindControl("txtDescription")).Text;
        FileUpload fUpload = (FileUpload)grdGeneralInfo.Rows[e.RowIndex].FindControl("FileUpload");
        string Update_User = Session["UserName"].ToString();

        string CurrentFilePath = "", CurrentFileName = "";
        DateTime dtNow = DateTime.Now;

        if (fUpload.HasFile)
        {
            CurrentFileName = fUpload.FileName;
            fUpload.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\GeneralInfoFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName);
            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\GeneralInfoFiles\\") +
            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpload.FileName;
        }

        grdGeneralInfo.EditIndex = -1;
        grdGeneralInfo.DataSource = objGeneralInfo.UpdateHistoryGeneralInfo(Convert.ToInt32(ID), Cust_id, Date, CurrentFileName, CurrentFilePath, Description, Update_User);
        grdGeneralInfo.DataBind();

    }

    protected void EditContact(object sender, GridViewEditEventArgs e)
    {
        grdGeneralInfo.EditIndex = e.NewEditIndex;
        getGeneralInfo();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdGeneralInfo.EditIndex = -1;
        getGeneralInfo();
    }
    
    protected void DeleteContact(object sender, EventArgs e)
    {
        DALGeneralInfo objGeneralInfo = new DALGeneralInfo();


        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        LinkButton lnkRemove = (LinkButton)sender;
        grdGeneralInfo.DataSource = objGeneralInfo.delHistoryGeneralInfo(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);        
        getGeneralInfo();
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        grdGeneralInfo.PageIndex = e.NewPageIndex;
        grdGeneralInfo.DataSource = (DataSet)Session["GeneralInfoGrid"];
        grdGeneralInfo.DataBind();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {
        LinkButton lnkRemove = (LinkButton)sender;
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }

}