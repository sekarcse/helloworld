﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public partial class SellingCNBs : System.Web.UI.Page
{

    int Cust_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            Response.Clear();
            getSellingCNB();         
        }
        else
        {
            if (Convert.ToString(Session["CommandSellingCNBs"]) == "save")
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");
                Response.Clear();
                getSellingCNB();
                Session["CommandSellingCNBs"] = string.Empty;
            }
        }
    }


    protected void grdSellingCNB_PreRender(object sender, EventArgs e)
    {

        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {

                grdSellingCNB.Columns[4].Visible = true;
                grdSellingCNB.Columns[5].Visible = true;
                TableCell cell1 = grdSellingCNB.FooterRow.Cells[6];
                TableCell cell2 = grdSellingCNB.FooterRow.Cells[4];
                grdSellingCNB.FooterRow.Cells.RemoveAt(6);
                grdSellingCNB.FooterRow.Cells.RemoveAt(4);
                grdSellingCNB.FooterRow.Cells.AddAt(4, cell1);
                grdSellingCNB.FooterRow.Cells.AddAt(6, cell2);
                //grdSellingCNB.Columns[5].Visible = false;
            }
            else
            {
                grdSellingCNB.Columns[4].Visible = false;
                grdSellingCNB.Columns[5].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }

    }

    public void getSellingCNB()
    {
        try
        {
            DALSellingCNB objSellingCNB = new DALSellingCNB();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSellingCNB.getSellingCNB(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
				Session["SellingCNBGrid"] = ds;
                grdSellingCNB.DataSource = ds;
                grdSellingCNB.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["date"] = null;
                d["CNB"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
				Session["SellingCNBGrid"] = dtnull;
                grdSellingCNB.DataSource = dtnull;
                grdSellingCNB.DataBind();
                grdSellingCNB.Rows[0].Visible = false;
                grdSellingCNB.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void AddNewSellingCNB(object sender, EventArgs e)
    {
        //try
        //{
            DALSellingCNB objSellingCNB = new DALSellingCNB();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            DateTime Contract_Renewal_Date = Convert.ToDateTime(((TextBox)grdSellingCNB.FooterRow.FindControl("txtContract_Renewal_Date")).Text);

            String CNB = ((TextBox)grdSellingCNB.FooterRow.FindControl("txtCNB")).Text;
            FileUpload fUpSellingCNBd = (FileUpload)grdSellingCNB.FooterRow.FindControl("FileUpSellingCNBd");
            string Create_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpSellingCNBd.HasFile)
            {                
                CurrentFileName = fUpSellingCNBd.FileName;
                fUpSellingCNBd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SellingCNBFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSellingCNBd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\SellingCNBFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSellingCNBd.FileName;
            }
            grdSellingCNB.DataSource = objSellingCNB.InsertSellingCNB(Cust_id, CurrentFileName, CurrentFilePath, Create_User, Contract_Renewal_Date, CNB);
            grdSellingCNB.DataBind();
        //}
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //}
        //finally
        //{ }
    }

    protected void UpdateSellingCNB(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DALSellingCNB objSellingCNB = new DALSellingCNB();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            int ID = Convert.ToInt16(((Label)grdSellingCNB.Rows[e.RowIndex].FindControl("Id")).Text);            
            
            DateTime SellingCNBDate = Convert.ToDateTime(((TextBox)grdSellingCNB.Rows[e.RowIndex].FindControl("txtContract_Renewal_Date")).Text);

            String CNB = ((TextBox)grdSellingCNB.Rows[e.RowIndex].FindControl("txtCNB")).Text;
            FileUpload fUpSellingCNBd = (FileUpload)grdSellingCNB.Rows[e.RowIndex].FindControl("FileUpSellingCNBd");
            string Update_User = Session["UserName"].ToString();
            string CurrentFilePath = "", CurrentFileName = "";
            DateTime dtNow = DateTime.Now;
            if (fUpSellingCNBd.HasFile)
            {
                CurrentFileName = fUpSellingCNBd.FileName;
                fUpSellingCNBd.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\SellingCNBFiles\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSellingCNBd.FileName);
                CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\SellingCNBFiles\\") +
                dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fUpSellingCNBd.FileName;
            }
            grdSellingCNB.EditIndex = -1;
            grdSellingCNB.DataSource = objSellingCNB.UpdateSellingCNB(ID, Cust_id, CurrentFileName, CurrentFilePath, Update_User, SellingCNBDate, CNB);
            grdSellingCNB.DataBind();          
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void EditSellingCNB(object sender, GridViewEditEventArgs e)
    {
        grdSellingCNB.EditIndex = e.NewEditIndex;
        getSellingCNB();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdSellingCNB.EditIndex = -1;
        getSellingCNB();
    }

    protected void ShowFiles(object sender, EventArgs e)
    {   
            LinkButton lnkRemove = (LinkButton)sender;
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=" + lnkRemove.Text);
            Response.ContentType = "";
            FileStream MyFileStream;
            long FileSize;
            MyFileStream = new FileStream(lnkRemove.CommandArgument, FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
            FileSize = MyFileStream.Length;
            byte[] Buffer = new byte[(int)FileSize];
            MyFileStream.Read(Buffer, 0, (int)FileSize);
            MyFileStream.Close();
            Response.BinaryWrite(Buffer);
            Response.End();    
    }

    protected void DeleteSellingCNB(object sender, EventArgs e)
    {
        try
        {
            DALSellingCNB objSellingCNB = new DALSellingCNB();
            DataSet ds = new DataSet();

            LinkButton lnkRemove = (LinkButton)sender;

            

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            ds = objSellingCNB.delSellingCNB(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("date");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("File_Name");
            dtnull.Columns.Add("File_Path");

            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["SellingCNBGrid"] = ds;
                grdSellingCNB.DataSource = ds;
                grdSellingCNB.DataBind();
            }
            else
            {

                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["CNB"] = null;
                d["date"] = null;
                d["File_Name"] = null;
                d["File_Path"] = null;
                dtnull.Rows.Add(d);
                Session["SellingCNBGrid"] = dtnull;
                grdSellingCNB.DataSource = dtnull;
                grdSellingCNB.DataBind();
                grdSellingCNB.Rows[0].Visible = false;
                grdSellingCNB.Rows[0].Controls.Clear();
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
		grdSellingCNB.PageIndex = e.NewPageIndex;
        grdSellingCNB.DataSource = (DataSet)Session["SellingCNBGrid"];
        grdSellingCNB.DataBind();
    }


}