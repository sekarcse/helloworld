﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;
using System.Collections;
using System.Collections.Generic;


public partial class AddHistorySavings : System.Web.UI.Page

{

    int Cust_id = 0;
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!this.IsPostBack)
        {
            if (Session["RoleID"] == null)
                Response.Redirect("login.asp");

            getHistorySavings();         
        }
        else
        {
            if (Session["CommandHOS"] == "save")
            {
                if (Session["RoleID"] == null)
                Response.Redirect("login.asp");
                getHistorySavings();
                Session["CommandHOS"] = string.Empty;
            }
        }
    }


    protected void grdContacts_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToInt16(Session["RoleID"]) == 1)
            {
                
                grdSavings.Columns[9].Visible = true;
                grdSavings.Columns[10].Visible = true;
                TableCell cell1 = grdSavings.FooterRow.Cells[11];
                TableCell cell2 = grdSavings.FooterRow.Cells[9];
                grdSavings.FooterRow.Cells.RemoveAt(11);
                grdSavings.FooterRow.Cells.RemoveAt(9);
                grdSavings.FooterRow.Cells.AddAt(9, cell1);
                grdSavings.FooterRow.Cells.AddAt(11, cell2);
                //grdContacts.Columns[5].Visible = false;
            }
            else
            {
                grdSavings.Columns[10].Visible = false;
                grdSavings.Columns[9].Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
        }
    }


    public void getHistorySavings()

    {
        try
        {
            DALHistorySavings objSavings = new DALHistorySavings();

            DataSet ds = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            //Cust_id = 5;

            ds = objSavings.getHistorySavings(Cust_id);

            DataTable dtnull = new DataTable();

            dtnull.Columns.Add("Id");
            dtnull.Columns.Add("DateFrom");
            dtnull.Columns.Add("DateTo");
            dtnull.Columns.Add("Savtype");
            dtnull.Columns.Add("Util_type");
            dtnull.Columns.Add("CurrAmount");
            dtnull.Columns.Add("CNB");
            dtnull.Columns.Add("Description");
            dtnull.Columns.Add("TotalAmount");
            if (ds.Tables[0].Rows.Count != 0)
            {
                Session["HOSGrid"] = ds;
				grdSavings.DataSource = ds;
                grdSavings.DataBind();
            }
            else
            {
                DataRow d = dtnull.NewRow();
                d["Id"] = 0;
                d["DateFrom"] = null;
                d["DateTo"] = null;
                d["Savtype"] = null;
                d["Util_type"] = null;
                d["CurrAmount"] = null;
                d["CNB"] = null;
                d["Description"] = null;
                d["TotalAmount"] = null;                
                dtnull.Rows.Add(d);
				Session["HOSGrid"] = dtnull;
                grdSavings.DataSource = dtnull;
                grdSavings.DataBind();
                grdSavings.Rows[0].Visible = false;
                grdSavings.Rows[0].Controls.Clear();
            }
        }
        catch (Exception ex)

        {
            ex.ToString();
        }
    }

    //protected void AddSavings(object sender, EventArgs e)


    //{

    //    DALHistorySavings objSavings = new DALHistorySavings();        
    //    if (Session["CustID"] != null)
    //        Cust_id = Convert.ToInt16(Session["CustID"].ToString());
    //    //Cust_id = 5;
    //    DateTime DateFrom = Convert.ToDateTime(((TextBox)grdSavings.FooterRow.FindControl("txtFromDate")).Text);
    //    DateTime DateTo = Convert.ToDateTime(((TextBox)grdSavings.FooterRow.FindControl("txtToDate")).Text);
    //    int SavingType = ((DropDownList)grdSavings.FooterRow.FindControl("ddlSaving_type")).SelectedIndex;
    //    int Utilitytype = ((DropDownList)grdSavings.FooterRow.FindControl("ddlUtility_type")).SelectedIndex;
    //    double Amount = Convert.ToDouble(((TextBox)grdSavings.FooterRow.FindControl("txtAmount")).Text);
    //    int CNB = Convert.ToInt16(((TextBox)grdSavings.FooterRow.FindControl("txtCNB")).Text);
    //    string Description = ((TextBox)grdSavings.FooterRow.FindControl("txtDescription")).Text;
    //    string Create_User = Session["UserName"].ToString();
    //    grdSavings.DataSource = objSavings.Inserthistorysavings(Cust_id, DateFrom, DateTo, SavingType, Utilitytype, Amount, Description, Create_User, CNB);
    //    grdSavings.DataBind();

    //}

    protected void UpdateSavings(object sender, GridViewUpdateEventArgs e)
    {
        DALHistorySavings objSavings = new DALHistorySavings();
        string ID = ((Label)grdSavings.Rows[e.RowIndex].FindControl("Id")).Text;
        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());
        //Cust_id = 5;
        DateTime DateFrom = Convert.ToDateTime(((TextBox)grdSavings.Rows[e.RowIndex].FindControl("txtFromDate")).Text);
        DateTime DateTo = Convert.ToDateTime(((TextBox)grdSavings.Rows[e.RowIndex].FindControl("txtToDate")).Text);
        int SavingType = ((DropDownList)grdSavings.Rows[e.RowIndex].FindControl("ddlSaving_type")).SelectedIndex;
        int Utilitytype = ((DropDownList)grdSavings.Rows[e.RowIndex].FindControl("ddlUtility_type")).SelectedIndex;
        double Amount = Convert.ToDouble(((TextBox)grdSavings.Rows[e.RowIndex].FindControl("txtAmount")).Text);
        int CNB = Convert.ToInt16(((TextBox)grdSavings.Rows[e.RowIndex].FindControl("txtCNB")).Text);
        string Description = ((TextBox)grdSavings.Rows[e.RowIndex].FindControl("txtDescription")).Text;
        string Update_User = Session["UserName"].ToString();
        grdSavings.EditIndex = -1;
        grdSavings.DataSource = objSavings.Updatehistorysavings(Convert.ToInt32(ID), Cust_id, DateFrom, DateTo, SavingType, Utilitytype, Amount, Description, Update_User, CNB);
        grdSavings.DataBind();
    }

    protected void EditSavings(object sender, GridViewEditEventArgs e)


    {
        grdSavings.EditIndex = e.NewEditIndex;
        getHistorySavings();
    }

    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)


    {
        grdSavings.EditIndex = -1;
        getHistorySavings();
    }
    
    protected void DeleteSavings(object sender, EventArgs e)


    {
        
        DALHistorySavings objSavings = new DALHistorySavings();
        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());
        //Cust_id = 5;
        LinkButton lnkRemove = (LinkButton)sender;
        grdSavings.DataSource = objSavings.delHistorySavings(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);
        getHistorySavings();
    }

    protected void OnPaging(object sender, GridViewPageEventArgs e)

    {
        grdSavings.PageIndex = e.NewPageIndex;
        grdSavings.DataSource = (DataSet)Session["HOSGrid"];
        grdSavings.DataBind();
    }


    protected void grd_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        try
        {
            
            if (e.Row.RowState == DataControlRowState.Edit || (e.Row.RowState == (DataControlRowState.Alternate | DataControlRowState.Edit)))
            {

                DropDownList ddlSaving_type = (DropDownList)e.Row.FindControl("ddlSaving_type");
                ddlSaving_type.SelectedIndex = ddlSaving_type.Items.IndexOf(ddlSaving_type.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "Savtype").ToString()));

                DropDownList ddlUtility_type = (DropDownList)e.Row.FindControl("ddlUtility_type");
                ddlUtility_type.SelectedIndex = ddlUtility_type.Items.IndexOf(ddlUtility_type.Items.FindByText(DataBinder.Eval(e.Row.DataItem, "Util_type").ToString()));

            }
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        { }
    }


}