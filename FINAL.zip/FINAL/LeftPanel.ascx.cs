﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;

public partial class LeftPanel : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void tariff_Click(object sender, EventArgs e)
    {
        Response.Redirect("Tariff.aspx");
    }
    
    protected void Opus_Automization_Click(object sender, EventArgs e)
    {
        Response.Redirect("Opus.aspx");
    }


    protected void Southern_Automization_Click(object sender, EventArgs e)
    {
        Response.Redirect("Southern.aspx");
    }
    protected void EDF_Automization_Click(object sender, EventArgs e)
    {
        Response.Redirect("EDF.aspx");
    }
}