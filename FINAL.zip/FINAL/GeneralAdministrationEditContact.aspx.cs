﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class GeneralAdministrationEditContact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {  
        if (!Page.IsPostBack)
        {
            Session["EditInitialContactUniqueID"] = Request.QueryString["value"].ToString();
            hdnIDAddContact.Value = Session["EditInitialContactUniqueID"].ToString();
                
            DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();
            DataTable dtRetainEditContact = new DataTable();
             try
            {
                dtRetainEditContact = objGeneralAdministration.GetRetainEditInitialContactData(Convert.ToInt32(hdnIDAddContact.Value));
                if (dtRetainEditContact.Rows.Count > 0)
                {

                    if (dtRetainEditContact.Rows[0][4].ToString().Length > 0)
                    {
                        divAttachCopyOfEmail.Visible = false;
                        lnkViewCopyOfTheEmail.Text = dtRetainEditContact.Rows[0][4].ToString();
                        divViewCopyOfEmail.Visible = true;
                        Session["CopyOfEmailFileName"] = dtRetainEditContact.Rows[0][4].ToString();
                        Session["CopyOfEmailFilePath"] = dtRetainEditContact.Rows[0][5].ToString();
                    }
                    
                    if (dtRetainEditContact.Rows[0][2].ToString().Length > 0)
                    {
                        txtBriefDescription.Text = dtRetainEditContact.Rows[0][2].ToString();
                    }                                        
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }            
        } 
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "CancelAddedInitialContact()", true);
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {        

        DALGeneralAdministration objGeneralAdministration = new DALGeneralAdministration();

        string CurrentFilePath = "", CurrentFileName = "";
        DateTime dtNow = DateTime.Now;
        if (fileUploadCopyOfTheEmail.HasFile)
        {
            CurrentFileName = fileUploadCopyOfTheEmail.FileName;
            fileUploadCopyOfTheEmail.SaveAs(HttpContext.Current.Server.MapPath("PostedFiles\\GeneralAdministrationEmailCopy\\") + dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadCopyOfTheEmail.FileName);
            CurrentFilePath = HttpContext.Current.Server.MapPath("PostedFiles\\GeneralAdministrationEmailCopy\\") +
            dtNow.Year.ToString() + dtNow.Month.ToString() + dtNow.Day.ToString() + dtNow.Minute.ToString() + dtNow.Second.ToString() + dtNow.Millisecond.ToString() + fileUploadCopyOfTheEmail.FileName;
            objGeneralAdministration.SaveAddedInitialContact(Convert.ToInt32(hdnIDAddContact.Value), txtBriefDescription.Text, CurrentFileName, CurrentFilePath, Session["UserName"].ToString(), Convert.ToInt32(Session["CustID"].ToString()));
        }
        else
        {
            objGeneralAdministration.SaveAddedInitialContactWithoutFile(Convert.ToInt32(hdnIDAddContact.Value), txtBriefDescription.Text, Session["UserName"].ToString(), Convert.ToInt32(Session["CustID"].ToString()));
        }

        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "CallJSFunction", "SaveAddedInitialContact()", true);

        string scriptString = "<script language='''JavaScript'''> " + "window.opener.document.forms(0).submit(); </script>";

        // ASP.NET 2.0
        if (!Page.ClientScript.IsClientScriptBlockRegistered(scriptString))
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", scriptString);
        }  
    }

    protected void lnkViewCopyOfTheEmail_Click(object sender, EventArgs e)
    {
        Response.ClearContent();
        Response.AddHeader("content-disposition", "attachment; filename=" + Convert.ToString(Session["CopyOfEmailFileName"]));
        Response.ContentType = "";
        FileStream MyFileStream;
        long FileSize;
        MyFileStream = new FileStream(Convert.ToString(Session["CopyOfEmailFilePath"]), FileMode.Open); // you can get file path this way ---                      //LinkButton btn = sender as LinkButton;  string path = btn.CommandArgument.ToString();
        FileSize = MyFileStream.Length;
        byte[] Buffer = new byte[(int)FileSize];
        MyFileStream.Read(Buffer, 0, (int)FileSize);
        MyFileStream.Close();
        Response.BinaryWrite(Buffer);
        Response.End();
    }
}