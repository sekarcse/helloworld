﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class HHSTariff : System.Web.UI.Page
{
    int Cust_id = 0;
    
    protected void Page_Load(object sender, EventArgs e)
    {

        //////temp remove later starts
        //Session["CustID"] = "5";
        //Session["CompanyName"] = "testcompantname";
        //Session["RoleID"] = "1";
        //////temp remove later ends

        
        
        if (!IsPostBack)
        {
            if (Session["RoleID"] != null)
            {                
                DisplaySuppliers();
                BindDataHHSTariff();
            }
            else
            {                
                Response.Redirect("login.asp");
            }
        }
    }



    public void DisplaySuppliers()
    {
        try
        {
            DALHHSTariff objDisplaySuppliers = new DALHHSTariff();
            DataSet dsDisplaySuppliers = new DataSet();
            dsDisplaySuppliers = objDisplaySuppliers.DisplaySuppliers();
            ddlHHSTariffSupplierName.DataSource = dsDisplaySuppliers.Tables[0];
            ddlHHSTariffSupplierName.DataTextField = "supplier_name";
            ddlHHSTariffSupplierName.DataValueField = "supplier_id";
            ddlHHSTariffSupplierName.DataBind();
            ddlHHSTariffSupplierName.Items.Insert(0, "Please Select a Supplier");            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "Load Data Records", "DisplaySuppliers", ex.Message);
        }
    }

    public void BindDataHHSTariff()
    {
        try
        {
            DALHHSTariff objLoadHHSTariffParent = new DALHHSTariff();
            DataSet dsLoadHHSTariffParent = new DataSet();

            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());

            dsLoadHHSTariffParent = objLoadHHSTariffParent.LoadHHSTariffParent(Cust_id);

            if (dsLoadHHSTariffParent.Tables[0].Rows.Count == 1)
            {
                divHHSTariffSaveCancel.Visible = false;

                hdnHHSTariffPArentID.Value = Convert.ToString(dsLoadHHSTariffParent.Tables[0].Rows[0]["Id"]);

                ddlHHSTariffSupplierName.ClearSelection();
                if (dsLoadHHSTariffParent.Tables[0].Rows[0]["supplier"].ToString() != "0")
                {
                    ddlHHSTariffSupplierName.Items.FindByValue(dsLoadHHSTariffParent.Tables[0].Rows[0]["supplier"].ToString()).Selected = true;
                }

                ddlHHSTariffStandingChargePeriod.ClearSelection();
                if (dsLoadHHSTariffParent.Tables[0].Rows[0]["std_charge_period"].ToString() != "0")
                {
                    ddlHHSTariffStandingChargePeriod.Items.FindByValue(dsLoadHHSTariffParent.Tables[0].Rows[0]["std_charge_period"].ToString()).Selected = true;
                }

                //txtHHSTariffStandingChargeRate.Text = Convert.ToString(dsLoadHHSTariffParent.Tables[0].Rows[0]["std_charge"]);
                txtHHSTariffStandingChargeRate.Text = String.Format("{0:N2}", Convert.ToDouble(Convert.ToString(dsLoadHHSTariffParent.Tables[0].Rows[0]["std_charge"])));

                divHHSTariffSaveCancel.Visible = false;

                DataTable dtnull = new DataTable();

                dtnull.Columns.Add("Id");
                //dtnull.Columns.Add("Cust_id");
                dtnull.Columns.Add("Start_date");
                dtnull.Columns.Add("End_date");
                dtnull.Columns.Add("Reading_Type");
                dtnull.Columns.Add("Reading_StartTime");
                dtnull.Columns.Add("Reading_EndTime");
                dtnull.Columns.Add("Rate");               

                if (dsLoadHHSTariffParent.Tables[1].Rows.Count > 0)
                {
                    grdHHSTariff.DataSource = dsLoadHHSTariffParent.Tables[1];
                    grdHHSTariff.DataBind();
                }
                else if (dsLoadHHSTariffParent.Tables[1].Rows.Count == 0)
                {
                    //grdHHSTariff.FooterRow.Visible = true;
                    //grdHHSTariff.DataSource = dsLoadHHSTariffParent.Tables[1];
                    //grdHHSTariff.DataBind();
                    //grdHHSTariff.ShowFooter = true;


                    DataRow d = dtnull.NewRow();
                    d["Id"] = 0;
                    //d["Cust_id"] = null;
                    d["Start_date"] = null;
                    d["End_date"] = null;
                    d["Reading_Type"] = null;
                    d["Reading_StartTime"] = null;
                    d["Reading_EndTime"] = null;
                    d["Rate"] = null;              
                    

                    dtnull.Rows.Add(d);
                    Session["RecommendationGrid"] = dtnull;
                    grdHHSTariff.DataSource = dtnull;
                    grdHHSTariff.DataBind();
                    grdHHSTariff.Rows[0].Visible = false;
                    grdHHSTariff.Rows[0].Controls.Clear();
                }
            }
            else
            {
                divHHSTariffSaveCancel.Visible = true;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "HHS Tariff Parent", "BindDataHHSTariff", ex.Message);
        }
    }




    protected void btnSaveHHSTariffParent_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustID"] != null)
                Cust_id = Convert.ToInt16(Session["CustID"].ToString());
            
            int iSupplierID = 0;

            if (ddlHHSTariffSupplierName.SelectedIndex != 0)
            {
                iSupplierID = Convert.ToInt32(ddlHHSTariffSupplierName.SelectedValue);
            }

            string sStandingChargePeriod = "0";

            if (ddlHHSTariffStandingChargePeriod.SelectedIndex != 0)
            {
                sStandingChargePeriod = Convert.ToString(ddlHHSTariffStandingChargePeriod.SelectedValue);
            }

            Decimal dstd_charge = 0;
            if (Convert.ToString(txtHHSTariffStandingChargeRate.Text.Trim()).Length > 0)
            {
                dstd_charge = Convert.ToDecimal(txtHHSTariffStandingChargeRate.Text.Trim());
            }

            string sStructure = string.Empty;

            DALHHSTariff objSaveHHSTariffParent = new DALHHSTariff();

            Int64 iHHSTariffParentID = 0;
            iHHSTariffParentID = objSaveHHSTariffParent.SaveHHSTariffParent(Cust_id, iSupplierID, sStandingChargePeriod, dstd_charge, sStructure, Convert.ToString(Session["UserName"]));
            if (iHHSTariffParentID > 0)
            {
                //divHHSTariffSaveCancel.Visible = false;
                //hdnHHSTariffPArentID.Value = Convert.ToString(iHHSTariffParentID);
                Response.Redirect("HHSTariff.aspx", false);
            }
            else if (iHHSTariffParentID == 0)
            {
                //display java script warning message not saved
                //Response.Redirect("HHSTariff.aspx", false);
            }            
            
                         
        }      
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "HHS Tariff", "btnSaveHHSTariffParent_Click", ex.Message);
        }
    }

    protected void btnCancelHHSTariffParent_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("HHSTariff.aspx", false);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "HHS Tariff", "btnCancelHHSTariffParent_Click", ex.Message);
        }
    }




    protected void DeleteTariffChild(object sender, EventArgs e)
    {
        try
        {
        DALHHSTariff objDeleteTariff = new DALHHSTariff();

        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());

        LinkButton lnkRemove = (LinkButton)sender;
        objDeleteTariff.DeleteTariffChild(Convert.ToInt32(lnkRemove.CommandArgument), Cust_id);
        Response.Redirect("HHSTariff.aspx", false);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "HHS Tariff", "DeleteTariffChild", ex.Message);
        }
    }





    protected void AddNewTariffChild(object sender, EventArgs e)
    {
        try
        {
        DALHHSTariff objAddNewTariffChild = new DALHHSTariff();

        if (Session["CustID"] != null)
            Cust_id = Convert.ToInt16(Session["CustID"].ToString());


        DateTime Start_date = Convert.ToDateTime(((TextBox)grdHHSTariff.FooterRow.FindControl("txtStartDate")).Text);
        DateTime End_date = Convert.ToDateTime(((TextBox)grdHHSTariff.FooterRow.FindControl("txtEndDate")).Text);

        string Reading_Type = string.Empty;

        if (((DropDownList)grdHHSTariff.FooterRow.FindControl("ddlReading_Type")).SelectedValue != "0")
        {
            Reading_Type = ((DropDownList)grdHHSTariff.FooterRow.FindControl("ddlReading_Type")).SelectedValue;
        }

        string Reading_StartTime = ((TextBox)grdHHSTariff.FooterRow.FindControl("txtReading_StartTime")).Text;
        string Reading_EndTime = ((TextBox)grdHHSTariff.FooterRow.FindControl("txtReading_EndTime")).Text;

        Decimal Rate = Convert.ToDecimal(((TextBox)grdHHSTariff.FooterRow.FindControl("txtRate")).Text);

        objAddNewTariffChild.AddNewTariffChild(Cust_id, Start_date, End_date, Reading_Type, Reading_StartTime, Reading_EndTime, Convert.ToString(Session["UserName"]), Convert.ToInt64(Convert.ToString(hdnHHSTariffPArentID.Value)), Rate);
        Response.Redirect("HHSTariff.aspx", false);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteLogFile(Server.MapPath("~/ErrorLog/Log.txt"), "HHS Tariff", "AddNewTariffChild", ex.Message);
        }
    }




}