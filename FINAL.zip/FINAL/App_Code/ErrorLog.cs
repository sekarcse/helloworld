﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

/// <summary>
/// Summary description for ErrorLog
/// </summary>
public static class ErrorLog
{
    #region Error Log
    public static void WriteLogFile(string filePath, string fileName, string methodName, string message)
    {

        try
        {

            if (!string.IsNullOrEmpty(message))
            {

                using (FileStream file = new FileStream(filePath, FileMode.Append, FileAccess.Write))
                {

                    StreamWriter streamWriter = new StreamWriter(file);

                    streamWriter.WriteLine((((System.DateTime.Now + " - ") + fileName + " - ") + methodName + " - ") + message);

                    streamWriter.Close();

                }

            }

        }

        catch
        {

        }

    }
    #endregion
}