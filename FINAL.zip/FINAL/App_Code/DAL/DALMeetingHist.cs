﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALMeetingHist
/// </summary>
public class DALMeetingHist
{
	public DALMeetingHist()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public void AddMeetingHistory(int MeetingCalledBy_Id, int CalledBy_Id, string CalledBy_Name, int VenueID, string AuthorisedBy, DateTime Meeting_date, string strMonarchAttendees, string strOtherAttendees, string strPurpose, string strResult, string ClientAction_PersonName, string strOtherAction, string MonarchAction_PersonName, string strMonarchAction, string FileName, string FilePath, string MeetingMinutes,string Create_User)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("AddMeetingHistory", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledBy_Id", MeetingCalledBy_Id));
            myCommand.Parameters.Add(new SqlParameter("@CalledBy_Id", CalledBy_Id));
            myCommand.Parameters.Add(new SqlParameter("@CalledBy_Name", CalledBy_Name));
            myCommand.Parameters.Add(new SqlParameter("@VenueID", VenueID));
            myCommand.Parameters.Add(new SqlParameter("@AuthorisedBy", AuthorisedBy));
            myCommand.Parameters.Add(new SqlParameter("@Meeting_date", Meeting_date));
            myCommand.Parameters.Add(new SqlParameter("@strMonarchAttendees", strMonarchAttendees));
            myCommand.Parameters.Add(new SqlParameter("@strOtherAttendees", strOtherAttendees));
            myCommand.Parameters.Add(new SqlParameter("@strPurpose", strPurpose));
            myCommand.Parameters.Add(new SqlParameter("@strResult", strResult));            
            myCommand.Parameters.Add(new SqlParameter("@ClientAction_PersonName", ClientAction_PersonName));
            myCommand.Parameters.Add(new SqlParameter("@strOtherAction", strOtherAction));
            myCommand.Parameters.Add(new SqlParameter("@MonarchAction_PersonName", MonarchAction_PersonName));
            myCommand.Parameters.Add(new SqlParameter("@strMonarchAction", strMonarchAction));            
            myCommand.Parameters.Add(new SqlParameter("@FileName", FileName));
            myCommand.Parameters.Add(new SqlParameter("@FilePath", FilePath));
            myCommand.Parameters.Add(new SqlParameter("@MeetingMinutes", MeetingMinutes));
            myCommand.Parameters.Add(new SqlParameter("@create_user", Create_User));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateMeetingHistory(int HistoryID, int MeetingCalledBy_Id, int CalledBy_Id, string CalledBy_Name, int VenueID, string AuthorisedBy, DateTime Meeting_date, string strMonarchAttendees, string strOtherAttendees, string strPurpose, string strResult, string ClientAction_PersonName, string strOtherAction, string MonarchAction_PersonName, string strMonarchAction, string FileName, string FilePath, string MeetingMinutes, string Update_User)
    {
        SqlConnection myConn = null;
        try
        {            
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateMeetingHistory", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@HistoryID", HistoryID));
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledBy_Id", MeetingCalledBy_Id));
            myCommand.Parameters.Add(new SqlParameter("@CalledBy_Id", CalledBy_Id));
            myCommand.Parameters.Add(new SqlParameter("@CalledBy_Name", CalledBy_Name));
            myCommand.Parameters.Add(new SqlParameter("@VenueID", VenueID));
            myCommand.Parameters.Add(new SqlParameter("@AuthorisedBy", AuthorisedBy));
            myCommand.Parameters.Add(new SqlParameter("@Meeting_date", Meeting_date));
            myCommand.Parameters.Add(new SqlParameter("@strMonarchAttendees", strMonarchAttendees));
            myCommand.Parameters.Add(new SqlParameter("@strOtherAttendees", strOtherAttendees));
            myCommand.Parameters.Add(new SqlParameter("@strPurpose", strPurpose));
            myCommand.Parameters.Add(new SqlParameter("@strResult", strResult));
            myCommand.Parameters.Add(new SqlParameter("@ClientAction_PersonName", ClientAction_PersonName));
            myCommand.Parameters.Add(new SqlParameter("@strOtherAction", strOtherAction));
            myCommand.Parameters.Add(new SqlParameter("@MonarchAction_PersonName", MonarchAction_PersonName));
            myCommand.Parameters.Add(new SqlParameter("@strMonarchAction", strMonarchAction));
            myCommand.Parameters.Add(new SqlParameter("@FileName", FileName));
            myCommand.Parameters.Add(new SqlParameter("@FilePath", FilePath));
            myCommand.Parameters.Add(new SqlParameter("@MeetingMinutes", MeetingMinutes));
            myCommand.Parameters.Add(new SqlParameter("@last_update_user", Update_User));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet ViewEditMeetingHistory(int HistoryID)
    {        
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("ViewEditMeetingHistoryNew", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@HistID", HistoryID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingHistory");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet ViewMeetingHistory(int HistoryID)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("getMeetingHistoryViewValues", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@HistoryID", HistoryID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingHistory");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }
    

    public DataSet getAllMeetingHistories(int MeetingCalledBy_Id, int CalledBy_Id)
    {
        
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {

            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getMeetingHistory", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@MeetingCalledBy_Id", MeetingCalledBy_Id));
            strCommand.Parameters.Add(new SqlParameter("@CalledBy_Id", CalledBy_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "MeetingHistory");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



}