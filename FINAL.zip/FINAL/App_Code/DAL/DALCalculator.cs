﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DALCalculator
/// </summary>
public class DALCalculator
{
	public DALCalculator()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataSet getMatchedMPAN(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getMatchedMPAN", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "MatchedMPAN");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }


    public DataSet getUnmatchedMPAN(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getUnmatchedMPAN", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "UnmatchedMPAN");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }





    public DataSet HalfHourDataDetails(string sHalfHourDataTableName)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPGetHalfHourDataDetails", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@HalfHourDataTableName", sHalfHourDataTableName));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "HalfHourDataDetails");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }




    public DataSet getCalculatePeriodRate()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPCalculatePeriodRate", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;           
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CalculatePeriodRate");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet LineLossUsingDistributionDetails(string sLineLossCode, string SDistributionID)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPLineLossUsingDistributionDetails", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@LLCs_LLF", sLineLossCode));
            strCommand.Parameters.Add(new SqlParameter("@DID", SDistributionID));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "LineLossUsingDistributionDetails");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }





    public DataSet TimeBandsPeriodDetails(string Regional_Elec_Company, string DID)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPTimeBandsPeriodDetails", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Regional_Elec_Company", Regional_Elec_Company));
            strCommand.Parameters.Add(new SqlParameter("@Zone", DID));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "TimeBandsPeriodDetails");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }





    public DataSet CalculateTotalUnitsFromTimeBands(int iStartDay, int iEndDay, int iStartMonth, int iEndMonth, string sStartTime, string sEndTime, string sMPAN)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPCalculateTotalUnitsFromTimeBands", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@StartDay", iStartDay));
            strCommand.Parameters.Add(new SqlParameter("@EndDay", iEndDay));
            strCommand.Parameters.Add(new SqlParameter("@StartMonth", iStartMonth));
            strCommand.Parameters.Add(new SqlParameter("@EndMonth", iEndMonth));
            strCommand.Parameters.Add(new SqlParameter("@StartTime", sStartTime));
            strCommand.Parameters.Add(new SqlParameter("@EndTime", sEndTime));
            strCommand.Parameters.Add(new SqlParameter("@MPAN", sMPAN));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CalculateTotalUnitsFromTimeBands");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }





    public DataSet getCalculateTariff(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPCalculateTariff", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CalculateTariff");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }




    public DataSet GetMPANforTariffCalculation()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPGetMPANforTariffCalculation", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "GetMPANforTariffCalculation");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }




    public DataSet CalculateTariffTotalWithTime(DateTime dStart_date, DateTime dEnd_date, string sReading_StartTime, string sReading_EndTime, string sMPAN)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPCalculateTariffTotalWithTime", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Start_date", dStart_date));
            strCommand.Parameters.Add(new SqlParameter("@End_date", dEnd_date));
            strCommand.Parameters.Add(new SqlParameter("@Reading_StartTime", sReading_StartTime));
            strCommand.Parameters.Add(new SqlParameter("@Reading_EndTime", sReading_EndTime));
            strCommand.Parameters.Add(new SqlParameter("@MPAN", sMPAN));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CalculateTariffTotalWithTime");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    public DataSet getCalculateFactoral(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPgetCalculateFactoral", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CalculateFactoral");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }






    public void UpdateWithPeriodSouthEastLowVoltageNetwork19(string MPAN)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodSouthEastLowVoltageNetwork19", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public void UpdateWithPeriodLondonLowVoltageNetwork12(string MPAN)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodLondonLowVoltageNetwork12", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateWithPeriodSouthEastDID19(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodSouthEastDID19", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }



    public void UpdateWithPeriodEastMidlandsDID11(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodEastMidlandsDID11", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }



    public void UpdateWithPeriodScottishHydroDID17(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodScottishHydroDID17", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateWithPeriodSWALECDID21(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodSWALECDID21", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateWithPeriodSWEBDID22(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodSWEBDID22", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateWithPeriodYorkshireDID23(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodYorkshireDID23", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }




    public void UpdateWithPeriodMANWEBDID13(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodMANWEBDID13", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateWithPeriodNorthWestDID16(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodNorthWestDID16", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateWithPeriodNorthernDID15(string MPAN, string Metered_Voltage, string DID)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateWithPeriodNorthernDID15", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MPAN", MPAN));
            myCommand.Parameters.Add(new SqlParameter("@Metered_Voltage", Metered_Voltage));
            myCommand.Parameters.Add(new SqlParameter("@DID", DID));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet ValidateTariff(Int64 Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPValidateTariff", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "ValidateTariff");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



}