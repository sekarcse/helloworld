﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALCIS
/// </summary>
public class DALCIS
{
	public DALCIS()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int AddCIS(int Customer_id, int Cust_Id, string Company_name, string Company_Reg_No, string Signatory, string Title,
        string Address_line1, string Address_line2, string Address_line3, string Telephone, string Mobile,
        string Email, string Fax, string City, string County, string Postcode,DateTime Contract_Signed_date,
        DateTime ContractFrom, DateTime ContractTo, string ContractType, string ShareOfRefund, int LOAProvided,
        string MonarchTermEnterBy, DateTime MonarchTermDate, string Note, string Create_User, string Update_User, int flag)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("AddCIS", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Customer_id", Customer_id));
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            strCommand.Parameters.Add(new SqlParameter("@Company_name", Company_name));
            strCommand.Parameters.Add(new SqlParameter("@Company_Reg_No", Company_Reg_No));
            strCommand.Parameters.Add(new SqlParameter("@Signatory", Signatory));
            strCommand.Parameters.Add(new SqlParameter("@Title", Title));
            strCommand.Parameters.Add(new SqlParameter("@Address_line1", Address_line1));
            strCommand.Parameters.Add(new SqlParameter("@Address_line2", Address_line2));
            strCommand.Parameters.Add(new SqlParameter("@Address_line3", Address_line3));
            strCommand.Parameters.Add(new SqlParameter("@Telephone", Telephone));
            strCommand.Parameters.Add(new SqlParameter("@Mobile", Mobile));
            strCommand.Parameters.Add(new SqlParameter("@Email", Email));
            strCommand.Parameters.Add(new SqlParameter("@Fax", Fax));
            strCommand.Parameters.Add(new SqlParameter("@City", City));
            strCommand.Parameters.Add(new SqlParameter("@County", County));
            strCommand.Parameters.Add(new SqlParameter("@Postcode", Postcode));
            strCommand.Parameters.Add(new SqlParameter("@Contract_Signed_date", Contract_Signed_date));
            strCommand.Parameters.Add(new SqlParameter("@ContractFrom", ContractFrom));
            strCommand.Parameters.Add(new SqlParameter("@ContractTo", ContractTo));
            strCommand.Parameters.Add(new SqlParameter("@ContractType", ContractType));
            strCommand.Parameters.Add(new SqlParameter("@ShareOfRefund", ShareOfRefund));
            strCommand.Parameters.Add(new SqlParameter("@LOAProvided", LOAProvided));
            strCommand.Parameters.Add(new SqlParameter("@MonarchTermEnterBy", MonarchTermEnterBy));
            strCommand.Parameters.Add(new SqlParameter("@MonarchTermDate", MonarchTermDate));
            strCommand.Parameters.Add(new SqlParameter("@Note", Note));
            strCommand.Parameters.Add(new SqlParameter("@Create_User", Create_User));
            strCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            strCommand.Parameters.Add(new SqlParameter("@flag", flag));
            
            int CID = Convert.ToInt32(strCommand.ExecuteScalar().ToString());
            return CID;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return 0;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }


    public int UpdateCIS(int Customer_id, int Cust_Id, string Company_name, string Company_Reg_No, string Signatory, string Title,
        string Address_line1, string Address_line2, string Address_line3, string Telephone, string Mobile,
        string Email, string Fax, string City, string County, string Postcode, DateTime Contract_Signed_date,
        DateTime ContractFrom, DateTime ContractTo, string ContractType, string ShareOfRefund, int LOAProvided,
        string MonarchTermEnterBy, DateTime MonarchTermDate, string Note, string Create_User, string Update_User, int flag)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("UpdateCIS", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Customer_id", Customer_id));
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            strCommand.Parameters.Add(new SqlParameter("@Company_name", Company_name));
            strCommand.Parameters.Add(new SqlParameter("@Company_Reg_No", Company_Reg_No));
            strCommand.Parameters.Add(new SqlParameter("@Signatory", Signatory));
            strCommand.Parameters.Add(new SqlParameter("@Title", Title));
            strCommand.Parameters.Add(new SqlParameter("@Address_line1", Address_line1));
            strCommand.Parameters.Add(new SqlParameter("@Address_line2", Address_line2));
            strCommand.Parameters.Add(new SqlParameter("@Address_line3", Address_line3));
            strCommand.Parameters.Add(new SqlParameter("@Telephone", Telephone));
            strCommand.Parameters.Add(new SqlParameter("@Mobile", Mobile));
            strCommand.Parameters.Add(new SqlParameter("@Email", Email));
            strCommand.Parameters.Add(new SqlParameter("@Fax", Fax));
            strCommand.Parameters.Add(new SqlParameter("@City", City));
            strCommand.Parameters.Add(new SqlParameter("@County", County));
            strCommand.Parameters.Add(new SqlParameter("@Postcode", Postcode));
            strCommand.Parameters.Add(new SqlParameter("@Contract_Signed_date", Contract_Signed_date));
            strCommand.Parameters.Add(new SqlParameter("@ContractFrom", ContractFrom));
            strCommand.Parameters.Add(new SqlParameter("@ContractTo", ContractTo));
            strCommand.Parameters.Add(new SqlParameter("@ContractType", ContractType));
            strCommand.Parameters.Add(new SqlParameter("@ShareOfRefund", ShareOfRefund));
            strCommand.Parameters.Add(new SqlParameter("@LOAProvided", LOAProvided));
            strCommand.Parameters.Add(new SqlParameter("@MonarchTermEnterBy", MonarchTermEnterBy));
            strCommand.Parameters.Add(new SqlParameter("@MonarchTermDate", MonarchTermDate));
            strCommand.Parameters.Add(new SqlParameter("@Note", Note));
            strCommand.Parameters.Add(new SqlParameter("@Create_User", Create_User));
            strCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            strCommand.Parameters.Add(new SqlParameter("@flag", flag));
            int CID = (Int32)strCommand.ExecuteScalar();
            return CID;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return 0;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet AddCIS_Contacts(int Contact_Id, int Cust_Id, string Contact, string Title, string Telephone, string Mobile,
        string Fax, string Email, string Create_User, string Update_User, int Contact_Id2,
        string Contact2, string Title2, string Telephone2, string Mobile2, string Fax2, string Email2)

    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("AddCIS_Contacts", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Contact_Id", Contact_Id));
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            strCommand.Parameters.Add(new SqlParameter("@Contact", Contact));
            strCommand.Parameters.Add(new SqlParameter("@Title", Title));
            strCommand.Parameters.Add(new SqlParameter("@Telephone", Telephone));
            strCommand.Parameters.Add(new SqlParameter("@Mobile", Mobile));
            strCommand.Parameters.Add(new SqlParameter("@Fax", Fax));
            strCommand.Parameters.Add(new SqlParameter("@Email", Email));
            strCommand.Parameters.Add(new SqlParameter("@Create_User", Create_User));
            strCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            strCommand.Parameters.Add(new SqlParameter("@Contact_Id2", Contact_Id2));
            strCommand.Parameters.Add(new SqlParameter("@Contact2", Contact2));
            strCommand.Parameters.Add(new SqlParameter("@Title2", Title2));
            strCommand.Parameters.Add(new SqlParameter("@Telephone2", Telephone2));
            strCommand.Parameters.Add(new SqlParameter("@Mobile2", Mobile2));
            strCommand.Parameters.Add(new SqlParameter("@Fax2", Fax2));
            strCommand.Parameters.Add(new SqlParameter("@Email2", Email2));

            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CISContactsManagment");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }


    public DataSet UpdateCIS_Contacts(int Contact_Id, int Cust_Id, string Contact, string Title, string Telephone, string Mobile,
        string Fax, string Email, string Create_User, string Update_User, int Contact_Id2,
        string Contact2, string Title2, string Telephone2, string Mobile2, string Fax2, string Email2)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("UpdateCIS_Contacts", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Contact_Id", Contact_Id));
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            strCommand.Parameters.Add(new SqlParameter("@Contact", Contact));
            strCommand.Parameters.Add(new SqlParameter("@Title", Title));
            strCommand.Parameters.Add(new SqlParameter("@Telephone", Telephone));
            strCommand.Parameters.Add(new SqlParameter("@Mobile", Mobile));
            strCommand.Parameters.Add(new SqlParameter("@Fax", Fax));
            strCommand.Parameters.Add(new SqlParameter("@Email", Email));
            strCommand.Parameters.Add(new SqlParameter("@Create_User", Create_User));
            strCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            strCommand.Parameters.Add(new SqlParameter("@Contact_Id2", Contact_Id2));
            strCommand.Parameters.Add(new SqlParameter("@Contact2", Contact2));
            strCommand.Parameters.Add(new SqlParameter("@Title2", Title2));
            strCommand.Parameters.Add(new SqlParameter("@Telephone2", Telephone2));
            strCommand.Parameters.Add(new SqlParameter("@Mobile2", Mobile2));
            strCommand.Parameters.Add(new SqlParameter("@Fax2", Fax2));
            strCommand.Parameters.Add(new SqlParameter("@Email2", Email2));

            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CISContactsManagment");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }
    
    public DataSet InsertCISInfo(int CIS_Id, int Utility_type,int NumberofSite,int Supplier_Id,DateTime Contract_Renewal_Date,int Copy_Contracts_Provided,int Copy_Invoices_Provided,string Create_User)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertCIS_UtilityInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@CIS_Id", CIS_Id));
            myCommand.Parameters.Add(new SqlParameter("@Utility_type", Utility_type));
            myCommand.Parameters.Add(new SqlParameter("@NumberofSite", NumberofSite));
            myCommand.Parameters.Add(new SqlParameter("@Supplier_Id", Supplier_Id));
            myCommand.Parameters.Add(new SqlParameter("@Contract_Renewal_Date", Contract_Renewal_Date));
            myCommand.Parameters.Add(new SqlParameter("@Copy_Contracts_Provided", Copy_Contracts_Provided));
            myCommand.Parameters.Add(new SqlParameter("@Copy_Invoices_Provided", Copy_Invoices_Provided));
            myCommand.Parameters.Add(new SqlParameter("@Create_User", Create_User));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "CIS");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet UpdateCIS_UtilityInfo(int CIS_Id, int Utility_type, int NumberofSite, int Supplier_Id, DateTime Contract_Renewal_Date, int Copy_Contracts_Provided, int Copy_Invoices_Provided, string Update_User)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateCIS_UtilityInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@CIS_Id", CIS_Id));
            myCommand.Parameters.Add(new SqlParameter("@Utility_type", Utility_type));
            myCommand.Parameters.Add(new SqlParameter("@NumberofSite", NumberofSite));
            myCommand.Parameters.Add(new SqlParameter("@Supplier_Id", Supplier_Id));
            myCommand.Parameters.Add(new SqlParameter("@Contract_Renewal_Date", Contract_Renewal_Date));
            myCommand.Parameters.Add(new SqlParameter("@Copy_Contracts_Provided", Copy_Contracts_Provided));
            myCommand.Parameters.Add(new SqlParameter("@Copy_Invoices_Provided", Copy_Invoices_Provided));
            myCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "CIS");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet delCIS_UtilityInfo(int Id,int CIS_Id)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delCIS_UtilityInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@CIS_Id", CIS_Id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "UtilityInfo");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet getAllCISInfo(int CIS_Id)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("getAllCISInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@CIS_Id", CIS_Id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "CIS");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet getCIS(int Cust_Id)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("getCIS", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "CIS");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet UpdateCIS_UtilityInfoWithId(int CIS_Id, int Utility_type, int NumberofSite, int Supplier_Id, DateTime Contract_Renewal_Date, int Copy_Contracts_Provided, int Copy_Invoices_Provided, string Update_User, int Id)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateCIS_UtilityInfo_WithID", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@CIS_Id", CIS_Id));
            myCommand.Parameters.Add(new SqlParameter("@Utility_type", Utility_type));
            myCommand.Parameters.Add(new SqlParameter("@NumberofSite", NumberofSite));
            myCommand.Parameters.Add(new SqlParameter("@Supplier_Id", Supplier_Id));
            myCommand.Parameters.Add(new SqlParameter("@Contract_Renewal_Date", Contract_Renewal_Date));
            myCommand.Parameters.Add(new SqlParameter("@Copy_Contracts_Provided", Copy_Contracts_Provided));
            myCommand.Parameters.Add(new SqlParameter("@Copy_Invoices_Provided", Copy_Invoices_Provided));
            myCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "CIS");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

}