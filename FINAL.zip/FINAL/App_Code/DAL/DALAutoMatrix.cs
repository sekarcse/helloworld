﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALAutoMatrix
/// </summary>
public class DALAutoMatrix
{
	public DALAutoMatrix()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int ResetDatabase()
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("ResetDatabase", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;                        
            SqlParameter parameter = myCommand.Parameters.Add("@RowCount", SqlDbType.Int);
            parameter.Direction = ParameterDirection.Output;
            myCommand.ExecuteNonQuery();
            Int32 rowCount = (Int32)myCommand.Parameters["@RowCount"].Value;
            return rowCount;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return 0;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public int DataCleaning()
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DataCleaning", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            SqlParameter parameter = myCommand.Parameters.Add("@RowCount", SqlDbType.Int);
            parameter.Direction = ParameterDirection.Output;
            myCommand.ExecuteNonQuery();
            Int32 rowCount = (Int32)myCommand.Parameters["@RowCount"].Value;
            return rowCount;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return 0;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }



}