﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALSitecheck
/// </summary>
public class DALSitecheck
{
	public DALSitecheck()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataSet getSitecheck(int Cust_Id)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getHistorySiteCheck", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "Sitecheck");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }


    public DataSet InsertSitecheck(int Cust_Id, string File_NameUser, string File_PathUser, string File_NameClient, string File_PathClient, string create_user, DateTime date)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertHistorySiteCheck", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@File_NameUser", File_NameUser));
            myCommand.Parameters.Add(new SqlParameter("@File_PathUser", File_PathUser));
            myCommand.Parameters.Add(new SqlParameter("@File_NameClient", File_NameClient));
            myCommand.Parameters.Add(new SqlParameter("@File_PathClient", File_PathClient));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ClientAttendees");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet UpdateSitecheck(int Id, int cust_id, string File_NameUser, string File_PathUser, string File_NameClient, string File_PathClient, string update_user, DateTime date)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateHistorySiteCheck", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@cust_id", cust_id));
            myCommand.Parameters.Add(new SqlParameter("@File_NameUser", File_NameUser));
            myCommand.Parameters.Add(new SqlParameter("@File_PathUser", File_PathUser));
            myCommand.Parameters.Add(new SqlParameter("@File_NameClient", File_NameClient));
            myCommand.Parameters.Add(new SqlParameter("@File_PathClient", File_PathClient));
            myCommand.Parameters.Add(new SqlParameter("@update_user", update_user));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Sitecheck");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet delSitecheck(int Id, int cust_id)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delHistorySiteCheck", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@cust_id", cust_id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Sitecheck");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

}