﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for ClientAttendees
/// </summary>
public class DALClientAttendees

{
    public DALClientAttendees()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataSet getClientAttendees(int ClientID, int MeetingCalledById)
    {
        
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getClientAttendees", myConnection);
            strCommand.Parameters.Add(new SqlParameter("@ClientID", ClientID));
            strCommand.Parameters.Add(new SqlParameter("@MeetingCalledById", MeetingCalledById));
            strCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "ClientAttendees");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }


    public DataSet InsertClientAttendees(int ClientID, int MeetingCalledById, string Name, string Designation)
    {
        
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertClientAttendees", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ClientID", ClientID));
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledById", MeetingCalledById));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Designation", Designation));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ClientAttendees");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet UpdateClientAttendees(int ID, int ClientID, int MeetingCalledById, string Name, string Designation)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateClientAttendees", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@ClientID", ClientID));
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledById", MeetingCalledById));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Designation", Designation));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ClientAttendees");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }



    public DataSet DelClientAttendees(int ID, int ClientID, int MeetingCalledById)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DelClientAttendees", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@ClientID", ClientID));
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledById", MeetingCalledById));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);

            da.Fill(ds, "ClientAttendees");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }



}