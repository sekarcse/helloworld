﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for DALGeneralAdministration
/// </summary>
public class DALGeneralAdministration
{
	public DALGeneralAdministration()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable DisplayAccountManager()
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlDataAdapter daAccountManager = null;
        DataTable dtAccountManager = new DataTable();
        SqlCommand cmdAccountManager = new SqlCommand();

        try
        {
            cmdAccountManager.CommandType = CommandType.StoredProcedure;
            cmdAccountManager.CommandText = "DisplayAccountManager";
            cmdAccountManager.Connection = conn;
            daAccountManager = new SqlDataAdapter();
            daAccountManager.SelectCommand = cmdAccountManager;
            daAccountManager.Fill(dtAccountManager);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            daAccountManager.Dispose();
            cmdAccountManager.Dispose();
            conn.Close();
            conn.Dispose();
        }
        return dtAccountManager;
    }

    public string DisplayContractSignedDate(int CustomerID)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmdContractSignedDate = new SqlCommand();
        object ContractSignedDate = null;
        try
        {
            cmdContractSignedDate.CommandType = CommandType.StoredProcedure;
            cmdContractSignedDate.CommandText = "DisplayContractSignedDate";
            cmdContractSignedDate.Connection = conn;
            cmdContractSignedDate.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            ContractSignedDate = cmdContractSignedDate.ExecuteScalar();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
            conn.Dispose();
        }
        return Convert.ToString(ContractSignedDate);
    }

    public DataTable GetInitialContactGrid(int CustomerID)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlDataAdapter daInitialContact = null;
        DataTable dtInitialContact = new DataTable();
        SqlCommand cmdInitialContact = new SqlCommand();

        try
        {
            cmdInitialContact.CommandType = CommandType.StoredProcedure;
            cmdInitialContact.CommandText = "DisplayInitialContactGridGridDetails";
            cmdInitialContact.Connection = conn;
            cmdInitialContact.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            daInitialContact = new SqlDataAdapter();
            daInitialContact.SelectCommand = cmdInitialContact;
            daInitialContact.Fill(dtInitialContact);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            daInitialContact.Dispose();
            cmdInitialContact.Dispose();
            conn.Close();
            conn.Dispose();
        }
        return dtInitialContact;
    }

    public void SaveAddedInitialContact(int ID, string Description, string File_Name, string File_Path, string UserName, int CustomerID)
    {        
            // DBConnection is the web config name
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            try
            {
            SqlCommand command = new SqlCommand("SaveAddedInitialContact", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@ID", ID));
            command.Parameters.Add(new SqlParameter("@Description", Description));            
            command.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            command.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            command.Parameters.Add(new SqlParameter("@UserName", UserName));
            command.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
    }

    public void SaveAddedInitialContactWithoutFile(int ID, string Description, string UserName, int CustomerID)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();

        try
        {
            SqlCommand command = new SqlCommand("SaveAddedInitialContactWithoutFile", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@ID", ID));
            command.Parameters.Add(new SqlParameter("@Description", Description));            
            command.Parameters.Add(new SqlParameter("@UserName", UserName));
            command.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
    }

    public void DeleteInitialContact(int Id)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmdDeleteInitialContact = new SqlCommand();
        try
        {
            cmdDeleteInitialContact.CommandType = CommandType.StoredProcedure;
            cmdDeleteInitialContact.CommandText = "DeleteInitialContact";
            cmdDeleteInitialContact.Connection = conn;
            cmdDeleteInitialContact.Parameters.Add(new SqlParameter("@Id", Id));
            cmdDeleteInitialContact.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
            conn.Dispose();
        }        
    }
    
    public void SaveGeneralAdministration(int ID, DateTime DateContractSigned, DateTime CopyBillsReceived, DateTime CopyBillsPosted, DateTime AllocatedToAnAccountManager, string UserName, string AllocatedAccountManagerName, string CurrentFileName, string CurrentFilePath)
    {        
            // DBConnection is the web config name
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            try
            {
            SqlCommand command = new SqlCommand("SaveGeneralAdministration", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@ID", ID));
            command.Parameters.Add(new SqlParameter("@DateContractSigned", DateContractSigned));
            command.Parameters.Add(new SqlParameter("@CopyBillsReceived", CopyBillsReceived));
            command.Parameters.Add(new SqlParameter("@CopyBillsPosted", CopyBillsPosted));
            command.Parameters.Add(new SqlParameter("@AllocatedToAnAccountManager", AllocatedToAnAccountManager));
            command.Parameters.Add(new SqlParameter("@UserName", UserName));
            command.Parameters.Add(new SqlParameter("@AllocatedAccountManagerName", AllocatedAccountManagerName));
            command.Parameters.Add(new SqlParameter("@File_Name", CurrentFileName));
            command.Parameters.Add(new SqlParameter("@File_Path", CurrentFilePath));
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
    }
        
    public void SaveGeneralAdministrationContract(int ID, int CustomerID, string DateContractSigned, string CopyBillsReceived, string CopyBillsPosted, string AllocatedToAnAccountManager, string UserName, string AllocatedAccountManagerNameddl, string CurrentFileName, string CurrentFilePath)
    {   
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();

        try
        {
            SqlCommand command = new SqlCommand("SaveGeneralAdministrationContract", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@ID", ID));
            command.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            command.Parameters.Add(new SqlParameter("@DateContractSigned", DateContractSigned));
            command.Parameters.Add(new SqlParameter("@CopyBillsReceived", CopyBillsReceived));
            command.Parameters.Add(new SqlParameter("@CopyBillsPosted", CopyBillsPosted));
            command.Parameters.Add(new SqlParameter("@AllocatedToAnAccountManager", AllocatedToAnAccountManager));
            command.Parameters.Add(new SqlParameter("@UserName", UserName));
            command.Parameters.Add(new SqlParameter("@AllocatedAccountManagerNameddl", AllocatedAccountManagerNameddl));
            command.Parameters.Add(new SqlParameter("@File_Name", CurrentFileName));
            command.Parameters.Add(new SqlParameter("@File_Path", CurrentFilePath));
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
    }

    public void SaveGeneralAdministrationContractWithoutScannedCopy(int ID, int CustomerID, string DateContractSigned, string CopyBillsReceived, string CopyBillsPosted, string AllocatedToAnAccountManager, string UserName, string AllocatedAccountManagerNameddl)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();

        try
        {
            SqlCommand command = new SqlCommand("SaveGeneralAdministrationContractWithoutScannedCopy", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@ID", ID));
            command.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            command.Parameters.Add(new SqlParameter("@DateContractSigned", DateContractSigned));
            command.Parameters.Add(new SqlParameter("@CopyBillsReceived", CopyBillsReceived));
            command.Parameters.Add(new SqlParameter("@CopyBillsPosted", CopyBillsPosted));
            command.Parameters.Add(new SqlParameter("@AllocatedToAnAccountManager", AllocatedToAnAccountManager));
            command.Parameters.Add(new SqlParameter("@UserName", UserName));
            command.Parameters.Add(new SqlParameter("@AllocatedAccountManagerNameddl", AllocatedAccountManagerNameddl));
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
    }

    public DataTable GetGeneralAdministration(int CustomerID)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlDataAdapter daGeneralAdministration = null;
        DataTable dtGeneralAdministration = new DataTable();
        SqlCommand cmdGeneralAdministration = new SqlCommand();

        try
        {
            cmdGeneralAdministration.CommandType = CommandType.StoredProcedure;
            cmdGeneralAdministration.CommandText = "DisplayGeneralAdministrationDetails";
            cmdGeneralAdministration.Connection = conn;
            cmdGeneralAdministration.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            daGeneralAdministration = new SqlDataAdapter();
            daGeneralAdministration.SelectCommand = cmdGeneralAdministration;
            daGeneralAdministration.Fill(dtGeneralAdministration);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            daGeneralAdministration.Dispose();
            cmdGeneralAdministration.Dispose();
            conn.Close();
            conn.Dispose();
        }
        return dtGeneralAdministration;
    }

    public DataTable GetRetainEditInitialContactData(int ID)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlDataAdapter daRetainEditContact = null;
        DataTable dtRetainEditContact = new DataTable();
        SqlCommand cmdRetainEditContact = new SqlCommand();

        try
        {
            cmdRetainEditContact.CommandType = CommandType.StoredProcedure;
            cmdRetainEditContact.CommandText = "RetainEditInitialContactData";
            cmdRetainEditContact.Connection = conn;
            cmdRetainEditContact.Parameters.Add(new SqlParameter("@ID", ID));
            daRetainEditContact = new SqlDataAdapter();
            daRetainEditContact.SelectCommand = cmdRetainEditContact;
            daRetainEditContact.Fill(dtRetainEditContact);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            daRetainEditContact.Dispose();
            cmdRetainEditContact.Dispose();
            conn.Close();
            conn.Dispose();
        }
        return dtRetainEditContact;
    }

    public DataSet getTotalNHH(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("DisplayTotalNumberSigned", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@CustomerID", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "TotalNumberNHH_HH_Gas");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public void SaveSignedDetails(int ID, int NHHSigned, int HHSigned, int GasSigned, string UserName, int CustID)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();

        try
        {
            SqlCommand command = new SqlCommand("SaveSignedDetails", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@ID", ID));
            command.Parameters.Add(new SqlParameter("@NHHSigned", NHHSigned));
            command.Parameters.Add(new SqlParameter("@HHSigned", HHSigned));
            command.Parameters.Add(new SqlParameter("@GasSigned", GasSigned));
            command.Parameters.Add(new SqlParameter("@UserName", UserName));
            command.Parameters.Add(new SqlParameter("@CustID", CustID)); 
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
    }   

    public DataSet GetEmailData(int CustomerID, string UserName, string AllocatedAccountManagerNameddl)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("GetEmailData", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@CustomerID", CustomerID));
            strCommand.Parameters.Add(new SqlParameter("@UserName", UserName));
            strCommand.Parameters.Add(new SqlParameter("@AllocatedAccountManagerNameddl", AllocatedAccountManagerNameddl));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "EmailData");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    public DataSet getSummaryProgressReport(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getSummaryProgressReport", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "SummaryProgressReport");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }




    public DataSet InsertNewReasonGeneralAdministration(string create_user, Int64 customer_id, string Reason)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertNewReasonGeneralAdministration", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
            myCommand.Parameters.Add(new SqlParameter("@customer_id", customer_id));
            myCommand.Parameters.Add(new SqlParameter("@Reason", Reason));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ReasonGeneralAdministrationAfterInsert");
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }



    //public DataTable LoadGeneralAdministrationReason(int customer_id)
    //{
    //    // DBConnection is the web config name
    //    string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
    //    SqlConnection conn = new SqlConnection(connectionString);
    //    conn.Open();
    //    SqlDataAdapter daLoadGeneralAdministrationReason = null;
    //    DataTable dtLoadGeneralAdministrationReason = new DataTable();
    //    SqlCommand cmdLoadGeneralAdministrationReason = new SqlCommand();

    //    try
    //    {
    //        cmdLoadGeneralAdministrationReason.CommandType = CommandType.StoredProcedure;
    //        cmdLoadGeneralAdministrationReason.CommandText = "LoadGeneralAdministrationReason";
    //        cmdLoadGeneralAdministrationReason.Connection = conn;
    //        cmdLoadGeneralAdministrationReason.Parameters.Add(new SqlParameter("@customer_id", customer_id));
    //        daLoadGeneralAdministrationReason = new SqlDataAdapter();
    //        daLoadGeneralAdministrationReason.SelectCommand = cmdLoadGeneralAdministrationReason;
    //        daLoadGeneralAdministrationReason.Fill(dtLoadGeneralAdministrationReason);
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    finally
    //    {
    //        daLoadGeneralAdministrationReason.Dispose();
    //        cmdLoadGeneralAdministrationReason.Dispose();
    //        conn.Close();
    //        conn.Dispose();
    //    }
    //    return dtLoadGeneralAdministrationReason;
    //}




    public DataSet LoadGeneralAdministrationReason(int customer_id)
    {
        // DBConnection is the web config name
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlDataAdapter daLoadGeneralAdministrationReason = null;
        DataSet ds = new DataSet();
        SqlCommand cmdLoadGeneralAdministrationReason = new SqlCommand();

        try
        {
            cmdLoadGeneralAdministrationReason.CommandType = CommandType.StoredProcedure;
            cmdLoadGeneralAdministrationReason.CommandText = "LoadGeneralAdministrationReason";
            cmdLoadGeneralAdministrationReason.Connection = conn;
            cmdLoadGeneralAdministrationReason.Parameters.Add(new SqlParameter("@customer_id", customer_id));
            daLoadGeneralAdministrationReason = new SqlDataAdapter();
            daLoadGeneralAdministrationReason.SelectCommand = cmdLoadGeneralAdministrationReason;
            daLoadGeneralAdministrationReason.Fill(ds, "LoadGeneralAdministrationReason");
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
            return ds;
        }
        finally
        {
            daLoadGeneralAdministrationReason.Dispose();
            cmdLoadGeneralAdministrationReason.Dispose();
            conn.Close();
            conn.Dispose();
        }        
    }


    public DataSet LoadClientChecklist(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("LoadClientChecklistGA", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "LoadClientChecklist");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    public Int64 SaveClientChecklistGA(int Cust_Id, int HH_Data, int Network_Capacity_Agreement, int Distribution_Losses, int Transmission_Losses, int Metering_Related_Charges, int Bill_Validation_Exceptions, int Current_NHH_Electricity_Tariff, int Current_Gas_Tariff, int Current_Water_Tariff, int VAT_Charges, int CL_Charges, string create_user)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("SaveClientChecklistGA", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_Id));

            myCommand.Parameters.Add(new SqlParameter("@HH_Data", HH_Data));
            myCommand.Parameters.Add(new SqlParameter("@Network_Capacity_Agreement", Network_Capacity_Agreement));
            myCommand.Parameters.Add(new SqlParameter("@Distribution_Losses", Distribution_Losses));
            myCommand.Parameters.Add(new SqlParameter("@Transmission_Losses", Transmission_Losses));
            myCommand.Parameters.Add(new SqlParameter("@Metering_Related_Charges", Metering_Related_Charges));
            myCommand.Parameters.Add(new SqlParameter("@Bill_Validation_Exceptions", Bill_Validation_Exceptions));
            myCommand.Parameters.Add(new SqlParameter("@Current_NHH_Electricity_Tariff", Current_NHH_Electricity_Tariff));
            myCommand.Parameters.Add(new SqlParameter("@Current_Gas_Tariff", Current_Gas_Tariff));
            myCommand.Parameters.Add(new SqlParameter("@Current_Water_Tariff", Current_Water_Tariff));
            myCommand.Parameters.Add(new SqlParameter("@VAT_Charges", VAT_Charges));
            myCommand.Parameters.Add(new SqlParameter("@CL_Charges", CL_Charges));
           
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));

            SqlParameter parameterAssessmentId = myCommand.Parameters.Add("@ClientChecklistSaved", SqlDbType.BigInt);
            parameterAssessmentId.Direction = ParameterDirection.Output;
            myCommand.ExecuteNonQuery();

            Int64 iClientChecklistSaved = (Int64)myCommand.Parameters["@ClientChecklistSaved"].Value;
            if (myConn != null)
                myConn.Close();
            return iClientChecklistSaved;
        }
        catch (Exception ex)
        {
            ex.ToString();
            if (myConn != null)
                myConn.Close();
            return 0;
        }
    }



}