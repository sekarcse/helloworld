﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALGeneralInfo
/// </summary>
public class DALGeneralInfo
{
	public DALGeneralInfo()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataSet getHistoryGeneralInfo(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getHistoryGeneralInfo", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "GeneralInfo");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    public DataSet InsertHistoryGeneralInfo(int Cust_Id, DateTime date, string File_Name, string File_Path, string Description, string create_user)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertHistoryGeneralInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;            
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));            
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "GeneralInfo");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }



    public DataSet UpdateHistoryGeneralInfo(int Id, int Cust_Id, DateTime date, string File_Name, string File_Path, string Description, string update_user)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateHistoryGeneralInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));
            myCommand.Parameters.Add(new SqlParameter("@update_user", update_user));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "GeneralInfo");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }

    }



    public DataSet delHistoryGeneralInfo(int Id, int Cust_id)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delHistoryGeneralInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "GeneralInfo");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public void GeneralInfoAddNewInsertHistoryGeneralInfo(int Cust_Id, DateTime date, string File_Name, string File_Path, string Description, string create_user)
    {
        SqlConnection myConn = null;        
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertHistoryGeneralInfo", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
            myCommand.ExecuteNonQuery();                        
        }
        catch (Exception ex)
        {
            throw ex;          
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

}