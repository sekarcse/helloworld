﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALClient_Complaint
/// </summary>
public class DALClient_Complaint
{
	public DALClient_Complaint()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataSet getClient_Complaint(int Cust_Id)
    {



        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getClient_Complaint", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "Client_Complaint");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet InsertClient_Complaint(int Cust_Id, DateTime date, string ComplaintMadeby, int ComplaintMode, int ComplaintNature, string File_Name, string File_Path, string create_user)
    {



        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertClient_Complaint", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@ComplaintMadeby", ComplaintMadeby));
            myCommand.Parameters.Add(new SqlParameter("@ComplaintMode", ComplaintMode));
            myCommand.Parameters.Add(new SqlParameter("@ComplaintNature", ComplaintNature));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Client_Complaint");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet UpdateClient_Complaint(int Id, int Cust_Id, DateTime date, string ComplaintMadeby, int ComplaintMode, int ComplaintNature, string File_Name, string File_Path, string Update_User)
    {



        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateClient_Complaint", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@ComplaintMadeby", ComplaintMadeby));
            myCommand.Parameters.Add(new SqlParameter("@ComplaintMode", ComplaintMode));
            myCommand.Parameters.Add(new SqlParameter("@ComplaintNature", ComplaintNature));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Client_Complaint");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet delClient_Complaint(int Id, int cust_id)
    {



        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delClient_Complaint", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@cust_id", cust_id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Client_Complaint");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


}