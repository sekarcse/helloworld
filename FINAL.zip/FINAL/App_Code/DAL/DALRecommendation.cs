﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DALRecommendation
/// </summary>
public class DALRecommendation
{
	public DALRecommendation()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataSet getHistoryRecommendation(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getHistoryRecommendation", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "Recommendation");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    public void RecommendationAddNewInsertHistoryRecommendation(int Cust_Id, DateTime date_of_recommendation, string File_Name, string File_Path, int Recommendation, string create_user, Int32 location_id, Decimal Saving_Refund, DateTime date_expected, DateTime date_agreed_by_supplier, DateTime date_billed_by_monarch)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertHistoryRecommendation", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date_of_recommendation", date_of_recommendation));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Recommendation", Recommendation));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));



            myCommand.Parameters.Add(new SqlParameter("@location_id", location_id));
            myCommand.Parameters.Add(new SqlParameter("@Saving_Refund", Saving_Refund));
            myCommand.Parameters.Add(new SqlParameter("@date_expected", date_expected));
            myCommand.Parameters.Add(new SqlParameter("@date_agreed_by_supplier", date_agreed_by_supplier));
            myCommand.Parameters.Add(new SqlParameter("@date_billed_by_monarch", date_billed_by_monarch));



            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }



    public DataSet delHistoryRecommendation(int Id, int Cust_id)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delHistoryRecommendation", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "GeneralInfo");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet UpdateHistoryRecommendation(int Id, int Cust_Id, DateTime date_of_recommendation, string File_Name, string File_Path, int Recommendation, string update_user, Int32 location_id, Decimal Saving_Refund, DateTime date_expected, DateTime date_agreed_by_supplier, DateTime date_billed_by_monarch)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateHistoryRecommendation", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date_of_recommendation", date_of_recommendation));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Recommendation", Recommendation));
            myCommand.Parameters.Add(new SqlParameter("@update_user", update_user));



            myCommand.Parameters.Add(new SqlParameter("@location_id", location_id));
            myCommand.Parameters.Add(new SqlParameter("@Saving_Refund", Saving_Refund));
            myCommand.Parameters.Add(new SqlParameter("@date_expected", date_expected));
            myCommand.Parameters.Add(new SqlParameter("@date_agreed_by_supplier", date_agreed_by_supplier));
            myCommand.Parameters.Add(new SqlParameter("@date_billed_by_monarch", date_billed_by_monarch));


            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Recommendation");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }

    }


}