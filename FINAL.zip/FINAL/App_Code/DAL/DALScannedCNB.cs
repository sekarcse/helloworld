﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;
/// <summary>
/// Summary description for DALScannedCNB
/// </summary>
public class DALScannedCNB
{
	public DALScannedCNB()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataSet getScannedCNB(int Cust_Id)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getHistoryScannedCNB", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "ScannedCNB");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }


    public DataSet InsertScannedCNB(int Cust_Id, string File_Name, string File_Path, string create_user, DateTime Startdate, DateTime Enddate, int Util_type, string CNB)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
       // try
       // {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertHistoryScannedCNB", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
            myCommand.Parameters.Add(new SqlParameter("@Startdate", Startdate));
            myCommand.Parameters.Add(new SqlParameter("@Enddate", Enddate));
            myCommand.Parameters.Add(new SqlParameter("@Util_type", Util_type));
            myCommand.Parameters.Add(new SqlParameter("@CNB", CNB));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ClientAttendees");
            return ds;
        //}
        //catch (Exception ex)
        //{
        //    ex.ToString();
        //    return ds;
        //}
        //finally
        //{
        //    if (myConn != null)
        //        myConn.Close();
        //}
    }


    public DataSet UpdateScannedCNB(int Id, int cust_id, string File_Name, string File_Path, string update_user, DateTime Startdate, DateTime Enddate, int Util_type, string CNB)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateHistoryScannedCNB", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@cust_id", cust_id));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@update_user", update_user));
            myCommand.Parameters.Add(new SqlParameter("@Startdate", Startdate));
            myCommand.Parameters.Add(new SqlParameter("@Enddate", Enddate));
            myCommand.Parameters.Add(new SqlParameter("@Util_type", Util_type));
            myCommand.Parameters.Add(new SqlParameter("@CNB", CNB));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ScannedCNB");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet delScannedCNB(int Id, int cust_id)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delHistoryScannedCNB", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@cust_id", cust_id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ScannedCNB");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public void AddNewInsertScannedCNB(int Cust_Id, string File_Name, string File_Path, string create_user, DateTime Startdate, DateTime Enddate, int Util_type, string CNB)
    {

        SqlConnection myConn = null;
        
        try
        {
        string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        myConn = new SqlConnection(strConn);
        myConn.Open();
        SqlCommand myCommand = new SqlCommand("InsertHistoryScannedCNB", myConn);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
        myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
        myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
        myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
        myCommand.Parameters.Add(new SqlParameter("@Startdate", Startdate));
        myCommand.Parameters.Add(new SqlParameter("@Enddate", Enddate));
        myCommand.Parameters.Add(new SqlParameter("@Util_type", Util_type));
        myCommand.Parameters.Add(new SqlParameter("@CNB", CNB));
        myCommand.ExecuteNonQuery(); 
        }
        catch (Exception ex)
        {
            throw ex; 
        }
        finally
        {
             if (myConn != null)
                 myConn.Close();
        }
    }

}