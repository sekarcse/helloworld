﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DALUserRights
/// </summary>
public class DALUserRights
{
	public DALUserRights()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataSet GetUserRights()
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("GetUserRights", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "UserRights");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public void UpdateUserRights(string strUserRights)
    {
        SqlConnection myConn = null;        
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateUserRights", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@strUserRights", strUserRights));
            myCommand.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ex.ToString();            
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


}