﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for Login
/// </summary>
public class DALLogin
{   

    // Start of LoginCheck
    public DataSet LoginCheck(string UserId, string password)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {
       
        string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

        myConnection = new SqlConnection(connectionString);
        myConnection.Open();
        SqlCommand strCommand = new SqlCommand("Login_User",myConnection);
        strCommand.CommandType = CommandType.StoredProcedure;
        strCommand.Parameters.Add(new SqlParameter("@UserId",UserId));
        strCommand.Parameters.Add(new SqlParameter("@Password",password));

        SqlDataAdapter da = new SqlDataAdapter(strCommand);
        da.Fill(ds, "Users");
        return ds;

        }
        catch(Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {        
            if (myConnection != null)
    			{
	    			myConnection.Close();
			    }			    
        }    
    
    }
    // End of Login Check.


    public string getMd5Hash(string input)
    {
        // Create a new instance of the MD5 object.
        MD5 md5Hasher = MD5.Create();

        // Convert the input string to a byte array and compute the hash.
        byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(input));

        // Create a new Stringbuilder to collect the bytes
        // and create a string.
        StringBuilder sBuilder = new StringBuilder();

        // Loop through each byte of the hashed data 
        // and format each one as a hexadecimal string.
        int i = 0;
        for (i = 0; i <= data.Length - 1; i++)
        {
            sBuilder.Append(data[i].ToString("x2"));
        }

        // Return the hexadecimal string.
        return sBuilder.ToString();

    }


    public DataSet getAllUsers()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {


            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getAllUsers", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);


            da.Fill(ds, "Users");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



    
}