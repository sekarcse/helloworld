﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;


/// <summary>
/// Summary description for DALTariff
/// </summary>
public class DALTariff
{
    
    public DataSet getSuppliers()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {


            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getSuppliers", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            

            da.Fill(ds, "Users");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
            
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



    public void UpdateTariff(DataTable dt)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        SqlTransaction transaction = null;

        try
        {


            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();

            transaction = myConnection.BeginTransaction();

            SqlCommand strCommand = new SqlCommand();
            strCommand.Connection = myConnection;
            strCommand.Transaction = transaction;
            strCommand.CommandText = "delete [Tariff Change]";
            strCommand.CommandType = CommandType.Text;
            strCommand.ExecuteNonQuery();

            strCommand.CommandText = "select * from [Tariff Change]";
            strCommand.CommandType = CommandType.Text;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            SqlCommandBuilder myBuilder = new SqlCommandBuilder(da); 

            myBuilder.GetUpdateCommand();

            da.UpdateCommand = myBuilder.GetUpdateCommand();

            da.Update(dt);
            transaction.Commit();

        }
        catch (Exception ex)
        {

            transaction.Rollback(); 
            ex.ToString();           

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



     public DataSet getCustomers()
    {

        SqlConnection myConn = null;
         DataSet ds = new DataSet();
         
         try
        {

            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConn = new SqlConnection(strConn);
            myConn.Open();

            SqlCommand myCommand = new SqlCommand("getAllCustomer", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Customers");

            return ds;

        }
        catch (Exception ex)
        {
            
            ex.ToString();
            return null;            

        }

        finally
        {
            if (myConn != null)
                myConn.Close();
        
        }
         
    }

     public void InsertTariff(int CustomerID,int cnb_no,int supplier,DateTime enddate,string UtilType)
     {
         SqlConnection myConn = null;
         try
         {
             string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
             myConn = new SqlConnection(strConn);
             myConn.Open();
             SqlCommand myCommand = new SqlCommand("InsertTariff", myConn);
             myCommand.CommandType = CommandType.StoredProcedure;
             myCommand.Parameters.Add(new SqlParameter("@CustomerID",CustomerID));
             myCommand.Parameters.Add(new SqlParameter("@cnb_no",cnb_no));
             myCommand.Parameters.Add(new SqlParameter("@supplier",supplier));
             myCommand.Parameters.Add(new SqlParameter("@enddate",enddate));
             myCommand.Parameters.Add(new SqlParameter("@UtilType",UtilType));
             myCommand.ExecuteNonQuery();
         }
         catch (Exception ex)
         {
             ex.ToString();
         }
         finally
         {

             if (myConn != null)
                 myConn.Close();
         }
     }



     public DataTable getRejectedLog(int CustomerID,string type)
     {
         SqlConnection myConn = null;
         DataTable dt = null;
         try
         {
             string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
             myConn = new SqlConnection(strConn);
             myConn.Open();
             SqlCommand myCommand = new SqlCommand("GetErrorLog", myConn);
             myCommand.CommandType = CommandType.StoredProcedure;
             myCommand.Parameters.Add(new SqlParameter("@CustID", CustomerID));
             myCommand.Parameters.Add(new SqlParameter("@UtilType", type));
             SqlDataAdapter da = new SqlDataAdapter(myCommand);
             DataSet ds = new DataSet();

             da.Fill(ds, "RejectedLog");
             dt = ds.Tables[0];
             return dt;

         }
         catch (Exception ex)
         {
             ex.ToString();
             return dt;
         }
         finally
         {

             if (myConn != null)
                 myConn.Close();
         }
     }





}