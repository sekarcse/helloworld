﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DALHHSTariff
/// </summary>
public class DALHHSTariff
{
	public DALHHSTariff()
	{
		//
		// TODO: Add constructor logic here
		//
	}




    public DataSet DisplaySuppliers()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPHHSDisplaySuppliers", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;            
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "HHSDisplaySuppliers");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    
    public Int64 SaveHHSTariffParent(int Cust_Id, int SupplierID, string StandingChargePeriod, Decimal std_charge, string Structure, string create_user)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("SPSaveHHSTariffParent", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@supplier", SupplierID));
            myCommand.Parameters.Add(new SqlParameter("@std_charge_period", StandingChargePeriod));
            myCommand.Parameters.Add(new SqlParameter("@std_charge", std_charge));
            myCommand.Parameters.Add(new SqlParameter("@Structure", Structure));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));

            SqlParameter parameterAssessmentId = myCommand.Parameters.Add("@HHSTariff_ParentId", SqlDbType.BigInt);
            parameterAssessmentId.Direction = ParameterDirection.Output;
            myCommand.ExecuteNonQuery();

            Int64 HHSTariff_ParentId = (Int64)myCommand.Parameters["@HHSTariff_ParentId"].Value;
            if (myConn != null)
                myConn.Close();
            return HHSTariff_ParentId;
        }
        catch (Exception ex)
        {
            ex.ToString();
            if (myConn != null)
                myConn.Close();
            return 0;
        }        
    }


    public DataSet LoadHHSTariffParent(int Cust_Id)
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("SPLoadHHSTariffParent", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "LoadHHSTariffParent");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }



    public void DeleteTariffChild(int Id, int Cust_id)
    {
        SqlConnection myConn = null;
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("SPDeleteTariffChild", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_id", Cust_id));          
            myCommand.ExecuteNonQuery();            
        }
        catch (Exception ex)
        {
            ex.ToString();
            if (myConn != null)
                myConn.Close();            
        }
    }




    public void AddNewTariffChild(int Cust_Id, DateTime Start_date, DateTime End_date, string Reading_Type, string Reading_StartTime, string Reading_EndTime, string create_user, Int64 Tariff_ParentID, Decimal Rate)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();
         try
         {
        string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
        myConn = new SqlConnection(strConn);
        myConn.Open();
        SqlCommand myCommand = new SqlCommand("SPAddNewTariffChild", myConn);
        myCommand.CommandType = CommandType.StoredProcedure;

        myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
        myCommand.Parameters.Add(new SqlParameter("@Start_date", Start_date));
        myCommand.Parameters.Add(new SqlParameter("@End_date", End_date));
        myCommand.Parameters.Add(new SqlParameter("@Reading_Type", Reading_Type));
        myCommand.Parameters.Add(new SqlParameter("@Reading_StartTime", Reading_StartTime));
        myCommand.Parameters.Add(new SqlParameter("@Reading_EndTime", Reading_EndTime));
        myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
        myCommand.Parameters.Add(new SqlParameter("@Tariff_ParentID", Tariff_ParentID));
        myCommand.Parameters.Add(new SqlParameter("@Rate", Rate));
        myCommand.ExecuteNonQuery();  
         }
         catch (Exception ex)
         {
             ex.ToString();
         }
         finally
         {
             if (myConn != null)
                 myConn.Close();
         }
    }


    public DataSet BindLLCsData()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("BindLLCsData", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;            
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "LLCsData");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet BindDLAFsData()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("BindDLAFsData", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "DLAFsData");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet BindDistributionIDsData()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("BindDistributionIDsData", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "DistributionIDsData");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet BindTimeBandsforDLAFsData()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("BindTimeBandsforDLAFsData", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "TimeBandsforDLAFsData");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

}