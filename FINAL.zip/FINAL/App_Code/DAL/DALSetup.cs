﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALSetup
/// </summary>
public class DALSetup
{
	public DALSetup()
	{
		//
		// TODO: Add constructor logic here
		//
	}



    public DataSet getAllVenue()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {


            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getAllVenue", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            da.Fill(ds, "Venue");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }
    // end of Get all Venues.


    public DataSet UpdateVenue(int VenueID, string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateVenue", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@VenueID", VenueID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Venue");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet InsertVenue(string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertVenue", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Venue");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet DeleteVenue(int VenueID)
    {
        
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DeleteVenue", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@VenueID", VenueID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Venue");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }
    
    // for Meeting Result

    public DataSet getMeetingPurpose()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {


            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getMeetingPurpose", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            da.Fill(ds, "MeetingPurpose");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }
    // end of Get all Venues.


    public DataSet UpdateMeetingPurpose(int ID, string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateMeetingPurpose", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingPurpose");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet InsertMeetingPurpose(string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertMeetingPurpose", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingPurpose");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet DelMeetingPurpose(int ID)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DelMeetingPurpose", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingPurpose");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    // For meeting purpose. 

    public DataSet getMeetingResult()
    {
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {


            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getMeetingResult", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            da.Fill(ds, "MeetingResult");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }
    // end of Get all Venues.


    public DataSet UpdateMeetingResult(int ID, string Name, string Description)

    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateMeetingResult", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingResult");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet InsertMeetingResult(string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertMeetingResult", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingResult");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet DelMeetingResult(int ID)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DelMeetingResult", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingResult");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }

    // Actions 


    public DataSet getAllActions()
    {
        
        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {

            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getAllActions", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            da.Fill(ds, "getAllActions");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



    public DataSet UpdateActions(int ID, string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateActions", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "UpdateActions");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet InsertActions(string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertActions", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "InsertActions");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet DelActions(int ID)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DelActions", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "DelActions");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }

    // Meeting Called by

    public DataSet getMeetingCalledBy()
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {

            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getMeetingCalledBy", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            da.Fill(ds, "MeetingCalledBy");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



    public DataSet UpdateMeetingCalledBy(int ID, string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateMeetingCalledBy", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingCalledBy");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet InsertMeetingCalledBy(string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertMeetingCalledBy", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingCalledBy");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet DeleteMeetingCalledby(int ID)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DeleteMeetingCalledby", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "MeetingCalledBy");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    // --

    public DataSet getCalledby(int MeetingCalledByID)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getCalledby", myConnection);
            strCommand.Parameters.Add(new SqlParameter("@MeetingCalledByID", MeetingCalledByID));
            strCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "CalledBy");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }


    public DataSet InsertCalledBy(int MeetingCalledByID, string Name, string Description)
    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertCalledBy", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledByID", MeetingCalledByID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "ClientAttendees");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet UpdateCalledBy(int ID, int MeetingCalledByID, string Name, string Description)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateCalledBy", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledByID", MeetingCalledByID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));

            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "CalledBy");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet DelCalledby(int ID, int MeetingCalledByID)

    {

        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DelCalledby", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@MeetingCalledByID", MeetingCalledByID));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);

            da.Fill(ds, "CalledBy");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }

    // --

    public DataSet getComplaint_Nature(int OptionCode)
    {

        SqlConnection myConnection = null;
        DataSet ds = new DataSet();

        try
        {

            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getComplaint_Nature", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@OptionCode", OptionCode));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);

            da.Fill(ds, "getAllActions");

            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;

        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }

    }



    public DataSet UpdateComplaint_Nature(int ID, string Name, string Description, int OptionCode)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateComplaint_Nature", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));
            myCommand.Parameters.Add(new SqlParameter("@OptionCode", OptionCode));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "UpdateActions");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet InsertComplaint_Nature(string Name, string Description, int OptionCode)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();

        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertComplaint_Nature", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Name", Name));
            myCommand.Parameters.Add(new SqlParameter("@Description", Description));
            myCommand.Parameters.Add(new SqlParameter("@OptionCode", OptionCode));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "InsertActions");
            return ds;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet DelComplaint_Nature(int ID, int OptionCode)
    {
        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("DelComplaint_Nature", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@ID", ID));
            myCommand.Parameters.Add(new SqlParameter("@OptionCode", OptionCode));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "DelActions");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }


}