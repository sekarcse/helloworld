﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

public class DALUserRegistration
{
	public DALUserRegistration()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    // --------------------------------------------------------------------//
    // Method Name:     RegisterUser  ()
    // Purpose:         To register the user in database.
    // Created by :     Muhammad Siddique Bhatti
    // Created Date:    11 August 2010
    // Modified by: 
    // Modified date: 
    // --------------------------------------------------------------------//

    public bool RegisterUser(string UserName, string Password, string FirstName, string LastName, Int32 Role_id, string Email)
    {

        SqlConnection myConn = null;

        try
        {

            
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("Register_User", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@UserName", UserName));
            myCommand.Parameters.Add(new SqlParameter("@Password", Password));
            myCommand.Parameters.Add(new SqlParameter("@FirstName", FirstName));
            myCommand.Parameters.Add(new SqlParameter("@LastName", LastName));
            myCommand.Parameters.Add(new SqlParameter("@Role_id", Role_id));
            myCommand.Parameters.Add(new SqlParameter("@Email", Email));

            //SqlParameter parameter = myCommand.Parameters.Add("@RowCount", SqlDbType.Int);
            //parameter.Direction = ParameterDirection.ReturnValue;

            SqlParameter parameter = myCommand.Parameters.Add("@RowCount", SqlDbType.Int);
            parameter.Direction = ParameterDirection.Output;

            myCommand.ExecuteNonQuery();
            
            Int32 rowCount = (Int32)myCommand.Parameters["@RowCount"].Value;

            if (rowCount > 0)
                return true;
            else
                return false;

        }
        catch (Exception ex)
        {
            ex.ToString();
            return false;
        }
        finally
        {

            if (myConn != null)
                myConn.Close();
        }
    }

}