﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for DALClient_Satisfaction
/// </summary>
public class DALClient_Satisfaction
{
	public DALClient_Satisfaction()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataSet getClient_Satisfaction(int Cust_Id)
    {



        SqlConnection myConnection = null;
        DataSet ds = new DataSet();
        try
        {
            string connectionString = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConnection = new SqlConnection(connectionString);
            myConnection.Open();
            SqlCommand strCommand = new SqlCommand("getClient_Satisfaction", myConnection);
            strCommand.CommandType = CommandType.StoredProcedure;
            strCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            SqlDataAdapter da = new SqlDataAdapter(strCommand);
            da.Fill(ds, "Client_Satisfaction");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConnection != null)
            {
                myConnection.Close();
            }
        }
    }

    public DataSet InsertClient_Satisfaction(int Cust_Id, DateTime date, string SatisfactionMadeby, int SatisfactionMode, int SatisfactionNature, string File_Name, string File_Path, string create_user)
    {



        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("InsertClient_Satisfaction", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@SatisfactionMadeby", SatisfactionMadeby));
            myCommand.Parameters.Add(new SqlParameter("@SatisfactionMode", SatisfactionMode));
            myCommand.Parameters.Add(new SqlParameter("@SatisfactionNature", SatisfactionNature));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@create_user", create_user));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Client_Satisfaction");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }


    public DataSet UpdateClient_Satisfaction(int Id, int Cust_Id, DateTime date, string SatisfactionMadeby, int SatisfactionMode, int SatisfactionNature, string File_Name, string File_Path, string Update_User)
    {



        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("UpdateClient_Satisfaction", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@Cust_Id", Cust_Id));
            myCommand.Parameters.Add(new SqlParameter("@date", date));
            myCommand.Parameters.Add(new SqlParameter("@SatisfactionMadeby", SatisfactionMadeby));
            myCommand.Parameters.Add(new SqlParameter("@SatisfactionMode", SatisfactionMode));
            myCommand.Parameters.Add(new SqlParameter("@SatisfactionNature", SatisfactionNature));
            myCommand.Parameters.Add(new SqlParameter("@File_Name", File_Name));
            myCommand.Parameters.Add(new SqlParameter("@File_Path", File_Path));
            myCommand.Parameters.Add(new SqlParameter("@Update_User", Update_User));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Client_Satisfaction");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }

    public DataSet delClient_Satisfaction(int Id, int cust_id)
    {



        SqlConnection myConn = null;
        DataSet ds = new DataSet();
        try
        {
            string strConn = (string)ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            myConn = new SqlConnection(strConn);
            myConn.Open();
            SqlCommand myCommand = new SqlCommand("delClient_Satisfaction", myConn);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.Add(new SqlParameter("@Id", Id));
            myCommand.Parameters.Add(new SqlParameter("@cust_id", cust_id));
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            da.Fill(ds, "Client_Satisfaction");
            return ds;
        }
        catch (Exception ex)
        {
            ex.ToString();
            return ds;
        }
        finally
        {
            if (myConn != null)
                myConn.Close();
        }
    }
}