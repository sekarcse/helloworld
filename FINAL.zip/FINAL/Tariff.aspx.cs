﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Diagnostics;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Data;
using System.IO;
using Microsoft.VisualBasic;
using System.Text;

public partial class Tariff : System.Web.UI.Page
{

    string CurrentFileName = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                if (Session["RoleID"] == null)
                    Response.Redirect("login.asp");

                getAllSuppiers();
                getAllCustomers();
                
            }

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    public void getAllSuppiers()
    {

        try
        {
            DALTariff objtariff = new DALTariff();
            DataSet dsSuppliers = new DataSet();
            dsSuppliers = objtariff.getSuppliers();

            ddlSuppliers.DataSource = dsSuppliers;
            ddlSuppliers.DataValueField = "Supplier_id";
            ddlSuppliers.DataTextField = "Supplier_name";
            ddlSuppliers.DataBind();
            ddlSuppliers.Items.Insert(0, "<-- Select -->");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    public void getAllCustomers()
    {

        try
        {
            DALTariff objTariff = new DALTariff();
            DataSet dsCustomers = new DataSet();
            dsCustomers = objTariff.getCustomers();

            ddlCustomers.DataSource = dsCustomers;
            ddlCustomers.DataValueField = "customer_id";
            ddlCustomers.DataTextField = "company_name";
            ddlCustomers.DataBind();

            ddlCustomers.Items.Insert(0, "<-- Select -->");

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void BtnImportFile_Click(object sender, EventArgs e)
    {

        TabDelimitedFunction();

    }

    public void TabDelimitedFunction()
    {

        try
        {

            string mfilepath;
            mfilepath = "C:/Temp/test4.txt";

            if (!FileUpload.HasFile)
                return;

            string CurrentFilePath;
            CurrentFileName = FileUpload.FileName;
          
            
            FileUpload.SaveAs(HttpContext.Current.Server.MapPath("TempFiles\\") + FileUpload.FileName) ;
              
            CurrentFilePath = HttpContext.Current.Server.MapPath("TempFiles\\")  +
               System.IO.Path.GetFileName(FileUpload.FileName);

            DataTable dt = new DataTable();
            using (TextReader tr = File.OpenText(CurrentFilePath))
            {
                string line;
                while ((line = tr.ReadLine()) != null)
                {
                    string[] items = line.Split('\t');
                    if (dt.Columns.Count == 0)
                    {
                        // Create the data columns for the data table based on the number of items on the first line of the file
                        for (int i = 0; i < items.Length; i++)
                            dt.Columns.Add(new DataColumn(items[i].ToString().TrimEnd(), typeof(string)));
                    }
                    else
                        dt.Rows.Add(items);
                }
            }

            DALTariff obj = new DALTariff();
            obj.UpdateTariff(dt);

            //ErrorMsg.Text = "File import successfully.";
            System.IO.File.Delete(HttpContext.Current.Server.MapPath("TempFiles\\")  +
               System.IO.Path.GetFileName(FileUpload.FileName));

        }
        catch (Exception ex)
        {
            ex.ToString();
        }

    }


    public static void ExportToSpreadsheet(DataTable table, string name)
    {

        try
        {

            HttpContext context = HttpContext.Current;
            context.Response.Clear();
            foreach (DataColumn column in table.Columns)
            {
                context.Response.Write(column.ColumnName + "\t");
            }
            context.Response.Write(Environment.NewLine);
            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    context.Response.Write(row[i].ToString().Replace("\t", string.Empty) + "\t");
                }
                context.Response.Write(Environment.NewLine);
            }

            context.Response.ContentType = "application/vnd.ms-excel";
            context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + name + ".xls");
            context.Response.End();

        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    public static void ExportToTextFile(DataTable table, string name)
    {

        String strFileName = null;
        HttpContext context = HttpContext.Current;

        

        try
        {

            strFileName = HttpContext.Current.Server.MapPath("TariffErrorLog\\") + "GasErrorLog__" +
                DateTime.Now.Year +
                DateTime.Now.Month +
                DateTime.Now.Day +
                DateTime.Now.Hour +
                DateTime.Now.Minute +
                DateTime.Now.Second +
                DateTime.Now.Millisecond +
                ".txt";

            StreamWriter fp = default(StreamWriter);
            fp = File.CreateText(strFileName);
            foreach (DataColumn column in table.Columns)
            {
                fp.Write(column.ColumnName + "\t");
            }
            fp.Write(Environment.NewLine);

            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    fp.Write(row[i].ToString().Replace("\t", string.Empty) + "\t");
                }
                fp.Write(Environment.NewLine);
            }


            fp.Close();

            FileInfo fileinfo = new FileInfo(strFileName);
            if (fileinfo.Exists)
            {
                context.Response.Clear();
                context.Response.AddHeader("Content-Disposition", "inline;attachment; filename=" + fileinfo.Name);
                context.Response.AddHeader("Content-Length", fileinfo.Length.ToString());
                context.Response.ContentType = "application/octet-stream";
                context.Response.Flush();
                context.Response.WriteFile(fileinfo.FullName);
                context.Response.End();
            }

            
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }


    protected void ChangePasswordPushButton_Click(object sender, EventArgs e)
    {

        try
        {
        DALTariff objtariff = new DALTariff();
 
        string type;

        if (rdotype1.Checked)
            type = "elec";
        else
        {
            type = "gas";
        }

        DataTable dt = new DataTable();
        int Customer_ID = Convert.ToInt32(ddlCustomers.SelectedValue.ToString().Trim());
        int CNB_NO = Convert.ToInt32(txt_cnb_no.Text.ToString().Trim());
        int Supplier_ID = Convert.ToInt32(ddlSuppliers.SelectedValue.ToString().Trim());
        DateTime EndDate = Convert.ToDateTime(txt_enddate.Text.ToString().Trim());       

        dt = objtariff.getRejectedLog(Customer_ID,type);

        objtariff.InsertTariff(Customer_ID, CNB_NO, Supplier_ID, EndDate, type);
            
        ExportToTextFile(dt, "");
        
        }
        catch(Exception ex)
        {
            ex.ToString();
        }

    }

    
    
    public void ClearControls()
    {
       txt_cnb_no.Text = string.Empty  ;
       ddlCustomers.SelectedIndex = 0;
       ddlSuppliers.SelectedIndex = 0;
       txt_enddate.Text = string.Empty;
       rdotype1.Checked = true;
    }

    protected void CancelPushButton_Click(object sender, EventArgs e)
    {
        ClearControls();
    }
}